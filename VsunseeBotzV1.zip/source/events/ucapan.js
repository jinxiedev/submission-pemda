import moment from 'moment-timezone'

export function Ucapan() {
const time = moment().tz('Asia/Jakarta').format('HH:mm:ss')
let vanztime
if (time < "05:00:00") { vanztime = "sᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ 🌌" }
else if (time < "11:00:00") { vanztime = "sᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ 🌄" }
else if (time < "15:00:00") { vanztime = "sᴇʟᴀᴍᴀᴛ sɪᴀɴɢ 🌅" }
else if (time < "18:00:00") { vanztime = "sᴇʟᴀᴍᴀᴛ sᴏʀᴇ 🌇" }
else if (time < "19:00:00") { vanztime = "sᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ 🌠" }
else { vanztime = "sᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ 🌌" }
return vanztime
}

export function Waktu() {
const tanggal = moment().tz('Asia/Jakarta').format('DD')
const bulan = moment().tz('Asia/Jakarta').format('MMMM')
const tahun = moment().tz('Asia/Jakarta').format('YYYY')
return `${tanggal} ${bulan} ${tahun}`
}

export function Jam() {
return moment().tz('Asia/Jakarta').format('HH:mm:ss')
}