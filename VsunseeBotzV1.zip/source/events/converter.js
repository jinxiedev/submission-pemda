import fs from 'fs-extra'
import ffmpeg from 'fluent-ffmpeg'
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg'
ffmpeg.setFfmpegPath(ffmpegInstaller.path)

export async function toAudio(input, ext = 'mp4') {
const id = Date.now()
const inputPath = `./temp_${id}.${ext}`
const outputPath = `./temp_${id}.mp3`
fs.writeFileSync(inputPath, input)

return new Promise((resolve, reject) => {
ffmpeg(inputPath)
.toFormat('mp3')
.audioBitrate(128)
.on('end', () => {
const result = fs.readFileSync(outputPath)
fs.unlinkSync(inputPath)
fs.unlinkSync(outputPath)
resolve(result)
})
.on('error', (err) => {
reject(err)
})
.save(outputPath)
})
}