import '../../settings/thumb.js'
import axios from 'axios'
import fs from 'fs'
import { tmpdir } from 'os'
import path from 'path'
import { addExif, imageToWebp, videoToWebp } from './exif.js'

export async function makeStickerFromUrl(mediaUrl, vanzz, m, reply) {
try {
const tmpPath = path.join(tmpdir(), `${Date.now()}`)
const response = await axios.get(mediaUrl, { responseType: 'arraybuffer' })
fs.writeFileSync(tmpPath, response.data)

let webpBuffer
if (/\.mp4|\.mov|\.avi|\.webm/i.test(mediaUrl)) {
webpBuffer = await videoToWebp(fs.readFileSync(tmpPath))
} else {
webpBuffer = await imageToWebp(fs.readFileSync(tmpPath))
}

const sticker = await addExif(webpBuffer, global.namebotz, global.nameown)

await vanzz.sendMessage(m.chat, {
sticker,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [m.sender], 
forwardedNewsletterMessageInfo: {
newsletterName: global.nameown, 
newsletterJid: global.ChannelID, 
},

externalAdReply: {
title: global.namebotz,
body: `Created by ${global.nameown}`,
mediaType: 1,
renderLargerThumbnail: false,
thumbnailUrl: global.StickerReply,
sourceUrl: global.VsunseeApi
}
}
}, { quoted: m })


fs.unlinkSync(tmpPath)
} catch (err) {
console.error('STICKER ERROR:', err)
reply('❌ Gagal membuat stiker. Pastikan format media didukung (Gambar/Video).')
}
}