import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys'; 

//Button Mesej
export const sendButtonMsg = async (vanzz, jid, content = {}, options = {}) => {
const { text, caption, footer = '', headerType = 1, ai, contextInfo = {}, buttons = [], mentions = [], ...media } = content;

const msg = await generateWAMessageFromContent(jid, {
viewOnceMessage: {
message: {
messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
buttonsMessage: {
...(media && typeof media === 'object' && Object.keys(media).length > 0 ? await generateWAMessageContent(media, { upload: vanzz.waUploadToServer }) : {}),
contentText: text || caption || '',
footerText: footer,
buttons,
headerType: (media && Object.keys(media).length > 0) ? Math.max(...Object.keys(media).map((a) => ({ document: 3, image: 4, video: 5, location: 6 })[a] || headerType)) : headerType,
contextInfo: {
...contextInfo,
...options.contextInfo,
mentionedJid: options.mentions || mentions,
...(options.quoted ? {
stanzaId: options.quoted.key.id,
remoteJid: options.quoted.key.remoteJid,
participant: options.quoted.key.participant || options.quoted.key.remoteJid,
fromMe: options.quoted.key.fromMe,
quotedMessage: options.quoted.message
} : {})
}
}
}
}
}, {});

await vanzz.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id,
additionalNodes: [{
tag: 'biz',
attrs: {},
content: [{
tag: 'interactive',
attrs: { type: 'native_flow', v: '1' },
content: [{ tag: 'native_flow', attrs: { name: 'quick_reply' } }]
}]
}, ...(ai ? [{ attrs: { biz_bot: '1' }, tag: 'bot' }] : [])]
})
return msg
}


//List Mesej
export const sendListMsg = async (vanzz, jid, content = {}, options = {}) => {
const { text, caption, footer = '', headerType = 1, ai, contextInfo = {}, buttonText = 'Click Here', sections = [], mentions = [], ...media } = content;

if (!Array.isArray(sections) || sections.length === 0) {
throw new Error("Properti 'sections' harus berupa array yang tidak kosong.");
}

const msg = await generateWAMessageFromContent(jid, {
viewOnceMessage: {
message: {
messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
listMessage: {
...(media && typeof media === 'object' && Object.keys(media).length > 0 ? await generateWAMessageContent(media, { upload: vanzz.waUploadToServer }) : {}),
title: text || caption || '',
description: footer, 
buttonText: buttonText, 
listType: 1, 
sections: sections, 
contextInfo: {
...contextInfo,
...options.contextInfo,
mentionedJid: options.mentions || mentions,
...(options.quoted ? {
stanzaId: options.quoted.key.id,
remoteJid: options.quoted.key.remoteJid,
participant: options.quoted.key.participant || options.quoted.key.remoteJid,
fromMe: options.quoted.key.fromMe,
quotedMessage: options.quoted.message
} : {})
}
}
}
}
}, {});

await vanzz.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id,
additionalNodes: [
...(ai ? [{ attrs: { biz_bot: '1' }, tag: 'bot' }] : [])
]
})

return msg
}
