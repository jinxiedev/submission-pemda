import axios from 'axios'
import fs from 'fs'
import FormData from 'form-data'
import request from 'request'
import * as cheerio from 'cheerio'
import { fileTypeFromBuffer } from 'file-type'

async function uploadCatbox(filePath){
try{
const f=new FormData()
f.append('reqtype','fileupload')
f.append('fileToUpload',fs.createReadStream(filePath))
const r=await axios.post('https://catbox.moe/user/api.php',f,{headers:{...f.getHeaders()},responseType:'text',timeout:20000})
if(typeof r.data==='string'&&r.data.startsWith('http'))return[{url:r.data.trim()}]
}catch(e){}
return null
}

async function uploadUguu(filePath){
try{
const f=new FormData()
f.append('files[]',fs.createReadStream(filePath))
const r=await axios.post('https://uguu.se/upload.php',f,{headers:{...f.getHeaders()},timeout:20000})
const u=r.data?.files?.[0]?.url||r.data?.files?.[0]
if(u)return[{url:u}]
}catch(e){}
return null
}

async function uploadTop4Top(filePath){
try{
const buffer=fs.readFileSync(filePath)
const{ext}=(await fileTypeFromBuffer(buffer))||{ext:'bin'}
return new Promise(resolve=>{
const req=request({url:'https://top4top.io/index.php',method:'POST',headers:{'User-Agent':'Mozilla/5.0','accept':'*/*','content-type':'multipart/form-data; boundary=----WebKitFormBoundaryAmIhdMyLOrbDawcA'}},(err,res,body)=>{
if(err)return resolve(null)
const $=cheerio.load(body)
const result=$('div.alert.alert-warning > ul > li > span').find('a').attr('href')||null
if(result)resolve([{url:result}]);else resolve(null)
})
const form=req.form()
form.append('file_1_',buffer,{filename:`${Date.now()}.${ext}`})
form.append('submitr','[ رفع الملفات ]')
})
}catch(e){}
return null
}

async function tryUploadAll(filePath){
const list=[uploadCatbox,uploadUguu,uploadTop4Top]
for(const fn of list){
try{
const res=await fn(filePath)
if(res&&res[0])return res
}catch{}
}
return null
}

async function downloadURLToTemp(url){
const{data}=await axios.get(url,{responseType:'arraybuffer'})
const tmp=`./temp_${Date.now()}`
fs.writeFileSync(tmp,data)
return tmp
}

export async function upload({buffer,url,path,filename}){
let filePath
try{
if(buffer){
filePath=`./temp_${Date.now()}_${filename||'upload'}`
fs.writeFileSync(filePath,buffer)
}else if(url){
filePath=await downloadURLToTemp(url)
}else if(path&&fs.existsSync(path)){
filePath=path
}else throw new Error('no_input')
const result=await tryUploadAll(filePath)
if(!result)throw new Error('Upload gagal di semua server.')
if(buffer||url)fs.unlinkSync(filePath)
return result
}catch(err){
if(buffer||url){try{if(fs.existsSync(filePath))fs.unlinkSync(filePath)}catch{}}
throw err
}
}