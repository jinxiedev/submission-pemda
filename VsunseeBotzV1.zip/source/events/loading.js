export async function loadingProgress(vanzz, chat) {
  const bars = [
    '▱▱▱▱▱▱▱▱▱▱⁰',
    '▰▰▰▱▱▱▱▱▱▱³⁰',
    '▰▰▰▰▰▰▱▱▱▱⁶⁰',
    '▰▰▰▰▰▰▰▰▰▱⁹⁰',
    '▰▰▰▰▰▰▰▰▰▰¹⁰⁰'
    ]
    const msg = await vanzz.sendMessage(chat, { text: bars[0] })
    for (let i = 1; i < bars.length; i++) {
    await new Promise(r => setTimeout(r, 600))
    await vanzz.sendMessage(chat, { text: bars[i], edit: msg.key })
  }
}