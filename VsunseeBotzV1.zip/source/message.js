import { loadDataBase } from "../source/events/database.js";
import "../settings/config.js";

import { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType, } from "@whiskeysockets/baileys";
import fs from "fs-extra";
import util from "util";
import chalk from "chalk";
import { exec, execSync } from "child_process";
import axios from "axios";
import syntaxerror from "syntax-error";
import { fileURLToPath } from "url";
import path from "path";
import os from "os";
import nou from "node-os-utils"; 
import speed from "performance-now";
import { Jimp } from "jimp"; 
import moment from "moment-timezone";
import { generateProfilePicture, getBuffer, fetchJson, fetchText, getRandom, runtime, sleep, makeid, } from "../source/myfunc.js";
import { qtext } from "../source/quoted.js";
import { vanzreply } from "../source/vanzreply.js";
import { runPlugins } from "../handler.js";
import { leveluser } from "../source/events/_levelup.js";
import { makeStickerFromUrl } from "../source/events/_sticker.js";

let prefix = ".";
let mode = true;

export default async (vanzz, m) => {
try {
await loadDataBase(vanzz, m);

const body = m.body || m.text || "";
const budy = m.body || m.text || "";
const command = body.startsWith(prefix)
  ? body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase()
  : "";
const commands = command.replace(prefix, "");
const args = body.trim().split(/ +/).slice(1);
const q = args.join(" ");
const text = args.join(" "); 
const quoted = m.quoted ? m.quoted : m;
const message = m;
const messageType = m.mtype;
const messageKey = message.key;
const pushName = m.pushName || "Undefined";
const itsMe = m.key.fromMe;
const chat = m.chat;
const sender = m.sender;
const isGroup = m.key.remoteJid.endsWith("@g.us");
const userId = sender.split("@")[0];
const from = m.key.remoteJid
const reply = m.reply;
const botNumber = vanzz.user.id.split(":")[0] + "@s.whatsapp.net";
const isOwner = ((Array.isArray(global.owner) ? global.owner.join(",") : global.owner || "").split(",").map(v => v.trim()).includes(sender.split("@")[0]) || (global.db?.owners || []).map(v => v.trim()).includes(sender.split("@")[0]) || m.key.fromMe);

//
const groupMetadata = isGroup ? await vanzz.groupMetadata(chat).catch(() => ({})) : {};
const groupMembers = isGroup ? (groupMetadata.participants || []) : [];
const participants = isGroup ? groupMembers : '';
const groupName = isGroup ? groupMetadata.subject : "";
const groupId = isGroup ? groupMetadata.id : "";

const isGroupAdmins = isGroup ? groupMembers.some(p => 
    ['admin', 'superadmin'].includes(p.admin) && 
    (p.id === sender || p.phoneNumber === sender)
) : false;

const isBotGroupAdmins = isGroup ? groupMembers.some(p => {
    const isAdmin = ['admin', 'superadmin'].includes(p.admin);
    const botList = global.NumberBot.flatMap(b => b.split(',')).map(b => b.trim());
    const isBot = botList.includes(p.id) || botList.includes(p.phoneNumber);
    return isAdmin && isBot;
}) : false;
//


const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const fcall = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: body}}}     

const TypeMess = getContentType(m?.message);
let reactions = TypeMess == "reactionMessage" ? m?.message[TypeMess]?.text : false;
if (reactions) {
if (["😂"].includes(reactions)) {
vanzz.sendMessage(m.chat, { text: "*KWKWKWKWK😹*" }, { quoted: null });
}
}

//Eval
if (body.startsWith("$")) {
if (!isOwner) return;
await m.reply("_Executing..._");
exec(q, async (err, stdout) => {
if (err) return m.reply(`${err}`);
if (stdout) {
await m.reply(`${stdout}`);
}
});
}

if (body.startsWith(">")) {
if (!isOwner) return;
  try {
const txtt = util.format(await eval(`(async()=>{ ${q} })()`));
m.reply(txtt);
  } catch (e) {
let _syntax = "";
let _err = util.format(e);
let err = syntaxerror(q, "EvalError", {
allowReturnOutsideFunction: true,
allowAwaitOutsideFunction: true,
sourceType: "module",
});
if (err) _syntax = err + "\n\n";
m.reply(util.format(_syntax + _err));
}
}

if (body.startsWith("=>")) {
if (!isOwner) return;
  try {
const txtt = util.format(await eval(`(async()=>{ return ${q} })()`));
m.reply(txtt);
} catch (e) {
let _syntax = "";
let _err = util.format(e);
let err = syntaxerror(q, "EvalError", {
allowReturnOutsideFunction: true,
allowAwaitOutsideFunction: true,
sourceType: "module",
});
if (err) _syntax = err + "\n\n";
m.reply(util.format(_syntax + _err));
}
}

//Command Log
if (m.message) {
console.log(
chalk.bgMagenta(" [===>] "),
chalk.cyanBright("Time: ") +
chalk.greenBright(new Date()) +
  "\n",
chalk.cyanBright("Message: ") +
chalk.greenBright(budy || m.mtype) +
  "\n" +
chalk.cyanBright("From:"),
chalk.greenBright(pushName),
chalk.yellow("- " + m.sender) +
  "\n" +
chalk.cyanBright("Chat Type:"),
chalk.greenBright(!isGroup ? "Private Chat" : "Group Chat - " + chalk.yellow(groupName))
);
}

if (!mode && !itsMe) {
return;
}

if (!body.startsWith(prefix)) {
return;
}

// Up Level
if (global.db && global.db.users && global.db.users[m.sender]) {
const user = global.db.users[m.sender];
if (user) {
const oldRole = user.role;
user.command += 1;
const newRole = leveluser(user.command).rank;
if (oldRole !== newRole) {
user.role = newRole;
const upuser = `🎉 *SELAMAT NAIK LEVEL!* 🎉\n\n*Nama:* ${pushName}\n*Level Lama:* ${oldRole}\n*Level Baru:* ${newRole}\n\nTerus gunakan bot untuk mencapai level selanjutnya!`;
vanzz.sendMessage(m.chat, { text: upuser }, { quoted: qtext });
}
}
}

// Resize
const resize = async (imagePathOrUrl, width, height) => {
let imageBuffer;
if (/^https?:\/\//.test(imagePathOrUrl)) {
const response = await axios.get(imagePathOrUrl, { responseType: "arraybuffer" });
imageBuffer = response.data;
} else {
imageBuffer = await fs.readFile(imagePathOrUrl);
}
const read = await Jimp.read(imageBuffer); 
const data = await read.resize(width, height).getBufferAsync(Jimp.MIME_JPEG);
return data;
};

const reaction = async (jid, emoji) => {
vanzz.sendMessage(jid, { react: { text: emoji, key: m.key } });
};

const plug = {
  vanzz,
  command,
  quoted,
  fetchJson,
  qtext,
  vanzreply, 
  text, 
  budy,
  commands,
  args,
  q,
  message,
  messageType,
  messageKey,
  pushName,
  itsMe,
  chat,
  sender,
  userId,
  reply,
  botNumber,
  isGroup,
  groupMetadata,
  groupName,
  groupId,
  groupMembers,
  isBotGroupAdmins,
  isGroupAdmins,
  generateProfilePicture,
  getBuffer,
  fetchJson,
  fetchText,
  getRandom,
  runtime,
  sleep,
  makeid,
  prefix,
  reaction,
  resize,
};
const pluginHandled = await runPlugins(m, plug);
if (pluginHandled) {
return;
}

//Get List All Command
async function countAllCommands() {
try {
const handlerPath = fileURLToPath(import.meta.url)
const handlerContent = await fs.readFile(handlerPath, "utf8")
const regexCase = /case\s+['"]([^'"]+)['"]/g
const handlerMatches = [...handlerContent.matchAll(regexCase)].map(m => m[1])
const handlerTotal = handlerMatches.length

async function readCmdFolder(dirPath, category = "cmd") {
let results = []
const files = await fs.readdir(dirPath, { withFileTypes: true })
for (const file of files) {
const fullPath = path.join(dirPath, file.name)
if (file.isDirectory()) {
results.push(...(await readCmdFolder(fullPath, `${category}/${file.name}`)))
} else if (file.isFile() && file.name.endsWith(".js")) {
const content = await fs.readFile(fullPath, "utf8")
const regexArray = /handler\.command\s*=\s*\[([^\]]+)\]/g
const regexSingle = /handler\.command\s*=\s*['"]([^'"]+)['"]/g
let match
while ((match = regexArray.exec(content)) !== null) {
const inner = match[1].match(/['"]([^'"]+)['"]/g) || []
inner.forEach(cmd => results.push({ command: cmd.replace(/['"]/g, ''), category }))
}
while ((match = regexSingle.exec(content)) !== null) {
results.push({ command: match[1], category })
}
}
}
return results
}
let cmdResults = []
const cmdDir = path.join(process.cwd(), "cmd")
if (fs.existsSync(cmdDir)) cmdResults = await readCmdFolder(cmdDir)
const grouped = {}
for (const { command, category } of cmdResults) {
if (!grouped[category]) grouped[category] = []
grouped[category].push(command)
}
const cmdTotal = cmdResults.length
const totalAll = handlerTotal + cmdTotal
return { handler: { total: handlerTotal, list: handlerMatches }, cmd: { total: cmdTotal, grouped }, totalAll }
} catch (err) {
console.error("Gagal menghitung total fitur:", err)
return { handler: { total: 0, list: [] }, cmd: { total: 0, grouped: {} }, totalAll: 0 }
}
}

async function autoSholat(vanzz, m) {
try {
global.vanzz = global.vanzz || {};
vanzz.autosholat = vanzz.autosholat || {};
const who = m.mentionedJid?.[0] || (m.fromMe ? vanzz.user.jid : m.sender);
const id = m.chat;
const now = Date.now();
if (id in vanzz.autosholat && now - vanzz.autosholat[id].timestamp < 300000) return;
const jadwalSholat = {
Dhuhr: "12:03",
Asr: "15:09",
Sunset: "18:08",
Maghrib: "18:47",
Isya: "19:38",
Imsak: "04:32"
};
const timeNow = moment().tz("Asia/Jakarta").format("HH:mm");
if (Object.values(jadwalSholat).includes(timeNow)) {
const sholat = Object.keys(jadwalSholat).find(k => jadwalSholat[k] === timeNow);
const caption = `@${who.split`@`[0]},\nWaktu *${sholat}* telah tiba, ambillah air wudhu dan segeralah shalat.\n\n*${timeNow} WIB*\n_untuk wilayah Jakarta dan sekitarnya._`;
console.log(`[AUTO SHOLAT] Mengirim pengingat untuk ${sholat} (${timeNow})`);
const thumb = (await axios.get("https://cdn-icons-png.flaticon.com/128/4527/4527060.png", { responseType: "arraybuffer" })).data;
await vanzz.sendMessage(m.chat, {
text: caption,
contextInfo: {
mentionedJid: [who],
externalAdReply: {
title: "-",
body: "",
mediaType: 1,
thumbnail: thumb,
renderLargerThumbnail: false,
showAdAttribution: false
}
}
}, { quoted: null });
vanzz.autosholat[id] = { timestamp: now };
setTimeout(() => delete vanzz.autosholat[id], 57000);
}
} catch (e) {
console.log("[AUTO SHOLAT ERROR]", e);
}
}
await autoSholat(vanzz, m);

//Switch Command Case
switch (commands) {

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------\\	
// GROUP CASE
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------\\	

case "upswgc": {
if (!isOwner) return 
if (!m.quoted && !text) return m.reply(`*Example:*\n*Reply Media/Album atau tulis teks ${prefix + command}*`)
let msg
if (m.quoted) {
let json = JSON.stringify({ [m.quoted.mtype]: m.quoted }, null, 2)
let parsed = JSON.parse(json)
msg = generateWAMessageFromContent(m.chat, parsed, { quoted: null })
vanzz.relayMessage(m.chat, { groupStatusMessageV2: { message: msg.message }}, {})
} else if (text) {
let parsed = generateWAMessageFromContent(m.chat, { extendedTextMessage: { text }}, { quoted: null })
msg = parsed
vanzz.relayMessage(m.chat, { groupStatusMessageV2: { message: msg.message }}, {})
}
vanzz.sendMessage(m.chat, { text: "*Success Upload Story WhatsApp Group 🚀*" }, { quoted: qtext })
}
break
 
case 'totalfitur': {
if (!isOwner) return
const data = await countAllCommands()
let teks = `📊 *STATISTIK FITUR BOT*\n\n`
teks += `📂 *Total case di handler:* ${data.handler.total}\n`
teks += `📁 *Total handler.command (cmd + subfolder):* ${data.cmd.total}\n`
teks += `🧩 *Total semua fitur:* ${data.totalAll}\n\n`
teks += `📦 *Daftar Case Handler:*\n${data.handler.list.map(c => `• ${c}`).join('\n') || '-'}\n\n`
for (const [category, commands] of Object.entries(data.cmd.grouped)) {
teks += `📁 *${category.toUpperCase()}* (${commands.length})\n${commands.map(c => `• ${c}`).join('\n')}\n\n`
}
vanzreply( m, teks)
}
break

case 'getpp': {
let user;
if (m.quoted) {
user = m.quoted.sender;
} else if (text) {
const mentioned = text.match(/@(\d{5,})/);
if (mentioned) {
user = mentioned[1] + '@s.whatsapp.net';
} else if (text.includes('62')) {
const number = text.replace(/[^0-9]/g, '');
user = number + '@s.whatsapp.net';
} else {
return m.reply('Format salah! Gunakan .getpp @tag atau .getpp 628xx')}
} else {
user = m.quoted ? m.quoted.sender : m.sender; }
try {
let pp = await vanzz.profilePictureUrl(user, 'image');
await vanzz.sendMessage(m.chat, {
image: { url: pp },
caption: `Foto profil dari *@${user.split('@')[0]}*`,
mentions: [user] });
} catch (e) {
m.reply('Gagal mengambil foto profil! Mungkin tidak ada atau disembunyikan.')}}
break

case 'setgroupname': case 'setsubject': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } }) 
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } }) 
if (!text) return vanzreply( m, 'Text ?')
await vanzz.groupUpdateSubject(m.chat, text)
await vanzreply( m, `Sukses Mengubah Nama Grup ☑️`)}
break

case 'setdesk': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '👮‍♂️❌', key: m.key } })
if (!text) return m.reply('Contoh: .setdesc Ini deskripsi baru grup.')
try {
await vanzz.groupUpdateDescription(m.chat, text)
m.reply('Deskripsi grup berhasil diperbarui ✅')
} catch {
m.reply('Gagal mengubah deskripsi!')}}
break

case 'getdesk': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
try {
const metadata = await vanzz.groupMetadata(m.chat)
const desc = metadata.desc || 'Grup ini tidak memiliki deskripsi.'
m.reply(`*Deskripsi Grup:*\n\n${desc}`)
} catch {
m.reply('Gagal mengambil deskripsi grup!')}}
break

case 'setppgroup': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '👮‍♂️❌', key: m.key } })
let media = m.quoted ? m.quoted : m
let mime = (media.msg || media).mimetype || ''
if (!/image\/(jpe?g|png)/.test(mime)) return m.reply('Reply atau kirim gambar dengan caption .setppgroup')
try {
let image = await media.download()
await vanzz.updateProfilePicture(m.chat, image)
m.reply('Foto profil grup berhasil diperbarui ✅')
} catch {
m.reply('Gagal mengubah foto grup! Pastikan gambar valid.')}}
break

case "clid": {
if (!m.isGroup) return
if (!m.sender) return m.reply("🚫 Gagal mendapatkan informasi pengirim.")
const userName = m.pushName || "🙈 Tidak Diketahui"
const senderJid = m.sender
const memberData = groupMembers.find(p => p.jid === senderJid || p.id === senderJid || p.lid === senderJid)
const userLid = memberData?.lid || "— Tidak ditemukan —"
const userJid = memberData?.jid || senderJid
const adminRole = memberData?.admin ? memberData.admin : "anggota"
const [userNumber, serverHost] = userJid.split('@')
if (!userNumber || !serverHost) return m.reply(`⚠️ Format JID tidak valid:\n${senderJid}`)
const mainText = `
╭〔 *INFORMASI PENGGUNA* 〕╮

👤 *Nama*     : ${userName}
📞 *Nomor*    : ${userNumber}
🏷️ *Server*   : ${serverHost}
🆔 *JID*      : ${userJid}
🔖 *LID*      : ${userLid}
⭐ *Status*    : ${adminRole.toUpperCase()}
`
await vanzz.sendMessage(m.chat, { text: mainText }, { quoted: qtext })
}
break

case 'polling': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPolling hanya bisa digunakan di dalam grup 👥`)
if (!args[0]) return m.reply('Contoh penggunaan:\n.poll Judul | Pilihan1 | Pilihan2')
const input = args.join(' ').split('|').map(v => v.trim())
if (input.length < 3) return m.reply('Format salah!\nContoh: .poll Judul | Buka | Tutup')
const [question, ...options] = input
await vanzz.sendMessage(m.chat, { poll: { name: question, values: options, selectableCount: 1 }})}
break

case 'introgc': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
let metadata = await vanzz.groupMetadata(m.chat)
let groupName = metadata.subject
let introText = `👋 Hai Kak, Selamat Datang Di *${groupName}* !

╔◉🌟 𝗜𝗡𝗧𝗥𝗢 𝗚𝗥𝗨𝗣 🌟◉╗
┃ 📛 Nama       : 
┃ 🎂 Umur       : 
┃ 🚻 Gender     : 
┃ ❤️ Status     : 
┃ 🎯 Hobi       : 
┃ 📝 Kata Kata Hari Ini :
╚══

Rules Group Bisa Ketik .getdesk Atau Tanyakan Ke Admin Group Yah😘

> Response By ${global.botname}`
vanzz.sendMessage(m.chat, { text: introText }, { quoted: m })}
break

case "open": case "bukagc": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })	
await vanzz.groupSettingUpdate(m.chat, 'not_announcement')}
break

case "close": case "tutupgc": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })	
await vanzz.groupSettingUpdate(m.chat, 'announcement')}
break

case "del": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!m.quoted) return m.reply("Reply pesan yang ingin dihapus!")
if (m.quoted.fromMe) {
vanzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender }})
} else {
vanzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender }})}}
break

case "joingc": case "joingrup": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!text && !m.quoted) return vanzreply( m, example('linknya'))
let teks = m.quoted ? m.quoted.text : text
if (!teks.includes('whatsapp.com')) return vanzreply( m, "Link Tautan Tidak Valid!")
let result = teks.split('https://chat.whatsapp.com/')[1]
await vanzz.groupAcceptInvite(result)
.then(() => vanzreply( m, "Berhasil Bergabung Ke Dalam Grup ✅"))
.catch(error => reply(error.toString()))}
break

case "leavegc": case "keluargc": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })	
await reply("_Selamat Tinggal Kak👋_")
await sleep(3000)
await vanzz.groupLeave(m.chat)}
break

case "promote": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙋‍♂️', key: m.key } })
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
await vanzz.groupParticipantsUpdate(m.chat, [users], 'promote')
.then(() => m.reply(`Berhasil Menjadikan Admin ☑️`))
.catch(err => m.reply(`Gagal: ${err}`))
}
break

case 'demote': {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vanzz.groupParticipantsUpdate(m.chat, [users], 'demote')
await vanzreply( m, `Berhasil Menurunkan Jabatan Admin Menjadi Member ☑️`)}
break

case "add": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!text && !m.quoted) return m.reply('Masukkan nomor yang ingin ditambahkan ⚡')
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vanzz.groupParticipantsUpdate(m.chat, [users], 'add').catch(console.log)}
break

case "kick": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vanzz.groupParticipantsUpdate(m.chat, [users], 'remove')
.then(() => vanzz.sendMessage(m.chat, { text: `Berhasil Mengeluarkan @${users.split("@")[0]} Dari Grup Ini`, mentions: [users] }, { quoted: m }))
.catch(err => m.reply(err.toString()))
} else return m.reply('Silakan masukkan nomor atau reply pengguna yang akan di kick 🐣')}
break

case "block": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vanzz.updateBlockStatus(users, 'block')}
break

case "unblock": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vanzz.updateBlockStatus(users, 'unblock')}
break

case "totalblock": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
vanzreply( m, `🐦 Total Block: ${banUser.length}`)}
break

case "opentime": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
let timer
if (args[1] == 'second') timer = args[0] * 1000
else if (args[1] == 'minute') timer = args[0] * 60000
else if (args[1] == 'hour') timer = args[0] * 3600000
else if (args[1] == 'day') timer = args[0] * 86400000
else return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
vanzreply( m, `⏳ Grup akan dibuka dalam ${q}...`)
setTimeout(() => {
vanzz.groupSettingUpdate(m.chat, 'not_announcement')
m.reply(`✅ Grup telah dibuka otomatis oleh sistem waktu`)
}, timer)}
break

case "closetime": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
let timer
if (args[1] == 'second') timer = args[0] * 1000
else if (args[1] == 'minute') timer = args[0] * 60000
else if (args[1] == 'hour') timer = args[0] * 3600000
else if (args[1] == 'day') timer = args[0] * 86400000
else return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
vanzreply( m, `⏳ Grup akan ditutup dalam ${q}...`)
setTimeout(() => {
vanzz.groupSettingUpdate(m.chat, 'announcement')
m.reply(`✅ Grup ditutup otomatis oleh sistem waktu`)
}, timer)}
break

case "idgc": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
m.reply(m.chat)}
break

case "infogroup": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
try {
const metadata = await vanzz.groupMetadata(m.chat)
let teks = `*[ INFORMATION GROUP ]*\n\n`
teks += `📌 Name Group: ${metadata.subject}\n`
teks += `🆔 Group ID: ${metadata.id}\n`
teks += `📅 Create At: ${new Date(metadata.creation * 1000).toLocaleString()}\n`
teks += `👑 Owner: ${metadata.owner || '-'}\n`
teks += `🔒 Restrict: ${metadata.restrict}\n`
teks += `📢 Announce: ${metadata.announce}\n`
teks += `📝 Description: ${metadata.desc || '-'}\n\n`
teks += `👥 Participants (${metadata.participants.length}):\n`
for (let a of metadata.participants) {
if (a.admin) teks += `- Admin: @${a.id.split('@')[0]} [${a.admin}]\n`}
return vanzz.sendMessage(m.chat, { text: teks, mentions: metadata.participants.map(p => p.id) }, { quoted: m })
} catch {
m.reply('❌ Gagal mengambil info grup ini')}}
break

case "linkgc": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isBotGroupAdmins) return vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
try {
const inviteCode = await vanzz.groupInviteCode(m.chat)
const groupLink = `https://chat.whatsapp.com/${inviteCode}`
vanzreply( m, `*📍 LINK GROUP ANDA*\n${groupLink}`)
} catch {
vanzreply( m, "❌ Gagal mendapatkan link grup. Pastikan bot adalah admin.")}}
break

case "creategc": case "creategroup": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!args.join(" ")) return vanzreply( m, `*Example :* ${prefix+command} vanzzGroups⚡`)
try {
let cret = await vanzz.groupCreate(args.join(" "), [])
let response = await vanzz.groupInviteCode(cret.id)
let teks = `「 Create Group 」\n\n▸ Name : ${cret.subject}\n▸ Owner : @${cret.owner.split("@")[0]}\n▸ Creation : ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")}\n\nhttps://chat.whatsapp.com/${response}`
vanzz.sendMessage(m.chat, { text: teks, mentions: await vanzz.parseMention(teks)}, { quoted: m })
} catch {
reply("❌ Error!")}}
break

case "cekasalmember": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
const participants = (await vanzz.groupMetadata(m.chat)).participants
let countIndonesia = 0, countMalaysia = 0, countUSA = 0, countOther = 0
participants.forEach(participant => {
const phoneNumber = participant.id.split('@')[0]
if (phoneNumber.startsWith("62")) countIndonesia++
else if (phoneNumber.startsWith("60")) countMalaysia++
else if (phoneNumber.startsWith("1")) countUSA++
else countOther++
})
m.reply(`📊 Jumlah Anggota Grup Berdasarkan Negara:\n\n🇮🇩 Indonesia: ${countIndonesia}\n🇲🇾 Malaysia: ${countMalaysia}\n🇺🇲 USA: ${countUSA}\n🌍 Lainnya: ${countOther}`)}
break

case "pindahmember": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!text) return m.reply('❌ Format Salah!\nContoh: .pindahmember idGrupAsal|idGrupTujuan')
let [fromGroup, toGroup] = text.split('|').map(v => v.trim())
if (!fromGroup || !toGroup) return m.reply('❌ Format Salah!\nContoh: .pindahmember idGrupAsal|idGrupTujuan')
try {
let metadata = await vanzz.groupMetadata(fromGroup)
let targetGroup = await vanzz.groupMetadata(toGroup)
if (!targetGroup.participants.find(p => p.id == vanzz.user.id || p.id == vanzz.decodeJid(vanzz.user.id)))
return m.reply('❌ Bot harus jadi admin di grup tujuan!')
let peserta = metadata.participants.map(v => v.id)
let sudah = targetGroup.participants.map(u => u.id)
let belum = peserta.filter(x => !sudah.includes(x))
let total = belum.length
let batchSize = 15
let jedaBatch = 400 * 60 * 10 // 10 menit
m.reply(`🚀 Mulai Culik Aman\n📊 Total Target: ${total}\n📦 Limit per batch: ${batchSize}\n⏳ Jeda: 10 menit`)
for (let i = 0; i < belum.length; i += batchSize) {
let batch = belum.slice(i, i + batchSize)
for (let user of batch) {
try {
await delay(Math.floor(Math.random() * 3000) + 3000)
await vanzz.groupParticipantsUpdate(toGroup, [user], 'add')
} catch (e) {
console.log(`❌ Gagal add ${user} → ${e.message}`)}}
let progress = Math.floor(((i + batch.length) / total) * 100)
await vanzz.sendMessage(m.chat, { text: `✅ Progress: ${progress}% selesai...` })
if (i + batchSize < belum.length) await delay(jedaBatch)} 
m.reply('✅ Semua target sudah diproses!')}
catch (e) {
console.log(e)
m.reply('❌ Gagal proses.\nPastikan ID grup benar dan bot adalah admin di grup tujuan.')}}
break

case "ht": case "hidetag": {
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
let teks = args.join(" ").trim() || " "
let metadata = await vanzz.groupMetadata(m.chat)
let member = metadata.participants.map(u => u.id)
vanzz.sendMessage(m.chat, { text: teks, mentions: member }, { quoted: null })}
break

case "spamtag": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
if (!m.mentionedJid[0]) return vanzreply( m, '_Tag orang yang akan di spam!!\n\nExample: .spamtag @tag | 22_')
const [orang, amountStr] = text.split("|").map(item => item.trim())
const amount = parseInt(amountStr, 10)
if (isNaN(amount) || amount <= 0) return vanzreply( m, '_Jumlah harus berupa angka positif⚠️_')
for (let i = 0; i < amount; i++) {
vanzz.sendMessage(m.chat, { text: orang, mentions: [m.mentionedJid[0]] })
await sleep(500)}}
break

case "tagall": {
if (!isGroup) return m.reply(`❌ *Fitur Khusus Grup*\nPerintah ini hanya bisa digunakan di dalam grup 👥`)
if (!isOwner) return vanzz.sendMessage(m.chat, { react: { text: '🙅‍♂️', key: m.key } })
const me = m.sender
let teks = `╚»˙·٠🪀●♥ Tag All ♥●🪀٠·˙«╝

😶 *Tagger:*  @${me.split('@')[0]}
🌿 *Message:* ${q ? q : 'no message'}\n\n`
for (let mem of participants) teks += `🪀 @${mem.id.split('@')[0]}\n`
vanzz.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: fcall })}
break

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------\\	
//END GROUP
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------\\	










//-------------------------------------------------------------------------------------------------------------------------------------------------------------------\\	

default:
}
} catch (err) {
m.reply(util.format(err));
}
};

let file = fileURLToPath(import.meta.url);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.greenBright(` ~> ♻️ File updated: ${file}`));
process.exit();
});