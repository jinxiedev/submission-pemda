import fs from 'fs'
import '../settings/config.js'

const replyimg = fs.readFileSync('./source/thumbnail/replyimg.jpg')

export const vanzreply = async (m, teks) => {
return vanzz.sendMessage(m.chat, {
text: teks,
mentions: [m.sender],
contextInfo: {
isForwarded: false,
forwardingScore: 9999,
businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" },
forwardedNewsletterMessageInfo: { newsletterName: `${namebotz}`, newsletterJid: global.Telegram },
externalAdReply: {
title: namebotz,
body: `√ ${nameown}`,
thumbnail: replyimg,
sourceUrl: null
}
}
}, { quoted: null })
} 