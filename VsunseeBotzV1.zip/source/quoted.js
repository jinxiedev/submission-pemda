import fs from 'fs'

export const qtext = {
key: {
fromMe: false,
participant: "0@s.whatsapp.net",
remoteJid: "120363400662819774@g.us"
},
message: {
stickerPackMessage: {
stickerPackId: " ",
name: "Sticker Pack",
publisher: `—!s\`Vanz Ryuichi🫀`
}
}
};
