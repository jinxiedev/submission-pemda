import fs from "fs";
import path from "path";
import chalk from "chalk";
import { fileURLToPath, pathToFileURL } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const pluginsLoader = async (directory) => {
let plugins = [];
const loadPlugins = async () => {
plugins = [];
const entries = fs.readdirSync(directory, { withFileTypes: true });
for (const entry of entries) {
const fullPath = path.join(directory, entry.name);
if (entry.isDirectory()) {
const subFiles = fs.readdirSync(fullPath);
for (const sub of subFiles) {
const subPath = path.join(fullPath, sub);
if (sub.endsWith(".js")) {
try {
const fileUrl = pathToFileURL(subPath).href;
const modKey = Object.keys(import.meta.resolve ? import.meta.resolve : {}).find(k => k.includes(fileUrl));
if (modKey) delete import.meta.resolve[modKey];
const pluginModule = await import(`${fileUrl}?update=${Date.now()}`);
pluginModule.default.filename = sub;
plugins.push(pluginModule.default);
} catch (e) {
console.log(chalk.red(`Gagal memuat ${subPath}:`), e);
}
}
}
} else if (entry.isFile() && entry.name.endsWith(".js")) {
try {
const fileUrl = pathToFileURL(fullPath).href;
const pluginModule = await import(`${fileUrl}?update=${Date.now()}`);
pluginModule.default.filename = entry.name;
plugins.push(pluginModule.default);
} catch (e) {
console.log(chalk.red(`Gagal memuat ${fullPath}:`), e);
}
}
}
};
await loadPlugins();
fs.watch(directory, { recursive: true }, async (event, filename) => {
if (filename && filename.endsWith(".js")) {
console.log(chalk.yellow(`🔁 Plugin ${filename} Updates🔖`));
await loadPlugins();
}
});
return plugins;
};

export const runPlugins = async (m, plug) => {
const pluginsDisable = false;
if (pluginsDisable) return false;
const plugins = await pluginsLoader(path.resolve(__dirname, "./cmd"));
for (let plugin of plugins) {
if (plugin.command && plugin.command.find(e => e === plug.command.toLowerCase())) {
if (typeof plugin !== "function") continue;

const configPath = path.join(__dirname, "settings", "config.js");
try {
await import(`${pathToFileURL(configPath)}?update=${Date.now()}`);
} catch (err) {
console.log(chalk.red("Gagal memuat config.js:"), err);
}

const sender = m.sender.split("@")[0];
const ownerList = Array.isArray(global.owner)
? global.owner.join(",").split(",").map(v => v.trim())
: (global.owner || "").split(",").map(v => v.trim());
const dbOwners = (global.db?.owners || []).map(v => v.trim());

const isOwner = (
ownerList.includes(sender) ||
dbOwners.includes(sender) ||
m.key.fromMe
);

if (plugin.owner && !isOwner) {
await m.reply("Maaf, perintah ini hanya untuk Owner.");
return true;
}

const premiumPath = path.join(process.cwd(), "source", "database", "premium.json")
let premiumUsers = []
if (fs.existsSync(premiumPath)) {
  try { premiumUsers = JSON.parse(fs.readFileSync(premiumPath)) } catch {}
}

if (plugin.premium) {
  const userId = m.sender.replace(/[^0-9]/g, "")
  if (!premiumUsers.includes(userId)) {
    await m.reply("⚠️ Fitur ini hanya untuk *User Premium!* 🚀\nKetik *.owner* untuk membeli akses.")
    return true
  }
}

let user = global.db.users[plug.sender];
const limitCost = plugin.limit || 0;
if (!isOwner && user.limit < limitCost) {
await m.reply(
`Maaf, limit Anda tidak cukup untuk menggunakan perintah ini.\n` +
`💰 Limit Anda: ${user.limit}\n🔋 Diperlukan: ${limitCost}`
);
return true;
}

try {
plug.user = user;
await plugin(m, plug);
if (limitCost > 0 && !isOwner) {
user.limit -= limitCost;
console.log(`Mengurangi ${limitCost} limit dari ${plug.pushName}`);
await new Promise(resolve => setTimeout(resolve, 5000));
await m.reply(`-${limitCost} Limit Terpakai.\nSisa limit Anda sekarang: ${user.limit}`);
}
return true;
} catch (error) {
console.log(chalk.red("Error saat menjalankan plugin:"), error);
return true;
}
}
}
return false;
};

let file = fileURLToPath(import.meta.url);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.greenBright(` ~> ♻️ File updated: ${file}`));
process.exit();
});