import fs from "fs";
import chalk from "chalk";

global.owner = ["173426987819031,6288276746473,173426987821031,51531588046893"];
global.NumberBot = ['51531588046893@lid', '173426987819031@lid,51531588046893@lid'];

global.mode = false; // Private False
global.autoclsession = true // Clear Sessions

global.modesend = 'button'; //Cmd
global.menuStyle = 'button'; //Menu

global.namebotz = "ᴠꜱᴜɴꜱᴇᴇ ʙᴏᴛᴢ 🔖";
global.packname = '🔖 ᴠꜱᴜɴꜱᴇᴇ ʙᴏᴛᴢ — ʙʏ ᴠᴀɴᴢʀʏᴜɪᴄʜɪ';
global.nameown = "— ᴠᴀɴᴢ ʀʏᴜɪᴄʜɪ";
global.author = 'ᴠᴀɴᴢ ʀʏᴜɪᴄʜɪ';
global.footer = "🔖 ᴠꜱᴜɴꜱᴇᴇ ʙᴏᴛᴢ";

global.YouTube = "https://youtube.com/@vannzzstore?si=LwnA-Qm0IiocHsis";
global.GitHub = "https://github.com/Vanxzofc";
global.Telegram = "https://t.me/vanzryuichi";
global.Wa = "https://wa.me/6288276746473";
global.ChannelWA = "https://whatsapp.com/channel/0029VbBS8on9cDDVHaTqil0k";
global.ChannelID = "120363420426577837@newsletter";
global.GroupWa = "https://chat.whatsapp.com/D6ZkmV5xPqx18wp68gAJOZ?mode=wwt";
global.GroupID = "120363419077105196@g.us";

global.VsunseeApi = "apiz.vsunsee.click";
global.VsunseeApikey = "VsunseeXVANZ";

global.apikeycf = "ApikeyCloudflareLu";
global.emailcf = "EmailCloudflarelu@gmail.com";

global.domain = 'https://pterodactyl.vsunsee.sbs';
global.apikey = 'ptla_BWdztH0XjcHmlOZkjSJ39qT9Z2Rdjb1uz1naAdvWj5e';
global.capikey = 'ptlc_G1IVE8O4OjVGiseilPLzhZW8CU1o4FOUPOfAbcjeUIl';
