import fs from "fs";
import chalk from "chalk";

global.AvatarUrl = 'https://i.top4top.io/p_3596k6j3f1.jpg';
global.ThumbnailUrl = 'https://d.top4top.io/p_3596faxpp1.jpg';

//Sticker
global.StickerReply = 'https://e.top4top.io/p_3596eqssr1.jpg';

//Cmd/Pterodactyl
global.ThumbPterodactyl = 'https://files.catbox.moe/nigm5a.jpeg';

//Cmd/News
global.ThumbNews = 'https://files.catbox.moe/7bjihb.jpeg';

//Cmd/Check
global.ThumbCheck = 'https://files.catbox.moe/d2f0fk.jpg';

//Cmd/Subdomain
global.ThumbSubdo = 'https://files.catbox.moe/il6qou.png';

//Cmd/Downloader
global.gdrive = 'https://files.catbox.moe/c2t3ne.jpeg';
global.github = 'https://files.catbox.moe/kcl5mt.jpeg';
global.mediafire = 'https://files.catbox.moe/r7gtgr.png';
global.npm = 'https://files.catbox.moe/svxk4w.png';
global.sfile = 'https://files.catbox.moe/6aji39.png';
global.tiktok = 'https://files.catbox.moe/6vjutl.jpg';