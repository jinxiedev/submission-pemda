import "./settings/config.js";
import "./settings/thumb.js";
import { makeWASocket, useMultiFileAuthState, jidDecode, getContentType, DisconnectReason, Browsers, downloadContentFromMessage, fetchLatestWaWebVersion } from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import path from "path";
import pino from "pino";
import readline from "readline";
import chalk from "chalk";
import fs from "fs-extra";
import NodeCache from "node-cache";
import { fileTypeFromBuffer } from "file-type";
import axios from "axios";
import { Jimp } from "jimp";
import { runPlugins } from "./handler.js";
import handleMessage from "./source/message.js";
import { fileURLToPath } from "url";
import { smsg } from "./source/myfunc.js";
import "./source/myfunc.js";
import { writeExifImg, writeExifVid, imageToWebp, videoToWebp } from "./source/events/exif.js";

global.mode = true;
global.sessionName = "session";
const pairingCode = process.argv.includes("pair");

if (!pairingCode) {
console.log(chalk.redBright("command work ( node index.js pair"));
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout,
});
const question = (text) => new Promise((resolve) => rl.question(text, resolve));
const msgRetryCounterCache = new NodeCache();


function autoClearSession() {
if (!global.autoclsession) return
const sessionDir = `./${global.sessionName}`
const interval = 1 * 60 * 60 * 1000 
const cleanSession = () => {
try {
if (!fs.existsSync(sessionDir)) return
if (!global.vanzz?.ws || global.vanzz.ws.readyState !== 1) return
const files = fs.readdirSync(sessionDir)
const keep = ["creds.json", "auth_info.json"]
const trash = files.filter(f =>
(f.startsWith("pre-key") || f.startsWith("sender-key") || f.startsWith("session-") || f.startsWith("app-state")) &&
!keep.includes(f)
)
if (trash.length > 0) {
trash.forEach(f => fs.unlinkSync(path.join(sessionDir, f)))
console.log(chalk.green(`🧹 AutoClean: ${trash.length} session file(s) deleted.`))
}
} catch (e) {
console.log(chalk.red(`❌ AutoClean Error: ${e.message}`))
}
}
setInterval(cleanSession, interval)
cleanSession()
}
if (global.autoclsession) autoClearSession()

//Buffer
const getBuffer = async (url, options) => {
try {
options = options || {};
const res = await axios({
method: "get",
url,
headers: {
"DNT": 1,
"Upgrade-Insecure-Request": 1,
},
...options,
responseType: "arraybuffer",
});
return res.data;
  } catch (e) {
console.log(`Error : ${e}`);
return null;
}
};

//resize
const resize = async (imagePathOrUrl, width, height) => {
try {
let imageBuffer;
if (/^https?:\/\//.test(imagePathOrUrl)) {
const response = await axios.get(imagePathOrUrl, { responseType: "arraybuffer" });
imageBuffer = response.data;
} else {
const absolutePath = path.resolve(imagePathOrUrl); // Pastikan path absolut
if (!fs.existsSync(absolutePath)) {
console.log(`File not found: ${absolutePath}`);
return null;
}
imageBuffer = await fs.readFile(absolutePath);
}
const read = await Jimp.read(imageBuffer);
const data = await read.resize(width, height).getBufferAsync(Jimp.MIME_JPEG);
return data;
  } catch (e) {
console.error(`Resize error: ${e.message}`);
return null;
}
};

//Connection
async function startServer() {
const child = async () => {
process.on("unhandledRejection", (err) => console.error(err));
const { state, saveCreds } = await useMultiFileAuthState("./" + sessionName);
const { version: waVersionLocal } = await fetchLatestWaWebVersion().catch(() => ({ version: [2, 3000, 1027934701] }));

const vanzz = makeWASocket({
printQRInTerminal: !pairingCode,
logger: pino({
level: "silent", }),
version: waVersionLocal,
browser: ["Ubuntu", "Chrome", "120.0.0"], 
auth: state,
msgRetryCounterCache,
connectTimeoutMs: 60000,
defaultQueryTimeoutMs: 0,
keepAliveIntervalMs: 10000,
emitOwnEvents: true,
fireInitQueries: true,
generateHighQualityLinkPreview: true,
syncFullHistory: false, 
markOnlineOnConnect: true,
});
global.vanzz = vanzz;
vanzz.ev.on("creds.update", saveCreds);

//Input Number
    if (!vanzz.authState.creds.registered) {
      console.log(chalk.cyan("â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€Â·Â·Â·"));
      console.log(`ðŸ“¨ ${chalk.redBright("Please type your WhatsApp number")}:`);
      console.log(chalk.cyan("â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€Â·Â·Â·"));
      let phoneNumber = await question(`   ${chalk.cyan("- Number")}: `);
      console.log(chalk.cyan("â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€Â·Â·Â·"));
      phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

      try {
        let code = await vanzz.requestPairingCode(phoneNumber);
        code = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.cyan("â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€Â·Â·Â·"));
        console.log(` ðŸ’» ${chalk.redBright("Your Pairing Code")}:`);
        console.log(chalk.cyan("â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€Â·Â·Â·"));
        console.log(`   ${chalk.cyan("- Code")}: ${code}`);
        console.log(chalk.cyan("â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€Â·Â·Â·"));
      } catch (err) {
        console.error(chalk.redBright(`❌ Gagal mendapatkan pairing code!`), err);
      }
      rl.close();
    }


//Message Upsert
vanzz.ev.on("messages.upsert", async (chatUpdate) => {
try {
let m = chatUpdate.messages[0];
if (!m.message) return;
m.message =
Object.keys(m.message)[0] === "ephemeralMessage"
? m.message.ephemeralMessage.message
: m.message;
if (m.key && m.key.remoteJid === "status@broadcast") return;
if (!vanzz.public && !m.key.fromMe && chatUpdate.type === "notify")
return;
if (m.key.id.startsWith("BAE5") && m.key.id.length === 16) return;
m = smsg(vanzz, m);
handleMessage(vanzz, m, chatUpdate);
} catch (err) {
console.error(chalk.red("[ERROR] Gagal memproses pesan:"), err);
}
});

vanzz.decodeJid = (jid) => {
if (!jid) return jid;
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {};
return (
(decode.user && decode.server && decode.user + "@" + decode.server) ||
jid
);
} else return jid;
};

vanzz.public = mode;
vanzz.serializeM = (m) => smsg(vanzz, m);

//Connection Handle
vanzz.ev.on("connection.update", async update => {
const { connection, lastDisconnect } = update
const reason = new Boom(lastDisconnect?.error)?.output?.statusCode
if (connection === "connecting") console.log(chalk.yellow("🔄 Menghubungkan ke WhatsApp..."))
if (connection === "open") console.log(chalk.black(chalk.bgWhite("✅ Terhubung ke WhatsApp!"))) 
if (connection === "close") {
console.log(chalk.red(`❌ Koneksi terputus (${reason || "unknown"})`))
if (reason === DisconnectReason.loggedOut) {
console.log(chalk.redBright("🚫 Sesi invalid, hapus folder session dan scan ulang."))
process.exit()
}
if (
reason === DisconnectReason.badSession ||
reason === DisconnectReason.connectionClosed ||
reason === DisconnectReason.connectionLost ||
reason === DisconnectReason.restartRequired ||
reason === DisconnectReason.timedOut ||
!reason
) {
console.log(chalk.yellow("⚠️ Mencoba reconnect otomatis dalam 5 detik..."))
await new Promise(r => setTimeout(r, 5000))
startServer()
} else {
console.log(chalk.red("🔁 Gagal Koneksi Ke Whatsapp, Restart Bot..."))
process.exit()
}
}
setTimeout(() => {
if (!global.vanzz?.ws?.isOpen) {
console.log(chalk.yellow("⚠️ Status koneksi tidak diketahui > 1 menit, restart bot..."))
process.exit()
}
}, 60000)
})

// Send Button Func
vanzz.sendButton = async (jid, text, footer, btnklick, image1, image2, buttons, quoted, options) => {
const message = {
footer: footer,
headerType: 1,
viewOnce: true,
image: { url: image1 },
caption: text,
buttons: [
  {
buttonId: "action",
buttonText: { displayText: "Pilih Opsi" },
type: 4,
nativeFlowInfo: {
  name: "single_select",
  paramsJson: JSON.stringify({
title: btnklick,
sections: [
  {
title: "MENU UTAMA",
rows: buttons.map((btn) => ({
  title: btn.title,
  description: btn.description || "",
  id: btn.id,
})),
},
],
}),
},
},
],
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [quoted.sender],
forwardedNewsletterMessageInfo: {
newsletterName: global.nameown,
newsletterJid: global.ChannelID,
},
externalAdReply: {
title: global.namebotz,
body: global.nameown,
thumbnailUrl: image1,
sourceUrl: global.ChannelWA,
mediaType: 1,
renderLargerThumbnail: false,
},
},
...options,
};
return await vanzz.sendMessage(jid, message, { quoted });
};

//downloadAndSaveMediaMessage
vanzz.downloadAndSaveMediaMessage = async (
message,
filename,
attachExtension = true
) => {
let quoted = message.msg ? message.msg : message;
let mime = (message.msg || message).mimetype || "";
let messageType = message.mtype
? message.mtype.replace(/Message/gi, "")
: mime.split("/")[0];
const stream = await downloadContentFromMessage(quoted, messageType);
let buffer = Buffer.from([]);
for await (const chunk of stream) {
buffer = Buffer.concat([buffer, chunk]);
}
let type = await fileTypeFromBuffer(buffer);
let trueFileName = attachExtension ? filename + "." + type.ext : filename;
await fs.writeFileSync(trueFileName, buffer);
return trueFileName;
};

//downloadMediaMessage
vanzz.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || "";
let messageType = message.mtype
? message.mtype.replace(/Message/gi, "")
: mime.split("/")[0];
const stream = await downloadContentFromMessage(message, messageType);
let buffer = Buffer.from([]);
for await (const chunk of stream) {
buffer = Buffer.concat([buffer, chunk]);
}
return buffer;
};

//Send Text
vanzz.sendText = (jid, teks, quoted = "", options) => {
return vanzz.sendMessage(
jid,
{ text: teks, ...options },
{ quoted, ...options }
);
};

//Send Image
vanzz.sendImage = async (jid, path, caption = "", quoted = "", options) => {
let buffer = Buffer.isBuffer(path)
? path
: /^data:.*?\/.*?;base64,/i.test(path)
? Buffer.from(path.split(",")[1], "base64")
: /^https?:\/\//.test(path)
? await getBuffer(path)
: fs.existsSync(path)
? fs.readFileSync(path)
: Buffer.alloc(0);
  return await vanzz.sendMessage(
jid,
{ image: buffer, caption: caption, jpegThumbnail: "", ...options },
{ quoted }
);
};

//SendVideo
vanzz.sendVideo = async (jid, path, caption = "", quoted = "", gif = false, options) => {
let buffer = Buffer.isBuffer(path)
? path
: /^data:.*?\/.*?;base64,/i.test(path)
? Buffer.from(path.split(",")[1], "base64")
: /^https?:\/\//.test(path)
? await getBuffer(path)
: fs.existsSync(path)
? fs.readFileSync(path)
: Buffer.alloc(0);
  return await vanzz.sendMessage(
jid,
{ video: buffer, caption: caption, gifPlayback: gif, jpegThumbnail: "", ...options },
{ quoted }
);
};

//SendAudio
vanzz.sendAudio = async (jid, path, quoted = "", ptt = false, options) => {
let buffer = Buffer.isBuffer(path)
? path
: /^data:.*?\/.*?;base64,/i.test(path)
? Buffer.from(path.split(",")[1], "base64")
: /^https?:\/\//.test(path)
? await getBuffer(path)
: fs.existsSync(path)
? fs.readFileSync(path)
: Buffer.alloc(0);
  return await vanzz.sendMessage(
jid,
{ audio: buffer, ptt: ptt, ...options },
{ quoted }
);
};

//sendImageAsSticker
vanzz.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff
if (Buffer.isBuffer(path)) buff = path
else if (/^data:.*?\/.*?;base64,/i.test(path)) buff = Buffer.from(path.split(',')[1], 'base64')
else if (/^https?:\/\//.test(path)) buff = await (await getBuffer(path))
else if (fs.existsSync(path)) buff = fs.readFileSync(path)
else buff = Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
const webpBuffer = fs.existsSync(buffer) ? fs.readFileSync(buffer) : buffer
await vanzz.sendMessage(jid, { sticker: webpBuffer }, { quoted })
try {
if (fs.existsSync(buffer)) fs.unlinkSync(buffer)
} catch {}
return true
}

//sendVideoAsSticker
vanzz.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff
if (Buffer.isBuffer(path)) buff = path
else if (/^data:.*?\/.*?;base64,/i.test(path)) buff = Buffer.from(path.split(',')[1], 'base64')
else if (/^https?:\/\//.test(path)) buff = await (await getBuffer(path))
else if (fs.existsSync(path)) buff = fs.readFileSync(path)
else buff = Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
const webpBuffer = fs.existsSync(buffer) ? fs.readFileSync(buffer) : buffer
await vanzz.sendMessage(jid, { sticker: webpBuffer }, { quoted })
try {
if (fs.existsSync(buffer)) fs.unlinkSync(buffer)
} catch {}
return true
}

//sendButtonRelay
vanzz.sendButtonRelay = async (jid, text, buttons, quoted) => {
const thumbnailPath = "./source/thumbnail/image.jpg";
let thumbnail = await resize(thumbnailPath, 300, 300);
if (!thumbnail) {
console.error("Failed to resize thumbnail, using default or skipping...");
thumbnail = await getBuffer("https://raw.githubusercontent.com/balxz/akuuu-muaakk/refs/heads/main/New%20Project%203%20%5B0C67D63%5D.png");
}
const message = {
viewOnceMessage: {
message: {
interactiveMessage: {
header: {
locationMessage: {
degreesLatitude: -9999999999,
degreesLongitude: -8888888888,
name: global.namebotz,
address: global.nameown,
jpegThumbnail: thumbnail,
},
hasMediaAttachment: true,
},
body: { text: text },
nativeFlowMessage: {
buttons: buttons,
messageParamsJson: JSON.stringify({
limited_time_offer: {
text: "t.me/VanzRyuichi",
url: "t.me/VanzRyuichi",
copy_code: "99999999",
expiration_time: Date.now() * 999,
},
bottom_sheet: {
in_thread_buttons_limit: 2,
divider_indices: [1, 2, 3, 4, 5, 999],
list_title: "VanzRyuichi",
button_title: "VanzRyuichi",
},
tap_target_configuration: {
title: " X ",
description: "bomboclard",
canonical_url: "https://t.me/VanzRyuichi",
domain: "apiz.vsunsee.us.kg",
button_index: 0,
  },
}),
},
},
},
},
};
return await vanzz.relayMessage(jid, message, { quoted });
};

return vanzz;
};

child().catch((err) => console.log(err));
}

startServer();

let file = fileURLToPath(import.meta.url);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.greenBright(` ~> ♻️ File updated: ${file}`));
process.exit();
});
