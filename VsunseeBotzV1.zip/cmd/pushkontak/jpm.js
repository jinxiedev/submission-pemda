import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text }) => {
try {
await vanzz.sendMessage(m.chat, { react: { text: "📢", key: m.key } })
if (!text) return vanzreply(m, "⚠️ Masukkan pesan!\nContoh: *.jpm Halo semua!*")
const groups = await vanzz.groupFetchAllParticipating()
const groupList = Object.values(groups)
if (!groupList.length) return vanzreply(m, "❌ Tidak ada grup yang terdeteksi di akun bot ini.")
await vanzreply(m, `📢 Mengirim Pesan Ke *${groupList.length}* Grup\nPesan: _${text}_`)
let successCount = 0
for (let group of groupList) {
try {
await vanzz.sendMessage(group.id, { text }, { quoted: qtext })
successCount++
console.log(`📩 Pesan Terkirim Ke Grup: ${group.subject}`)
await new Promise((r) => setTimeout(r, 5000))
} catch (err) {
console.log(`❌ Gagal kirim ke grup: ${group.subject}`)
}
}
await vanzreply(m, `Berhasil Mengirim Pesan Ke *${successCount}/${groupList.length}* Grup ☑️`)
await vanzz.sendMessage(m.chat, { react: { text: "☑️", key: m.key } })
} catch (error) {
console.error("Error saat JPM:", error)
await vanzreply(m, "❌ Gagal mengirim pesan ke semua grup.")
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
}
}

handler.help = ["Join Push Message"]
handler.tags = ["push"]
handler.command = ["jpm"]
handler.owner = true

export default handler