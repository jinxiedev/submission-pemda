import fs from "fs"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text }) => {
try {
await vanzz.sendMessage(m.chat, { react: { text: "📨", key: m.key } })

let [pesan, groupId, jeda] = text.split("|")
if (!pesan || !groupId || !jeda)
return vanzreply(m, "⚠️ Format salah!\nGunakan: *.pushkontak teks|idgrup|jeda*\n\nContoh:\n*.pushkontak Halo|120xxxxx@g.us|6000*")

let groupMetadata = await vanzz.groupMetadata(groupId).catch(() => null)
if (!groupMetadata)
return vanzreply(m, "❌ Grup tidak ditemukan atau bot bukan admin di grup tersebut.")

let members = groupMetadata.participants.map(p => p.id.replace(/@.*/, ""))
if (!members.length) return vanzreply(m, "❌ Tidak ada anggota di grup ini.")

let delayTime = parseInt(jeda)
await vanzreply(m, `📢 Mengirim pesan ke ${members.length} anggota grup *${groupMetadata.subject}* dengan jeda ${delayTime}ms per kontak.`)

// kirim pesan ke tiap anggota
for (let num of members) {
await vanzz.sendMessage(`${num}@s.whatsapp.net`, { text: pesan }, { quoted: qtext })
console.log(`📩 Pesan terkirim ke ${num}`)
await new Promise(r => setTimeout(r, delayTime))
}

// buat nama acak + isi vCard
let randomNum = Math.floor(Math.random() * 900 + 100) // hasil: 100–999
let vcfData = members.map(num => 
`BEGIN:VCARD
VERSION:3.0
FN:Kontak Vanz Random #${randomNum}
TEL;TYPE=CELL:+${num}
END:VCARD`
).join("\n")

// simpan & kirim file vcf
let fileName = `Kontak_Vanz_Random_${randomNum}.vcf`
fs.writeFileSync(fileName, vcfData)

await vanzz.sendMessage(m.chat, {
document: fs.readFileSync(fileName),
mimetype: "text/vcard",
fileName: fileName,
caption: `📇 Daftar kontak berhasil dibuat!\nNama: *Kontak Vanz Random #${randomNum}*`
}, { quoted: m })

await vanzreply(m, `✅ Push pesan selesai dan file kontak berhasil dikirim!`)
await vanzz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
} catch (error) {
console.error("Error saat push kontak:", error)
await vanzreply(m, "❌ Gagal mengirim pesan atau membuat kontak.")
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
}
}

handler.help = ["Push Kontak Group"]
handler.tags = ["push"]
handler.command = ["pushkontak"]
handler.owner = true

export default handler