import axios from 'axios'

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!text||!text.includes('|'))
return m.reply(`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} Nickname|Versi\n\n📍 Contoh:\n${prefix+command} VannRyuichiboy|1`)
const[nickname,versi]=text.split('|').map(a=>a.trim())
if(!nickname)return m.reply('❌ Harap isi nickname kamu!')
if(nickname.length>12)return m.reply('❌ Nickname maksimal 12 karakter!')
if(!versi||isNaN(versi)||versi<1||versi>11)return m.reply('❌ Versi hanya boleh dari 1 sampai 11!')
await vanzz.sendMessage(m.chat,{react:{text:'✨',key:m.key}})
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/lobbyff?apikey=${global.VsunseeApikey}&nickname=${encodeURIComponent(nickname)}&versi=${encodeURIComponent(versi)}`
const res=await axios.get(apiUrl,{responseType:'arraybuffer'})
await vanzz.sendMessage(m.chat,{image:Buffer.from(res.data),caption:`🎮 *Loby Free Fire*\n👤 Nickname: ${nickname}\n🧩 Versi: ${versi}`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('FAKEFF ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Fake Lobby Free Fire']
handler.tags=['maker']
handler.command=['fakeff']

export default handler