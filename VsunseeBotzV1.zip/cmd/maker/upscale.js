import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'

let handler = async (m, { vanzz, prefix, command }) => {
try{
let q = m.quoted ? m.quoted : (m.message?.imageMessage ? m : null)
let mime = (q.msg || q).mimetype || ''
if(!/image/.test(mime))
return m.reply(`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption:\n${prefix+command}\n\n📍 Contoh:\n• Kirim gambar dengan caption: ${prefix+command}\n• Atau reply gambar lalu ketik: ${prefix+command}`)
await vanzz.sendMessage(m.chat,{react:{text:'📤',key:m.key}})
let media = await vanzz.downloadAndSaveMediaMessage(q)
const cdn = await upload({ path: media })
const cdnUrl = cdn[0]?.url
if(!cdnUrl) throw new Error('URL CDN tidak valid.')
await vanzz.sendMessage(m.chat,{react:{text:'🪄',key:m.key}})
const result = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/upscale?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(cdnUrl)}`,{responseType:'arraybuffer'})
if(!result.data||result.data.length<100){
if(fs.existsSync(media))fs.unlinkSync(media)
return m.reply('❌ Gagal memproses gambar.')
}
await vanzz.sendMessage(m.chat,{image:Buffer.from(result.data),caption:`🧩 *Upscale Selesai*\n\n📸 *Resolusi gambar berhasil ditingkatkan!*`},{quoted:m})
if(fs.existsSync(media))fs.unlinkSync(media)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('UPSCALE ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help = ['Upscale HD Image']
handler.tags = ['maker']
handler.command = ['upscale','hd']

export default handler