import fetch from 'node-fetch'

let handler = async (m, { vanzz, text, author }) => {
if (!text) return vanzz.sendMessage(m.chat, { text: `Contoh: .brat vanzz Ryuichi` }, { quoted: m })
if (text.length > 250) return vanzz.sendMessage(m.chat, { text: `Karakter terbatas, maksimal 250!` }, { quoted: m })
await vanzz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })
try {
const res = await fetch(`https://${global.VsunseeApi}/vsunseeV8/brat?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`)
if (!res.ok) throw new Error('Gagal mengambil gambar dari API.')
const buffer = Buffer.from(await res.arrayBuffer())
await vanzz.sendImageAsSticker(m.chat, buffer, m, { packname: 'Brat Maker', author })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error(e)
await vanzz.sendMessage(m.chat, { text: `❌ Terjadi kesalahan:\n${e.message}` }, { quoted: m })
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Sticker From Text']
handler.tags = ['maker']
handler.command = ['brat']

export default handler