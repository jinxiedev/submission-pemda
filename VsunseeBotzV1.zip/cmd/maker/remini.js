import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'

let handler = async (m, { vanzz, prefix, command }) => {
try{
let q = m.quoted ? m.quoted : (m.message?.imageMessage ? m : null)
let mime = (q.msg || q).mimetype || ''
if(!/image/.test(mime))
return m.reply(`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption:\n${prefix+command}\n\n📍 Contoh:\n• Kirim gambar dengan caption: ${prefix+command}\n• Atau reply gambar lalu ketik: ${prefix+command}`)
await vanzz.sendMessage(m.chat,{react:{text:'📤',key:m.key}})
let media = await vanzz.downloadAndSaveMediaMessage(q)
const cdn = await upload({ path: media })
const cdnUrl = cdn[0]?.url
if(!cdnUrl) throw new Error('URL CDN tidak valid.')
await vanzz.sendMessage(m.chat,{react:{text:'🪄',key:m.key}})
const apiUrl = `https://${global.VsunseeApi}/vsunseeV8/remini?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(cdnUrl)}`
const result = await axios.get(apiUrl)
if(!result.data.status || !result.data.result?.original){
if(fs.existsSync(media)) fs.unlinkSync(media)
return m.reply('❌ Gagal memproses gambar.')
}
const enhanced = await axios.get(result.data.result.original, { responseType:'arraybuffer' })
await vanzz.sendMessage(m.chat, { 
image: Buffer.from(enhanced.data),
caption: `_✨ *Remini Image Enhancer_*\n`
}, { quoted:m })
if(fs.existsSync(media)) fs.unlinkSync(media)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('REMINI ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help = ['Remini Enhancer']
handler.tags = ['maker']
handler.command = ['remini']

export default handler