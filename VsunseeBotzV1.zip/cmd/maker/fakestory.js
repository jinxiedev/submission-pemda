import fs from 'fs'
import axios from 'axios'
import request from 'request'
import * as cheerio from 'cheerio'
import { fileTypeFromBuffer } from 'file-type'
import "../../settings/config.js"

async function uploadTop4Top(filePath){
try{
const buffer=fs.readFileSync(filePath)
const {ext}=(await fileTypeFromBuffer(buffer))||{ext:'bin'}
return new Promise((resolve,reject)=>{
const req=request({
url:'https://top4top.io/index.php',
method:'POST',
headers:{
'User-Agent':'Mozilla/5.0',
'accept':'*/*',
'content-type':'multipart/form-data; boundary=----WebKitFormBoundaryAmIhdMyLOrbDawcA'
}},(err,res,body)=>{
if(err)return reject(err)
const $=cheerio.load(body)
const result=$('div.alert.alert-warning > ul > li > span').find('a').attr('href')||null
if(result){resolve(result)}else{reject(new Error('Upload ke Top4Top gagal'))}
})
const form=req.form()
form.append('file_1_',buffer,{filename:`${Date.now()}.${ext}`})
form.append('submitr','[ رفع الملفات ]')
})
}catch(e){
console.error('Top4Top upload error:',e)
throw new Error('Gagal upload gambar ke Top4Top')
}}

let handler=async(m,{vanzz,text,prefix,command,qtext})=>{
try{
if((!m.quoted||!/image/.test((m.quoted.msg||m.quoted).mimetype))&&!m.message.imageMessage)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption:\n${prefix+command} Username|Caption\n\n📍 Contoh:\n${prefix+command} VannRyuichi|Kunci kesuksesan itu banyak, cuma kita sering lupa kuncinya.`},{quoted:qtext})
if(!text||!text.includes('|'))return m.reply('❌ Format salah! Gunakan format: `username|caption`')
const[username,captionText]=text.split('|').map(a=>a.trim())
if(!username)return m.reply('❌ Harap isi username!')
if(username.length>15)return m.reply('❌ Username maksimal 15 karakter!')
if(!captionText)return m.reply('❌ Harap isi caption story!')
await vanzz.sendMessage(m.chat,{react:{text:'🔖',key:m.key}})
let qmsg=m.quoted?m.quoted:m
let media=await vanzz.downloadAndSaveMediaMessage(qmsg)
const imageUrl=await uploadTop4Top(media)
if(fs.existsSync(media))fs.unlinkSync(media)
if(!imageUrl)return m.reply('❌ Gagal upload gambar ke Top4Top.')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/fakestory?apikey=${global.VsunseeApikey}&username=${encodeURIComponent(username)}&caption=${encodeURIComponent(captionText)}&userpp=${encodeURIComponent(imageUrl)}`
const res=await axios.get(apiUrl,{responseType:'arraybuffer'})
await vanzz.sendMessage(m.chat,{image:Buffer.from(res.data),caption:`📱 *Fake Instagram Story Berhasil!*\n👤 ${username}\n📝 ${captionText}`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('FAKESTORY ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Fake Instagram Story']
handler.tags=['maker']
handler.command=['fakestory']

export default handler