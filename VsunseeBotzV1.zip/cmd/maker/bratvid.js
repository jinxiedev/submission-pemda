import fetch from 'node-fetch'

let handler = async (m,{vanzz,text,author})=>{
if(!text)return vanzz.sendMessage(m.chat,{text:`Contoh: .bratvid vanzz Ryuichi`},{quoted:m})
if(text.length>250)return vanzz.sendMessage(m.chat,{text:`Karakter terbatas, maksimal 250!`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'🕖',key:m.key}})
try{
const res=await fetch(`https://${global.VsunseeApi}/vsunseeV8/bratvideo?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`)
if(!res.ok)throw new Error('Gagal mengambil video dari API.')
const buffer=await res.buffer()
await vanzz.sendVideoAsSticker(m.chat,buffer,m,{packname:'',author})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error(e)
await vanzz.sendMessage(m.chat,{text:`❌ Terjadi kesalahan:\n${e.message}`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})}
}

handler.help=['Sticker Video From Text']
handler.tags=['maker']
handler.command=['bratvid']

export default handler