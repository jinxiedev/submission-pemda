import fs from 'fs-extra'
import axios from 'axios'

let handler = async (m, { vanzz, text, qtext }) => {
if (!text) return vanzz.sendMessage(m.chat, { text: `❗ Masukkan teks untuk membuat quote!` }, { quoted: qtext })
try {
await vanzz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })
let ppuser
try {
ppuser = await vanzz.profilePictureUrl(m.sender, 'image')
} catch {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
type: 'quote',
format: 'png',
backgroundColor: '#000000',
width: 812,
height: 968,
scale: 2,
messages: [{
entities: [],
avatar: true,
from: {
id: 1,
name: m.pushName,
photo: { url: ppuser }
},
text: text,
replyMessage: {}
}]
}
const res = await axios.post('https://bot.lyo.su/quote/generate', json, { headers: { 'Content-Type': 'application/json' } })
const buffer = Buffer.from(res.data.result.image, 'base64')
const dirPath = './database/sampah'
if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true })
const tempnya = `${dirPath}/${m.sender}.png`
fs.writeFileSync(tempnya, buffer)
await vanzz.sendImageAsSticker(m.chat, tempnya, m, { packname: global.packname, author: global.nameown })
fs.unlinkSync(tempnya)
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (err) {
console.error('QC ERROR:', err)
await vanzz.sendMessage(m.chat, { text: `❌ Gagal membuat quote:\n${err.message}` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Quote Chat Sticker']
handler.tags = ['maker']
handler.command = ['qc']

export default handler