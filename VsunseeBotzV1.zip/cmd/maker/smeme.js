import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'

let handler = async (m, { vanzz, text, prefix, command, quoted, mime }) => {
try{
if(!/image/.test(mime))
return m.reply(`🧩 Kirim atau balas gambar dengan caption: ${prefix+command} text1|text2`)
if(!text) return m.reply(`Usage: ${prefix+command} text1|text2`)
const atas = text.split('|')[0] || '-'
const bawah = text.split('|')[1] || '-'
await vanzz.sendMessage(m.chat,{react:{text:'🕒',key:m.key}})
const media = await vanzz.downloadAndSaveMediaMessage(quoted)
const cdn = await upload({ path: media })
const cdnUrl = cdn[0]?.url
if(!cdnUrl) throw new Error('URL CDN tidak valid.')
const apiUrl = `https://${global.VsunseeApi}/vsunseeV8/smeme?apikey=${global.VsunseeApikey}&atas=${encodeURIComponent(atas)}&bawah=${encodeURIComponent(bawah)}&url=${encodeURIComponent(cdnUrl)}`
const res = await axios.get(apiUrl, { responseType:'arraybuffer' })
if(!res.data || res.data.length < 100){
if(fs.existsSync(media)) fs.unlinkSync(media)
return m.reply('❌ Gagal membuat meme.')
}
await vanzz.sendImageAsSticker(m.chat, Buffer.from(res.data), m, { packname: global.packname, author: global.author })
if(fs.existsSync(media)) fs.unlinkSync(media)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('SMEME ERROR:', e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help = ['Sticker Meme Custom']
handler.tags = ['maker']
handler.command = ['smeme']

export default handler