import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!text)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format lengkap:\n${prefix+command} provinsi|kota|nik|nama|ttl|jenis_kelamin|golongan_darah|alamat|rt/rw|kel/desa|kecamatan|agama|status|pekerjaan|kewarganegaraan|masa_berlaku|terbuat|pas_photo\n\n📍 Contoh:\n${prefix+command} Pluto|Kota Gasearah|172627263827272726|Vann Ryuichi|90/80/9999|Laki|M|Jalan Buntu|001/009|Home|HomeClub|Gada Agama|Jomblo|Tidur|PLUTO|Selamanya|Lupa|https://k.top4top.io/p_356927nzr1.jpg`},{quoted:qtext})

await vanzz.sendMessage(m.chat,{react:{text:'🪄',key:m.key}})

let q = text.split('|')
let pasPhoto = q[17]?.trim()

if(!pasPhoto && (m.quoted || m.message?.imageMessage)){
  let qmsg = m.quoted ? m.quoted : m
  let media = await vanzz.downloadAndSaveMediaMessage(qmsg)
  const cdn = await upload({ path: media })
  if(fs.existsSync(media)) fs.unlinkSync(media)
  pasPhoto = cdn[0]?.url || ''
}

const query =
`provinsi=${encodeURIComponent(q[0]||'')}`+
`&kota=${encodeURIComponent(q[1]||'')}`+
`&nik=${encodeURIComponent(q[2]||'')}`+
`&nama=${encodeURIComponent(q[3]||'')}`+
`&ttl=${encodeURIComponent(q[4]||'')}`+
`&jenis_kelamin=${encodeURIComponent(q[5]||'')}`+
`&golongan_darah=${encodeURIComponent(q[6]||'')}`+
`&alamat=${encodeURIComponent(q[7]||'')}`+
`&rt/rw=${encodeURIComponent(q[8]||'')}`+
`&kel/desa=${encodeURIComponent(q[9]||'')}`+
`&kecamatan=${encodeURIComponent(q[10]||'')}`+
`&agama=${encodeURIComponent(q[11]||'')}`+
`&status=${encodeURIComponent(q[12]||'')}`+
`&pekerjaan=${encodeURIComponent(q[13]||'')}`+
`&kewarganegaraan=${encodeURIComponent(q[14]||'')}`+
`&masa_berlaku=${encodeURIComponent(q[15]||'')}`+
`&terbuat=${encodeURIComponent(q[16]||'')}`+
`&pas_photo=${encodeURIComponent(pasPhoto||'')}`

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/ektp?apikey=${global.VsunseeApikey}&${query}`,{responseType:'arraybuffer'})
const buffer = Buffer.from(res.data)
if(!buffer || buffer.length < 200) return m.reply('❌ Gagal membuat e-KTP.')

await vanzz.sendMessage(m.chat,{
  image: buffer,
  caption: `🪪 *e-KTP Berhasil Dibuat!*\n👤 *Nama:* ${q[3]||'-'}\n🏙️ *Kota:* ${q[1]||'-'}`
},{quoted:m})

await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('EKTP ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Fake KTP Generator']
handler.tags=['maker']
handler.command=['ektp']

export default handler