import axios from 'axios'

let handler = async (m, { vanzz, text, prefix, command, qtext }) => {
if (!text) {
await vanzz.sendMessage(m.chat, {
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nama|kelas|teks\n\n📍 Contoh:\n${prefix + command} Vann Ryuichi|X SLB|helloworld("print") print(helloworld)`
}, { quoted: qtext })
return
}
await vanzz.sendMessage(m.chat, { react: { text: '🖋️', key: m.key } })
try {
const [nama, kelas, ...isi] = text.split('|')
if (!nama || !kelas || !isi.length) return m.reply(`⚠️ Format salah!\nGunakan format:\n${prefix + command} nama|kelas|teks`)
const teks = isi.join('|').trim()
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/nulis?apikey=${global.VsunseeApikey}&nama=${encodeURIComponent(nama)}&kelas=${encodeURIComponent(kelas)}&text=${encodeURIComponent(teks)}`, { responseType: 'arraybuffer' })
const buffer = Buffer.from(res.data)
if (!buffer || buffer.length === 0) return m.reply('❌ Gagal membuat gambar tulisan.')
await vanzz.sendMessage(m.chat, {
image: buffer,
caption: `📖 *Nulis Buku*\n\n✍️ *Nama:* ${nama}\n🏫 *Kelas:* ${kelas}\n📝 *Teks:* ${teks}\n`
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('NULIS ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Nulis Buku Otomatis']
handler.tags = ['maker']
handler.command = ['nulis']

export default handler