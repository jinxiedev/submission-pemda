import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'

let handler = async (m, { vanzz, prefix, command }) => {
try{
let q = m.quoted ? m.quoted : (m.message?.imageMessage ? m : null)
let mime = (q.msg || q).mimetype || ''
if(!/image/.test(mime))
return m.reply(`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption:\n${prefix+command}\n\n📍 Contoh:\n• Kirim gambar dengan caption: ${prefix+command}\n• Atau reply gambar lalu ketik: ${prefix+command}`)
await vanzz.sendMessage(m.chat,{react:{text:'📤',key:m.key}})
let media = await vanzz.downloadAndSaveMediaMessage(q)
const cdn = await upload({ path: media })
const cdnUrl = cdn[0]?.url
if(!cdnUrl) throw new Error('URL CDN tidak valid.')
await vanzz.sendMessage(m.chat,{react:{text:'🪄',key:m.key}})
const resp = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/removebg?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(cdnUrl)}`,{responseType:'arraybuffer'})
let buffer = Buffer.from(resp.data)
try{
let json = JSON.parse(buffer.toString())
return m.reply(`❌ *Gagal RemoveBG*\n📄 *Error:* ${json.error||json.message||'Unknown error'}`)
}catch{
await vanzz.sendMessage(m.chat,{image:buffer,caption:`🧩 *Background berhasil dihapus!*`},{quoted:m})
}
if(fs.existsSync(media)) fs.unlinkSync(media)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('REMOVE_BG ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help = ['Remove Background Image']
handler.tags = ['maker']
handler.command = ['removebg']

export default handler