import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!m.quoted&&!text&&!m.message.imageMessage)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption prompt edit:\n${prefix+command} Ayam Terbang\n\nAtau gunakan format link:\n${prefix+command} https://example.com/image.jpg|Ayam Terbang`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'📤',key:m.key}})
let imageUrl,prompt
if(text&&text.includes('|')){
const parts=text.split('|')
imageUrl=parts[0].trim()
prompt=parts.slice(1).join('|').trim()||'Edit Gambar Ini'
}else{
prompt=text?.trim()||'Edit Gambar Ini'
}
let q=m.quoted?m.quoted:(m.message?.imageMessage?m:null)
if(q){
let media=await vanzz.downloadAndSaveMediaMessage(q)
const cdn=await upload({path:media})
if(fs.existsSync(media))fs.unlinkSync(media)
imageUrl=cdn[0]?.url
}
if(!imageUrl)return m.reply('❌ Kirim atau reply gambar yang ingin diedit.')
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/imgedit?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`)
const{status,result}=res.data
if(!status||!result?.results?.[0]?.url)return m.reply('❌ Gagal mengedit gambar.')
const editedUrl=result.results[0].url
await vanzz.sendMessage(m.chat,{image:{url:editedUrl},caption:`🖌️ *Edit Berhasil!*\n🧠 Prompt: ${prompt}`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('IMGEDIT ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Image Edit Generator']
handler.tags=['maker']
handler.command=['imgedit']

export default handler