import axios from 'axios'

let handler = async (m, { vanzz, prefix, command, qtext, text }) => {
if (!text) {
await vanzz.sendMessage(m.chat, { 
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} teks_quote\n\n📍 Contoh:\n${prefix + command} Lo vanzz? ganteng bgt 🤭` 
}, { quoted: qtext })
return
}
await vanzz.sendMessage(m.chat, { react: { text: '🖌️', key: m.key } })
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/iqc?apikey=${global.VsunseeApikey}&messageText=${encodeURIComponent(text)}`, { responseType: 'arraybuffer' })
const buffer = Buffer.from(res.data)
if (!buffer || buffer.length === 0) return m.reply('❌ Gagal membuat gambar dari teks.')
await vanzz.sendMessage(m.chat, {
image: buffer,
caption: `🖋️ *Image Quote Creator*\n\n💬 Pesan: ${text}\nGambar Berhasil Dibuat ✅`,
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('IQC ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}}

handler.help = ['Iphone Quote Chat']
handler.tags = ['maker']
handler.command = ['iqc']

export default handler