import fetch from 'node-fetch'

let handler = async (m,{vanzz,text,author})=>{
if(!text)return vanzz.sendMessage(m.chat,{text:`Contoh: .bratanime vanzz Ryuichi`},{quoted:m})
if(text.length>250)return vanzz.sendMessage(m.chat,{text:`Karakter terbatas, maksimal 250!`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'🕖',key:m.key}})
try{
const res=await fetch(`https://${global.VsunseeApi}/vsunseeV8/bratanime?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`)
if(!res.ok)throw new Error('Gagal mengambil gambar anime dari API.')
const buffer=await res.buffer()
await vanzz.sendImageAsSticker(m.chat,buffer,m,{packname:'',author})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error(e)
await vanzz.sendMessage(m.chat,{text:`❌ Terjadi kesalahan:\n${e.message}`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})}
}

handler.help=['AnimeSticker From Text']
handler.tags=['maker']
handler.command=['bratanime']

export default handler