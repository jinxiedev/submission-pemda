import fs from 'fs'
import path from 'path'
import ffmpeg from 'fluent-ffmpeg'
import { fileTypeFromBuffer } from 'file-type';

const processingMap = new Map()
const cooldownMap = new Map()
const COOLDOWN_TIME = 60000 // Naikkan ke 60 detik agar server napas

let handler = async (m, { vanzz, prefix, command, text }) => {
const cooldownKey = m.chat 

if (processingMap.has(cooldownKey)) return m.reply('Sabar ya, masih ada video yang lagi diproses di chat ini... 𐔌՞. .՞𐦯')

const last = cooldownMap.get(m.sender)
if (last && Date.now() - last < COOLDOWN_TIME) {
const sisa = Math.ceil((COOLDOWN_TIME - (Date.now() - last)) / 1000)
return m.reply(`Tunggu ${sisa}s lagi ya biar server gak meledak~ 𐦯`)
}

const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''

if (!/video|mp4|mov|mkv|webm|avi|quicktime/i.test(mime)) {
return m.reply(`⚠️ Reply ke video yang mau di-HD kan!`)
}

await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
const tmpDir = './tmp'
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

let inputPath, outputPath, progressMsg
const filesToCleanup = []

try {
processingMap.set(cooldownKey, true)

const buffer = await quoted.download()
if (!buffer) throw new Error('Gagal download video')

const detected = await fileTypeFromBuffer(buffer)
const ext = detected?.ext || 'mp4'
inputPath = path.join(tmpDir, `in_${Date.now()}.${ext}`)
outputPath = path.join(tmpDir, `out_${Date.now()}.mp4`)

fs.writeFileSync(inputPath, buffer)
filesToCleanup.push(inputPath, outputPath)

progressMsg = await vanzz.sendMessage(m.chat, { text: `Memulai Upscale HD...` }, { quoted: m })

await new Promise((resolve, reject) => {
ffmpeg(inputPath)
.outputOptions([
'-vf scale=720:-2:flags=lanczos', 
'-c:v libx264',
'-preset superfast', 
'-crf 23',         
'-c:a copy'          
])
.on('progress', p => {
const percent = Math.round(p.percent)
if (percent % 25 === 0) {
    vanzz.sendMessage(m.chat, { edit: progressMsg.key, text: `⏳ Progress: ${percent}%` })
}
})
.on('end', resolve)
.on('error', reject)
.save(outputPath)
})

await vanzz.sendMessage(m.chat, {
video: { url: outputPath },
caption: 'Kualitas ditingkatkan ✨',
}, { quoted: m })

cooldownMap.set(m.sender, Date.now())

} catch (err) {
console.error(err)
m.reply(`❌ Error: ${err.message}`)
} finally {
processingMap.delete(cooldownKey)
filesToCleanup.forEach(f => {
if (fs.existsSync(f)) fs.unlinkSync(f)
})
}
}

handler.command = ['hdvideo', 'hd']
export default handler
