import { makeStickerFromUrl } from '../../source/events/_sticker.js'

let handler = async (m, { vanzz, prefix, command, reply }) => {
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
if (!/image|video/.test(mime)) return reply(`Reply gambar atau video dengan caption ${prefix + command}`)
try {
if (/image/.test(mime)) {
const media = await quoted.download()
const imageUrl = `data:${mime};base64,${media.toString('base64')}`
await makeStickerFromUrl(imageUrl, vanzz, m, reply)
} else if (/video/.test(mime)) {
if ((quoted?.msg || quoted)?.seconds > 10) return reply('Durasi video maksimal 10 detik!')
const media = await quoted.download()
const videoUrl = `data:${mime};base64,${media.toString('base64')}`
await makeStickerFromUrl(videoUrl, vanzz, m, reply)
}
} catch (e) {
console.error('STICKER ERROR:', e)
reply('❌ Terjadi kesalahan saat memproses media.')
}
}

handler.help = ['Sticker Creator']
handler.tags = ['maker']
handler.command = ['sticker', 's']

export default handler