import fs from 'fs'
import axios from 'axios'
import FormData from 'form-data'
import request from 'request'
import * as cheerio from 'cheerio'
import { fileTypeFromBuffer } from 'file-type'
import "../../settings/config.js"

async function uploadTop4Top(filePath) {
try{
const buffer=fs.readFileSync(filePath)
const {ext}=(await fileTypeFromBuffer(buffer))||{ext:'bin'}
return new Promise((resolve,reject)=>{
const req=request({
url:'https://top4top.io/index.php',
method:'POST',
headers:{
'User-Agent':'Mozilla/5.0',
'accept':'*/*',
'content-type':'multipart/form-data; boundary=----WebKitFormBoundaryAmIhdMyLOrbDawcA'
}},(err,res,body)=>{
if(err)return reject(err)
const $=cheerio.load(body)
const result=$('div.alert.alert-warning > ul > li > span').find('a').attr('href')||null
if(result){resolve(result)}else{reject(new Error('Upload ke Top4Top gagal'))}
})
const form=req.form()
form.append('file_1_',buffer,{filename:`${Date.now()}.${ext}`})
form.append('submitr','[ رفع الملفات ]')
})
}catch(error){
console.error('Top4Top upload error:',error)
throw new Error('Gagal upload gambar ke Top4Top')
}}

let handler=async(m,{vanzz,text,prefix,command,qtext})=>{
try{
if((!m.quoted||!/image/.test((m.quoted.msg||m.quoted).mimetype))&&!m.message.imageMessage)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption username (maks 8 huruf):\n${prefix+command} vanzzz`},{quoted:qtext})
let textInput=text?.trim()
if(!textInput)return m.reply('❌ Harap isi username (maks 8 huruf).')
if(textInput.length>8)return m.reply('❌ Username maksimal 8 huruf!')
await vanzz.sendMessage(m.chat,{react:{text:'✨',key:m.key}})
let qmsg=m.quoted?m.quoted:m
let media=await vanzz.downloadAndSaveMediaMessage(qmsg)
try{
await vanzz.sendMessage(m.chat,{react:{text:'✨',key:m.key}})
const imageUrl=await uploadTop4Top(media)
if(!imageUrl)throw new Error('Upload gambar gagal')
console.log('🧩 Top4Top URL:',imageUrl)
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/fakeml?apikey=${global.VsunseeApikey}&avatar=${encodeURIComponent(imageUrl)}&nickname=${encodeURIComponent(textInput)}`
console.log('🔗 API URL:',apiUrl)
const res=await axios.get(apiUrl,{responseType:'arraybuffer'})
let resultBuffer=res.data
let asText=''
try{asText=resultBuffer.toString()}catch{}
if(asText.startsWith('{')){
let parsed=JSON.parse(asText)
let msg=parsed.message||'❌ Gagal membuat FakeML.'
await vanzz.sendMessage(m.chat,{text:`*[❌]* ${msg}*`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
await vanzz.sendMessage(m.chat,{image:Buffer.from(resultBuffer),caption:`🎮 *Loby Mobile Legends*\n👤 Username: ${textInput}\n📁 Hosted by: Top4Top`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}finally{
if(fs.existsSync(media))fs.unlinkSync(media)
}}catch(e){
console.error('FAKEML ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
m.reply(`❌ Gagal membuat FakeML: ${e.message}`)
}}

handler.help=['Fake Lobby ML']
handler.tags=['maker']
handler.command=['fakeml'] 

export default handler