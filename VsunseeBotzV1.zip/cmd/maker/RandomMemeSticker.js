import fetch from 'node-fetch'

let handler = async (m, { vanzz, text, author }) => {
try {
await vanzz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })
const url = text && text.trim().length > 0
? `https://${global.VsunseeApi}/vsunseeV8/randomsticker?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`
: `https://${global.VsunseeApi}/vsunseeV8/randomsticker?apikey=${global.VsunseeApikey}`
const res = await fetch(url)
if (!res.ok) return m.reply('❌ Gagal mengambil sticker dari server!')
const buffer = await res.buffer()
await vanzz.sendImageAsSticker(m.chat, buffer, m, { packname: '', author })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (err) {
console.error('MEMES ERROR:', err)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
await m.reply('❌ Terjadi kesalahan saat mengambil sticker!')
}
}

handler.help = ['Random Meme Sticker']
handler.tags = ['maker']
handler.command = ['randomsticker']

export default handler