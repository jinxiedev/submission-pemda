import axios from 'axios'

let handler = async (m, { vanzz, text, prefix, command, qtext }) => {
try{
if(!text)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} nama\n\n📍 Contoh:\n${prefix+command} Rullz Fuqi`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'🪄',key:m.key}})
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/sertifikatlol?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`,{responseType:'arraybuffer'})
const buffer = Buffer.from(res.data)
if(!buffer || buffer.length < 200)
return m.reply('❌ Gagal membuat sertifikat.')
await vanzz.sendMessage(m.chat,{image:buffer,caption:`🏆 *Sertifikat Berhasil Dibuat!*\n👤 *Nama:* ${text}`},{quoted:m})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('SERTIFIKATLOL ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help = ['Sertifikat LOL']
handler.tags = ['maker']
handler.command = ['sertifikatlol']

export default handler