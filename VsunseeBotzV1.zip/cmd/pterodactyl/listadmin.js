import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📡',key:m.key}})
const page=parseInt(text)||1
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/listadmin?domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}`)
const body=res.data
if(!body||!body.status||!Array.isArray(body.admins))return await vanzz.sendMessage(m.chat,{text:'❌ Gagal mengambil daftar admin.'},{quoted:qtext})
const admins=body.admins
const perPage=20
const totalPage=Math.ceil(admins.length/perPage)
if(page<1||page>totalPage)return await vanzz.sendMessage(m.chat,{text:`⚠️ Halaman tidak ditemukan. Gunakan .listadmin 1 s/d ${totalPage}`},{quoted:qtext})
const start=(page-1)*perPage
const pageAdmins=admins.slice(start,start+perPage)
const buttons=[]
for(const a of pageAdmins){
const serverName=(a.servers&&a.servers.length)?a.servers.map(s=>s.name).join(', '):'-'
buttons.push({
title:`${a.email}`,
description:`Server: ${serverName}`,
id:`.deleteadmin ${a.id}`
})
}
await vanzz.sendButton(
m.chat,
`\n📄 Halaman Admin ${page}/${totalPage}`,
`✨ Pilih Admin Yang Akan Dihapus`,
`🗑️ Hapus Admin`,
global.ThumbPterodactyl,
null,
buttons,
m,
{}
)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('LIST ADMIN ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzz.sendMessage(m.chat,{text:`❌ Terjadi kesalahan saat mengambil daftar admin.`},{quoted:qtext})
}}

handler.help=['List Admin Panel']
handler.tags=['pterodactyl']
handler.command=['listadmin']
handler.owner=true
handler.premium=true

export default handler