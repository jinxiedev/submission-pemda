import axios from 'axios'
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🗑️',key:m.key}})
if(!text)return await vanzreply(m,'🧩 Gunakan format:\n.deleteserver <server_id>')
const id=text.trim()
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/deleteserver?domain=${encodeURIComponent(global.domain)}&capikey=${encodeURIComponent(global.capikey)}&id=${id}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal menghapus server.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
await vanzreply(m,`${body.message||'Server Berhasil Dihapus ☑️'}`)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('DELETE SERVER ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat menghapus server.\n\nError: ${e.message}`)
}}

handler.help=['Delete Server Panel']
handler.tags=['pterodactyl']
handler.command=['deleteserver']
handler.owner=true

export default handler