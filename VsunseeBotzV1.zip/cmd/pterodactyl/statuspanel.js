import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text,command})=>{
try{
if(command=="statuspanel"){
await vanzz.sendMessage(m.chat,{react:{text:'📊',key:m.key}})
const page=parseInt(text)||1
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/listserver?domain=${encodeURIComponent(global.domain)}&capikey=${encodeURIComponent(global.capikey)}`)
const body=res.data
if(!body||!body.status||!Array.isArray(body.result))return await vanzreply(m,'❌ Gagal mengambil daftar server.')
const servers=body.result
const perPage=20
const totalPage=Math.ceil(servers.length/perPage)
if(page<1||page>totalPage)return await vanzreply(m,`⚠️ Halaman tidak ditemukan. Gunakan .statuspanel 1 s/d ${totalPage}`)
const start=(page-1)*perPage
const pageServers=servers.slice(start,start+perPage)
const buttons=pageServers.map(s=>({
title:s.name,
description:`Server ID: ${s.id} | User: ${s.user_id}`,
id:`.resstatuspanel ${s.id}`
}))
await vanzz.sendButton(
m.chat,
`\n📄 Halaman Panel ${page}/${totalPage}`,
`✨ Pilih Server Untuk Melihat Status`,
`📊 Cek Status`,
global.ThumbPterodactyl,
null,
buttons,
m,
{}
)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}

if(command=="resstatuspanel"){
await vanzz.sendMessage(m.chat,{react:{text:'📊',key:m.key}})
if(!text)return await vanzreply(m,'🧩 Gunakan format:\n.resstatuspanel <server_id>')
const id=text.trim()
if(!id)return await vanzreply(m,'⚠️ Masukkan ID server yang valid!')
if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/statusserver?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}&id=${encodeURIComponent(id)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal mengambil status server.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
const info=body.info||{}
const caption=`🖥️ *Status Server ID ${id}*\n📡 Status: ${info.status||'Unknown'}\n💾 RAM: ${info.ram||'0 MB'}\n⚙️ CPU: ${info.cpu||'0%'}\n📀 Disk: ${info.disk||'0 MB'}`
await vanzreply(m,caption)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}
}catch(e){
console.error('STATUS PANEL ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan.\n\nError: ${e.message}`)
}}

handler.help=['Status Server Panel']
handler.tags=['pterodactyl']
handler.command=['statuspanel','resstatuspanel']
handler.owner=true

export default handler