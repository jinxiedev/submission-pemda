import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text,command})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}})
if(!text||text.toLowerCase()!=="gas"){
const warning=`✨ *PERINGATAN*\n\nHarap Hati-hati Menggunakan Fitur Ini!\nfitur Ini Akan *Menghapus Semua Server Pterodactyl* Yang Berstatus *Offline* Atau *Tidak Digunakan*.\n\n📌 *Command Valid:*\n.clearserveroff gas`
return await vanzreply(m,warning)
}
if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')
await vanzz.sendMessage(m.chat,{react:{text:'🧹',key:m.key}})
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/clearOfflineServers?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}`
const res=await axios.get(apiUrl,{timeout:30000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal menghapus server offline.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
const deleted=body.deleted||[]
let listDeleted=deleted.length>0?deleted.map(x=>`• ID: ${x.id} (${x.status})`).join('\n'):'Tidak ada server offline yang dihapus.'
const caption=`🧹 *CLEAR SERVER OFFLINE BERHASIL*\n\n📡 ${body.message||'Proses selesai.'}\n\n🗑️ *Total Dihapus:* ${body.totalDeleted||0}\n⚙️ *Total Dilewati:* ${body.totalSkipped||0}\n\n${listDeleted}`
await vanzreply(m,caption)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('CLEAR SERVER OFF ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat menghapus server offline.\n\nError: ${e.message}`)
}}

handler.help=['Clear Offline Server']
handler.tags=['pterodactyl']
handler.command=['clearserveroff']
handler.owner=true

export default handler