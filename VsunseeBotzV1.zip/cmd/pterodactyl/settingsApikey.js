import fs from 'fs'
import path from 'path'
import '../../settings/config.js'

let handler = async (m, { text, prefix, command, vanzz, qtext }) => {
try {
if (command === 'updomain') {
if (!text && !m.quoted) return m.reply(`*Format salah!*\nContoh: ${prefix + command} <Domain>`)
const newVal = m.quoted ? m.quoted.text : text
global.domain = newVal
const file = path.resolve('./settings/config.js')
let content = fs.readFileSync(file, 'utf8')
content = content.replace(/global\.domain\s*=\s*['"`]?.*?['"`]?;/, `global.domain = '${newVal}';`)
fs.writeFileSync(file, content, 'utf8')
await vanzz.sendMessage(m.chat, { text: '_Berhasil Mengganti Domain Panel✅_' }, { quoted: qtext })
}

else if (command === 'upapikey') {
if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`)
const newVal = m.quoted ? m.quoted.text : text
global.apikey = newVal
const file = path.resolve('./settings/config.js')
let content = fs.readFileSync(file, 'utf8')
content = content.replace(/global\.apikey\s*=\s*['"`]?.*?['"`]?;/, `global.apikey = '${newVal}';`)
fs.writeFileSync(file, content, 'utf8')
await vanzz.sendMessage(m.chat, { text: '_Berhasil Mengganti Apikey Panel✅_' }, { quoted: qtext })
}

else if (command === 'upcapikey') {
if (!text && !m.quoted) return m.reply(`*Format salah!*\nContoh: ${prefix + command} <Capikey>`)
const newVal = m.quoted ? m.quoted.text : text
global.capikey = newVal
const file = path.resolve('./settings/config.js')
let content = fs.readFileSync(file, 'utf8')
content = content.replace(/global\.capikey\s*=\s*['"`]?.*?['"`]?;/, `global.capikey = '${newVal}';`)
fs.writeFileSync(file, content, 'utf8')
await vanzz.sendMessage(m.chat, { text: '_Berhasil Mengganti Capikey Panel✅_' }, { quoted: qtext })
}
} catch (e) {
console.error('UPDATE CONFIG ERROR:', e)
await vanzz.sendMessage(m.chat, { text: '_Gagal menyimpan perubahan ke file config.js_' }, { quoted: qtext })
}
}

handler.help = ['Settings Apikey Pterodactyl']
handler.tags = ['pterodactyl']
handler.command = ['updomain', 'upapikey', 'upcapikey']
handler.owner = true

export default handler