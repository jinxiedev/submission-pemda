import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, command }) => {
try{
await vanzz.sendMessage(m.chat,{react:{text:'🎬',key:m.key}})

const sizeMatch=command.match(/^(\d+)(gb)?$/i)
if(!sizeMatch)
return await vanzreply(m,`🧩 Format salah!\nContoh: *.3gb NamaServer,628123456789*\nGunakan dari 1gb sampai 10gb atau 0 untuk unlimited.`)

const diskGb=Number(sizeMatch[1])
const cpuMap={1:40,2:60,3:80,4:100,5:120,6:140,7:160,8:180,9:200,10:220,0:0}
const cpuValue=cpuMap[diskGb]??0
const diskValue=diskGb===0?0:diskGb*1000
if(diskGb!==0&&(diskGb<1||diskGb>10))
return await vanzreply(m,'⚠️ Batas disk hanya 1GB–10GB atau 0 untuk unlimited.')

if(!text)
return await vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n.${command} <NamaServer>,<NomorTarget>\natau balas pesan user:\n.${command} <NamaServer>\n\n📍 Contoh:\n.${command} Samsul,6288276746473`)

let [nameServer,targetNumber]=text.split(',')
nameServer=(nameServer||'Server').trim()
targetNumber=(targetNumber||'').trim()

if(!targetNumber&&m.quoted&&m.quoted.sender){
targetNumber=m.quoted.sender.split('@')[0]
}else if(!targetNumber){
targetNumber=m.sender.split('@')[0]
}

if(!targetNumber||isNaN(targetNumber))
return await vanzreply(m,"❌ Nomor target tidak valid atau kosong!")

const targetJid=`${targetNumber.replace(/\D/g,'')}@s.whatsapp.net`

if(!global.VsunseeApi||!global.domain||!global.apikey||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')

const usernameBase=(nameServer.toLowerCase().replace(/\s+/g,'').replace(/[^a-z0-9]/g,'').slice(0,8))||('user'+Date.now().toString().slice(-4))
const randSuffix=Math.random().toString(36).slice(2,6)
const password=`${usernameBase}${randSuffix}`

const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/create?domain=${encodeURIComponent(global.domain)}&apikeyptero=${encodeURIComponent(global.apikey)}&capikeyptero=${encodeURIComponent(global.capikey)}&nameserver=${encodeURIComponent(nameServer)}&password=${encodeURIComponent(password)}&disk=${diskValue}&cpu=${cpuValue}`

const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data

if(!body||!body.status)
return await vanzreply(m,`❌ Gagal membuat panel.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)

const created=body.data||{}
const caption=`🔔 *INFORMASI AKUN PANEL*\n\n🏷Nama Server: ${created.nama_server??nameServer}\n🆔 Server ID: ${created.id_server??'-'}\n👤 Username: ${created.username??usernameBase}\n🔐 Password: ${created.password??password}\n⚙️ Spesifikasi:\n• Disk: ${diskGb===0?'Unlimited (0)':diskGb+' GB ('+diskValue+' MB)'}\n• CPU: ${cpuValue}\n🌐 Login: ${created.domain_panel??global.domain}\n\n🩸Dilarang Membagikan Data Akun\n🩸Bot Hanya Kirim 1X Data Akun\n🩸Garansi Full 30 Day\n🩸Jika Ada Masalah Hubungi Owner`

const message={
footer:global.nameown,
headerType:1,
viewOnce:false,
image:{url:ThumbPterodactyl},
caption:caption,
contextInfo:{
forwardingScore:999,
isForwarded:true,
mentionedJid:[m.sender],
forwardedNewsletterMessageInfo:{
newsletterName:global.nameown,
newsletterJid:global.ChannelID
},
externalAdReply:{
title:global.namebotz,
body:global.nameown,
thumbnailUrl:ThumbPterodactyl,
sourceUrl:global.ChannelWA,
mediaType:1,
renderLargerThumbnail:false
}
}
}

await vanzz.sendMessage(targetJid,message,{quoted:m})
await vanzreply(m,`Panel ${diskGb===0?'Unlimited':diskGb+'GB'}  Berhasil Dikirim Ke ${targetNumber} ✨`)
}catch(e){
await vanzreply(m,`❌ Terjadi kesalahan saat membuat panel.\n\nError:\n${e.message}`)
}}

handler.help=['Create Panel Pterodactyl']
handler.tags=['pterodactyl']
handler.command=['0','1gb','2gb','3gb','4gb','5gb','6gb','7gb','8gb','9gb','10gb']
handler.owner=true
handler.premium=true

export default handler