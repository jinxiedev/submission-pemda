import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text,command})=>{
try{
if(command=="stoppanel"){
await vanzz.sendMessage(m.chat,{react:{text:'🔴',key:m.key}})
const page=parseInt(text)||1
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/listserver?domain=${encodeURIComponent(global.domain)}&capikey=${encodeURIComponent(global.capikey)}`)
const body=res.data
if(!body||!body.status||!Array.isArray(body.result))return await vanzreply(m,'❌ Gagal mengambil daftar server.')
const servers=body.result
const perPage=20
const totalPage=Math.ceil(servers.length/perPage)
if(page<1||page>totalPage)return await vanzreply(m,`⚠️ Halaman tidak ditemukan. Gunakan .stoppanel 1 s/d ${totalPage}`)
const start=(page-1)*perPage
const pageServers=servers.slice(start,start+perPage)
const buttons=pageServers.map(s=>({
title:s.name,
description:`Server ID: ${s.id} | User: ${s.user_id}`,
id:`.resstoppanel ${s.id}`
}))
await vanzz.sendButton(
m.chat,
`\n📄 Halaman Panel ${page}/${totalPage}`,
`✨ Pilih Server Yang Akan Dimatikan`,
`🔴 Matikan Server`,
global.ThumbPterodactyl,
null,
buttons,
m,
{}
)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}

if(command=="resstoppanel"){
await vanzz.sendMessage(m.chat,{react:{text:'🔴',key:m.key}})
if(!text)return await vanzreply(m,'🧩 Gunakan format:\n.resstoppanel <server_id>')
const id=text.trim()
if(!id)return await vanzreply(m,'⚠️ Masukkan ID server yang valid!')
if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/offserver?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}&id=${encodeURIComponent(id)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal mematikan server.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
await vanzreply(m,body.message||`Server ID ${id} Berhasil Dimatikan☑️`)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}
}catch(e){
console.error('STOP PANEL ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan.\n\nError: ${e.message}`)
}}

handler.help=['Stop Server Panel']
handler.tags=['pterodactyl']
handler.command=['stoppanel','resstoppanel']
handler.owner=true

export default handler