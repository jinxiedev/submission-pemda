import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'⚙️',key:m.key}})

if(!text)return await vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n.setadmin <id_user>,<admin/user>\n\n📍 Contoh:\n.setadmin 16,admin`)

let [userid,type]=text.split(',')
userid=(userid||'').trim()
type=(type||'').toLowerCase().trim()

if(!userid||!['admin','user'].includes(type))
return await vanzreply(m,'⚠️ Masukkan format yang benar!\n\nKetik: `.setadmin <id_user>,<admin/user>`\n\nContoh valid:\n• .setadmin 16,admin\n• .setadmin 16,user')

if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.apikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')

const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/setadmin?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&apikeyptero=${encodeURIComponent(global.apikey)}&userid=${encodeURIComponent(userid)}&type=${encodeURIComponent(type)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data

if(!body||!body.status)
return await vanzreply(m,`❌ Gagal mengubah status admin.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)

const result=body.result||{}
const caption=`🔧 *Status Pengguna Diperbarui*\n\n👤 Username: ${result.username||'-'}\n✉️ Email: ${result.email||'-'}\n🆔 ID: ${result.id||userid}\n📊 Status Baru: ${result.newStatus||type}\n\n✅ ${body.message||'Berhasil diperbarui.'}`

await vanzreply(m,caption)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})

}catch(e){
console.error('SET ADMIN ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat mengubah status admin.\n\nError: ${e.message}`)
}}

handler.help=['Set Admin Atau User Panel']
handler.tags=['pterodactyl']
handler.command=['setuser']
handler.owner=true

export default handler