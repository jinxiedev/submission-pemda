import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,text,command})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📦',key:m.key}})

if(!text)return await vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n.${command} <NamaServer>,<NomorTarget>\natau balas pesan user dan ketik:\n.${command} <NamaServer>\n\n📍 Contoh:\n.${command} Samsul,628123456789`},{quoted:qtext})

let [nameServer,targetNumber]=text.split(',')
nameServer=(nameServer||'Server').trim()
targetNumber=(targetNumber||'').trim()

if(!targetNumber&&m.quoted&&m.quoted.sender){
targetNumber=m.quoted.sender.split('@')[0]
}else if(!targetNumber){
targetNumber=m.sender.split('@')[0]
}

const buttons=[]
for(let i=1;i<=10;i++){
buttons.push({title:`${i}GB`,id:`.${i}gb ${nameServer},${targetNumber}`})
}
buttons.push({title:`Unlimited`,id:`.0 ${nameServer},${targetNumber}`})

await vanzz.sendButton(
m.chat,
`📱 Target: ${targetNumber}`,
"Pilih Kapasitas Di Bawah Ini",
`🎛️ Pilih Disk`,
global.ThumbPterodactyl,
null,
buttons,
m,
{}
)

await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('CPANEL BUTTON ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzz.sendMessage(m.chat,{text:'❌ Terjadi kesalahan saat menampilkan pilihan panel.'},{quoted:qtext})
}}

handler.help=['cpanel']
handler.tags=['pterodactyl']
handler.command=['cpanel']

export default handler