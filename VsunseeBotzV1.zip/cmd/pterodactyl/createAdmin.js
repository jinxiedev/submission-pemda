import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🛠️',key:m.key}})

if(!text) return await vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n.cadmin <Username>,<NomorTarget>\n\n📍 Contoh:\n.cadmin TesAdmin,6288276746473`)

let [nameuser,targetNumber]=text.split(',')
nameuser=(nameuser||'Admin').trim()
targetNumber=(targetNumber||'').replace(/\D/g,'')

if(!targetNumber&&m.quoted&&m.quoted.sender){
targetNumber=m.quoted.sender.split('@')[0]
}else if(!targetNumber){
targetNumber=m.sender.split('@')[0]
}

if(/^0\d+/.test(targetNumber)) targetNumber='62'+targetNumber.slice(1)
const targetJid=`${targetNumber}@s.whatsapp.net`

if(!global.VsunseeApi||!global.domain||!global.apikey||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')

const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/createadmin?domain=${encodeURIComponent(global.domain)}&apikeyptero=${encodeURIComponent(global.apikey)}&capikeyptero=${encodeURIComponent(global.capikey)}&nameuser=${encodeURIComponent(nameuser)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data

if(!body||!body.status)
return await vanzreply(m,`❌ Gagal membuat admin.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)

const created=body.data||{}
const caption=`🔐 *Akun Admin Telah Dibuat*\n\n👤 Username: ${created.username||nameuser}\n✉️ Email: ${created.email||'-'}\n🔑 Password: ${created.password||'-'}\n🆔 User ID: ${created.id_user||'-'}\n🏷️ Root Admin: ${created.root_admin?'true':'false'}\n🌐 Domain: ${global.domain}\n\nJika ada masalah, hubungi owner.`

await vanzz.sendMessage(targetJid,{
image:{url:global.ThumbPterodactyl||undefined},
caption:caption,
headerType:1,
contextInfo:{
forwardingScore:999,
isForwarded:true,
externalAdReply:{
title:global.namebotz||'Admin Panel Info',
body:global.nameown||'',
thumbnailUrl:global.ThumbPterodactyl||undefined,
sourceUrl:global.ChannelID,
mediaType:1,
renderLargerThumbnail:false
}}})

await vanzreply(m,`✅ Akun admin berhasil dibuat dan dikirimkan ke ${targetNumber} ✨`)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})

}catch(e){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat membuat admin.\n\nError:\n${e.message}`)
}}

handler.help=['Create Admin Panel']
handler.tags=['pterodactyl']
handler.command=['cadmin']
handler.owner=true

export default handler