import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📡',key:m.key}})
const page=parseInt(text)||1
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/listserver?domain=${encodeURIComponent(global.domain)}&capikey=${encodeURIComponent(global.capikey)}`)
const body=res.data
if(!body||!body.status||!Array.isArray(body.result))return await vanzz.sendMessage(m.chat,{text:'❌ Gagal mengambil daftar server.'},{quoted:qtext})
const servers=body.result
const perPage=20
const totalPage=Math.ceil(servers.length/perPage)
if(page<1||page>totalPage)return await vanzz.sendMessage(m.chat,{text:`⚠️ Halaman tidak ditemukan. Gunakan .listserver 1 s/d ${totalPage}`},{quoted:qtext})
const start=(page-1)*perPage
const pageServers=servers.slice(start,start+perPage)
const buttons=pageServers.map(s=>({
title:s.name,
description:`Server ID: ${s.id} | User: ${s.user_id}`,
id:`.deleteserver ${s.id}`
}))
await vanzz.sendButton(
m.chat,
`\n📄 Halaman Server ${page}/${totalPage}`,
`✨Pilih Server Yang Akan Dihapus`,
`🗑️ Hapus Server`,
global.ThumbPterodactyl,
null,
buttons,
m,
{}
)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('LIST SERVER ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzz.sendMessage(m.chat,{text:`❌ Terjadi kesalahan saat mengambil daftar server.`},{quoted:qtext})
}}

handler.help=['List Server Panel']
handler.tags=['pterodactyl']
handler.command=['listserver']
handler.owner=true
handler.premium=true

export default handler