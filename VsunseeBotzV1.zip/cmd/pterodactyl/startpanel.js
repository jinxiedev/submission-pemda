import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text,command})=>{
try{
if(command=="startpanel"){
await vanzz.sendMessage(m.chat,{react:{text:'⚙️',key:m.key}})
const page=parseInt(text)||1
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/listserver?domain=${encodeURIComponent(global.domain)}&capikey=${encodeURIComponent(global.capikey)}`)
const body=res.data
if(!body||!body.status||!Array.isArray(body.result))return await vanzreply(m,'❌ Gagal mengambil daftar server.')
const servers=body.result
const perPage=20
const totalPage=Math.ceil(servers.length/perPage)
if(page<1||page>totalPage)return await vanzreply(m,`⚠️ Halaman tidak ditemukan. Gunakan .startpanel 1 s/d ${totalPage}`)
const start=(page-1)*perPage
const pageServers=servers.slice(start,start+perPage)
const buttons=pageServers.map(s=>({
title:s.name,
description:`Server ID: ${s.id} | User: ${s.user_id}`,
id:`.resstartpanel ${s.id}`
}))
await vanzz.sendButton(
m.chat,
`\n📄 Halaman Panel ${page}/${totalPage}`,
`✨ Pilih Server Yang Akan Dinyalakan`,
`⚡ Nyalakan Server`,
global.ThumbPterodactyl,
null,
buttons,
m,
{}
)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}

if(command=="resstartpanel"){
await vanzz.sendMessage(m.chat,{react:{text:'⚡',key:m.key}})
if(!text)return await vanzreply(m,'🧩 Gunakan format:\n.resstartpanel <server_id>')
const id=text.trim()
if(!id)return await vanzreply(m,'⚠️ Masukkan ID server yang valid!')
if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/onserver?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}&id=${encodeURIComponent(id)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal menyalakan server.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
await vanzreply(m,body.message||`Server ID ${id} berhasil dinyalakan ☑️`)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}
}catch(e){
console.error('STARTPANEL HANDLER ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan.\n\nError: ${e.message}`)
}}

handler.help=['Start Server Panel']
handler.tags=['pterodactyl']
handler.command=['startpanel','resstartpanel']
handler.owner=true

export default handler