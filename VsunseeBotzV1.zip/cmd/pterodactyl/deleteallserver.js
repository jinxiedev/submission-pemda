import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🧹',key:m.key}})
const pengecualian=(text||'').trim().replace(/\s+/g,'')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/deleteallserver?domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}&pengecualian=${encodeURIComponent(pengecualian)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal menghapus semua server.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
const deleted=(body.deleted||[]).map(x=>`• ${x}`).join('\n')||'-'
const failed=(body.failed||[]).map(x=>`• ${x}`).join('\n')||'-'
const skip=(body.dikecualikan||[]).map(x=>`• ${x}`).join('\n')||'-'
const caption=`🧹 *Hapus Semua Server*\n\n📦 Mode: ${body.mode||'-'}\n📊 Total Server: ${body.total||0}\n\n✅ *Berhasil Dihapus:*\n${deleted}\n\n⚠️ *Gagal Dihapus:*\n${failed}\n\n🚫 *Dikecualikan:*\n${skip}`
await vanzreply(m,caption)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('DELETE ALL SERVER ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat menghapus semua server.\n\nError: ${e.message}`)
}}

handler.help=['Delete All Server']
handler.tags=['pterodactyl']
handler.command=['deleteallserver']
handler.owner=true

export default handler