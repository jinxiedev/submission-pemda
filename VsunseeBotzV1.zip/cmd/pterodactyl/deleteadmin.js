import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🗑️',key:m.key}})
if(!text)return await vanzreply(m,'🧩 Gunakan format:\n.deleteadmin <user_id>')
const id=text.trim()
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/deleteadmin?domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}&userid=${id}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal menghapus admin.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
const deletedUser=body.deleted_user||{}
const deletedServers=(body.deleted_servers||[]).map(s=>`• ${s.name} (ID: ${s.id})`).join('\n')||'-'
const caption=`🗑️ *Admin Berhasil Dihapus*\n\n👤 Username: ${deletedUser.username||'-'}\n✉️ Email: ${deletedUser.email||'-'}\n🆔 User ID: ${deletedUser.id||id}\n🌐 Domain: ${body.domain||global.domain}\n\n🗄️ *Server Dihapus:*\n${deletedServers}\n\n✅ ${body.message||''}`
await vanzreply(m,caption)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('DELETE ADMIN ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat menghapus admin.\n\nError: ${e.message}`)
}}

handler.help=['Delete Admin Panel']
handler.tags=['pterodactyl']
handler.command=['deleteadmin']
handler.owner=true

export default handler