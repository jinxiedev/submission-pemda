import axios from 'axios'
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🔍',key:m.key}})
if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.apikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/statuspanel?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&apikeyptero=${encodeURIComponent(global.apikey)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal mengecek status panel.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
await vanzreply(m,body.message||'✅ Panel aktif dan API berfungsi dengan baik.')
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('CEKPANEL ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat mengecek panel.\n\nError: ${e.message}`)
}}

handler.help=['Cek Panel Status']
handler.tags=['pterodactyl']
handler.command=['cekpanel']
handler.owner=true

export default handler