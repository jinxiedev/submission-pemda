import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🧨',key:m.key}})
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/deletealluser?domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal menghapus semua user.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
const deleted=(body.deleted||[]).map(x=>`• ${x}`).join('\n')||'-'
const failed=(body.failed||[]).map(x=>`• ${x}`).join('\n')||'-'
const skip=(body.dikecualikan||[]).map(x=>`• ${x}`).join('\n')||'-'
const caption=`🧨 *Hapus Semua User*\n\n📦 Mode: ${body.mode||'-'}\n📊 Total User: ${body.total||0}\n\n✅ *Berhasil Dihapus:*\n${deleted}\n\n⚠️ *Gagal Dihapus:*\n${failed}\n\n🚫 *Dikecualikan:*\n${skip}`
await vanzreply(m,caption)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('DELETE ALL USER ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat menghapus semua user.\n\nError: ${e.message}`)
}}

handler.help=['Delete All User']
handler.tags=['pterodactyl']
handler.command=['deletealluser']
handler.owner=true

export default handler