import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m,{vanzz,text})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🔒',key:m.key}})
if(!text)return await vanzreply(m,'🧩 Gunakan format:\n.suspend <server_id>')
const id=text.trim()
if(!id)return await vanzreply(m,'⚠️ Masukkan ID server yang valid!')
if(!global.VsunseeApi||!global.VsunseeApikey||!global.domain||!global.capikey)
return await vanzreply(m,'⚠️ Config belum lengkap di config.js')
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/suspend?apikey=${encodeURIComponent(global.VsunseeApikey)}&domain=${encodeURIComponent(global.domain)}&capikeyptero=${encodeURIComponent(global.capikey)}&id=${encodeURIComponent(id)}`
const res=await axios.get(apiUrl,{timeout:20000})
const body=res.data
if(!body||!body.status)return await vanzreply(m,`❌ Gagal suspend server.\n\n🧩 Detail:\n${JSON.stringify(body?.error||body,null,2)}`)
await vanzreply(m,body.message||`✅ Server ID ${id} berhasil di-suspend.`)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('SUSPEND SERVER ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await vanzreply(m,`❌ Terjadi kesalahan saat suspend server.\n\nError: ${e.message}`)
}}

handler.help=['Suspend Server Panel']
handler.tags=['pterodactyl']
handler.command=['suspend']
handler.owner=true

export default handler