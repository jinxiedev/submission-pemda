import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📜',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/listdomaincf?apikeycf=${global.apikeycf}&email=${encodeURIComponent(global.emailcf)}`)
const data=res.data
if(!data.status)return m.reply(`❌ Gagal mengambil daftar domain: ${data.error||'Tidak diketahui'}`)
let teks=`🌐 *Daftar Domain Cloudflare (${data.total_domains})*\n\n`
for(let x of data.domains){
teks+=`🔹 *${x.name}*\n🆔 ID: ${x.id}\n📅 Dibuat: ${x.created_on}\n📡 Status: ${x.status}\n\n`
}
await vanzreply(m,teks.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('LISTDOMAINCF ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['List Domain Cloudflare']
handler.tags=['cloudflare']
handler.command=['listdomaincf']
handler.owner = true

export default handler