import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'
import { qtext } from '../../source/quoted.js'
import { sendButtonMsg } from '../../source/events/sendButtons.js' 

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(command==='subdomain'){
if(!text)return m.reply(`⚠️ Format salah!\n\nContoh:\n${prefix+command} namasubdomain|8.8.8.8|add`)
let[sub,ip,mode]=text.split('|')
if(!sub||!ip||!mode)return m.reply(`⚠️ Format tidak valid!\n\nContoh:\n${prefix+command} namasubdomain|8.8.8.8|add`)

mode = mode.toLowerCase()
if (mode === 'del') {
mode = 'delete'
}
if (mode !== 'add' && mode !== 'delete') {
return m.reply(`⚠️ Mode tidak valid! Gunakan 'add' atau 'delete'.`)
}

let rows=[
{title:"🎏 tokodex.biz.id",description:`${sub} tokodex.biz.id`,id:`.ressubdomain ${sub}|${ip}|${mode}|tokodex`},
{title:"🎏 shopserverr.biz.id",description:`${sub} shopserverr.biz.id`,id:`.ressubdomain ${sub}|${ip}|${mode}|shopserverr`},
{title:"🎏 vsunsee-clouds.biz.id",description:`${sub} vsunsee-clouds.biz.id`,id:`.ressubdomain ${sub}|${ip}|${mode}|vsunsee-clouds`}
]

const buttons = [
{
buttonId: 'listdomains', 
buttonText: { displayText: '🌐 Pilih Domain' },
type: 2,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Pilih Subdomain",
sections: [
{
title: `List Domain✨`,
rows: rows
}
]
})
}
}
]

const caption = `📝 Subdomain: ${sub}\n📡 IP: ${ip}\n⚙️ Mode: ${mode}\n`

await sendButtonMsg(vanzz, m.chat, {
caption: caption,
footer: `${global.namebotz}`,
buttons: buttons,
headerType: 1
}, { quoted: qtext })

}
else if(command==='ressubdomain'){
let[sub,ip,mode,api]=text.split('|')
if(!sub||!ip||!mode||!api)return m.reply(`⚠️ Format salah!\n\nGunakan: .ressubdomain subdomain|ip|mode|api`)
await vanzz.sendMessage(m.chat,{react:{text:'🗯',key:m.key}})
let url=`https://${global.VsunseeApi}/vsunseeV8/${api}?mode=${mode}&subdomain=${sub}&ip=${ip}`
let res=await fetch(url)
let data=await res.json().catch(_=>null)
if(!data)return m.reply("⚠️ Tidak ada response dari API!\n\nURL: "+url)
let subdomain=data.subdomain||sub
let ipaddr=data.ip||ip
let modemode=data.mode||mode
let pesan,emoji
if(data.status){
pesan=data.message||""
emoji=modemode.toLowerCase()==='add'?'🟢':modemode.toLowerCase()==='delete'?'🔴':'⚙️'
}else{
pesan=data.error||"Terjadi kesalahan"
emoji='❌'
}
let teks=`${emoji} *Subdomain (${api.toUpperCase()})*\n\n📝 Subdomain: ${subdomain}\n📡 IP: ${ipaddr}\n⚙️ Mode: ${modemode}\n💬 Pesan: ${pesan}`
let thumbUrl=global.ThumbSubdo

try {
let thumbRes = await fetch(thumbUrl)
let thumb = Buffer.from(await thumbRes.arraybuffer())

await vanzz.sendMessage(m.chat, {
image: thumb,
caption: teks
}, { quoted: qtext })
} catch (sendError) {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}

await vanzz.sendMessage(m.chat,{react:{text:emoji,key:m.key}})
}
}catch(e){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Subdomain Manager']
handler.tags=['cloudflare']
handler.command=['subdomain','ressubdomain']

export default handler
