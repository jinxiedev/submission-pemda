import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{text,prefix,command,vanzz})=>{
try{
let[mode,domain]=text.split('|')
if(!mode||!domain)return m.reply(`🧩 *Masukkan mode dan domain dengan benar!*\n\nContoh:\n${prefix+command} add|https://sigmaboy.my.id\n${prefix+command} delete|https://sigmaboy.my.id`)
mode=mode.trim().toLowerCase()
domain=domain.trim()
if(!['add','delete'].includes(mode))return m.reply('❌ Mode hanya bisa: add / delete')
await vanzz.sendMessage(m.chat,{react:{text:'🌐',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/adddomaincf?mode=${mode}&apikeycf=${global.apikeycf}&email=${encodeURIComponent(global.emailcf)}&domain=${encodeURIComponent(domain)}`)
const data=res.data
if(!data.status)return m.reply(`❌ Gagal: ${data.error||'Tidak diketahui'}`)
let hasil
if(mode==='add'){
hasil=`✅ *Domain Berhasil Ditambahkan!*\n\n🌐 *Domain:* ${data.domain}\n🧩 *Mode:* ${data.mode}\n📡 *Nameservers:*\n• ${data.nameservers[0]}\n• ${data.nameservers[1]}`
}else{
hasil=`✅ *Domain Berhasil Dihapus!*\n\n🌐 *Domain:* ${data.domain}\n🧩 *Mode:* ${data.mode}\n🗑️ *Pesan:* ${data.message}`
}
await vanzreply(m,hasil.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('ADDDOMAINCF ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Tambah / Hapus Domain Cloudflare']
handler.tags=['cloudflare']
handler.command=['adddomaincf']
handler.owner = true

export default handler