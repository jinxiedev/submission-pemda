import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix + command} hololive`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/kucing/search?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}&page=1`)
const { status, result } = res.data
if (!status || !result?.result?.length) {
await reaction(m.chat, '❌')
console.log("Kucing API Response Error:", res.data)
return m.reply(`*[❌]* Tidak ada hasil untuk *${text}*.`)
}

const list = result.result

try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}
const cards = []
for (let i = 0; i < Math.min(list.length, 10); i++) {
const item = list[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(item.image) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...img
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `🎬 *${item.title}*\n📅 ${item.date}\n📦 ID: ${item.id}`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin ID Video\",\"id\":\"kc-${i}\",\"copy_code\":\"${item.id}\"}` }
]
})
}
cards.push(card)
}
const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*🐾 Hasil Pencarian Kucing API:*\n@${m.sender.split('@')[0]}`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)
let textList = `⚠️ *Gagal Load Slide Button*\n\n🐾 *Hasil Pencarian Kucing API:*\n\n`
for (let i = 0; i < Math.min(list.length, 5); i++) {
const item = list[i]
textList += `🎬 *${item.title}*\n📅 ${item.date}\n🆔 ${item.id}\n\n`
try {
const imageBuffer = await axios.get(item.image, { responseType: 'arraybuffer' })
await vanzz.sendMessage(m.chat, { 
image: Buffer.from(imageBuffer.data), caption: `🎬 ${item.title}\n📅 ${item.date}\n🆔 ${item.id}` 
}, { quoted: qtext })
} catch (imageSendError) {
console.log(`Gagal kirim gambar ke-${i+1}, kirim teks sebagai gantinya.`)
await vanzz.sendMessage(m.chat, { text: `Gagal mengirim gambar untuk ${item.title}. ID: ${item.id}` }, { quoted: qtext })
}
}

await vanzz.sendMessage(m.chat, { text: textList.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("Kucing General Error:", e?.response?.data || e)
}
}

handler.help = ['Search Anime Kucing']
handler.tags = ['anime']
handler.command = ['kucing']

export default handler
