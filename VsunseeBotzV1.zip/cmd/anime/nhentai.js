import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix + command} naruto`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/nhentai/search?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}&page=1`)
const { status, result } = res.data
if (!status || !Array.isArray(result) || result.length === 0) {
await reaction(m.chat, '❌')
console.log("NHentai API Response Error:", res.data)
return m.reply(`*[ ❌ ]* Tidak ditemukan hasil untuk *${text}*.`)
}

try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}

const cards = []
for (let i = 0; i < Math.min(result.length, 10); i++) {
const item = result[i]
const { title, cover, url } = item
let imageUrl = cover.startsWith('//') ? `https:${cover}` : cover
let img = await prepareWAMessageMedia({ image: await getImageBuffer(imageUrl) }, { upload: vanzz.waUploadToServer })

const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...img
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `📖 *${title}*\n🔗 nhentai.net`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"Salin Link\",\"id\":\"nh-${i}\",\"copy_code\":\"${url}\"}` }
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*🔞 Hasil Pencarian NHentai:*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)

let listText = `⚠️ *Gagal Load Slide Button*\n\n🔞 *Hasil Pencarian NHentai:*\n\n`
for (let i = 0; i < Math.min(result.length, 5); i++) {
const item = result[i]
const imageUrl = item.cover.startsWith('//') ? `https:${item.cover}` : item.cover
listText += `📖 *${item.title}*\n🔗 ${item.url}\n\n`
try {
const imageBuffer = await axios.get(imageUrl, { responseType: 'arraybuffer' })
await vanzz.sendMessage(m.chat, { 
image: Buffer.from(imageBuffer.data), caption: `📖 ${item.title}\n🔗 ${item.url}` 
}, { quoted: qtext })
} catch (imageSendError) {
console.log(`Gagal kirim gambar ke-${i+1}, kirim teks sebagai gantinya.`)
await vanzz.sendMessage(m.chat, { text: `Gagal mengirim gambar untuk ${item.title}. Link: ${item.url}` }, { quoted: qtext })
}
}
await vanzz.sendMessage(m.chat, { text: listText.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("NHentai General Error:", e?.response?.data || e)
}
}

handler.help = ['Search Nhentai']
handler.tags = ['anime']
handler.command = ['nhentai']

export default handler
