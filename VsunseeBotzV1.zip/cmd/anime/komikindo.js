import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan judul komik!\n\nContoh:\n${prefix + command} Mahiru`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/komikindo/search?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !Array.isArray(result) || !result.length) {
await reaction(m.chat, '❌')
console.log("Komikindo API Response Error:", res.data)
return m.reply(`*[❌]* Komik tidak ditemukan.`)
}

try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}

const cards = []
for (let i = 0; i < Math.min(result.length, 10); i++) {
const item = result[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(item.img) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...img
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `📖 *${item.title}*\n⭐ ${item.score} | 📚 ${item.type}\n📜 Genre: ${item.genre.join(', ')}\n📦 Chapter: ${item.chapter}`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin Link Komik\",\"id\":\"kmk-${i}\",\"copy_code\":\"${item.url}\"}` }
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*📚 Hasil Pencarian Komikindo:*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)

let textList = `⚠️ *Gagal Load Slide Button*\n\n*📚 Hasil Pencarian Komikindo:*\n\n`
for (let i = 0; i < Math.min(result.length, 5); i++) {
const item = result[i]
textList += `📖 *${item.title}*\n⭐ ${item.score} | 📚 ${item.type}\n📜 Genre: ${item.genre.join(', ')}\n📦 Chapter: ${item.chapter}\n🔗 ${item.url}\n\n`
try {
const imageBuffer = await axios.get(item.img, { responseType: 'arraybuffer' })
await vanzz.sendMessage(m.chat, { 
image: Buffer.from(imageBuffer.data), caption: `📖 ${item.title}\n⭐ ${item.score}\n🔗 ${item.url}` 
}, { quoted: qtext })
} catch (imageSendError) {
console.log(`Gagal kirim gambar ke-${i+1}, kirim teks sebagai gantinya.`)
await vanzz.sendMessage(m.chat, { text: `Gagal mengirim gambar untuk ${item.title}. Link: ${item.url}` }, { quoted: qtext })
}
}

await vanzz.sendMessage(m.chat, { text: textList.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("Komikindo General Error:", e?.response?.data || e)
}
}

handler.help = ['Search Komikindo']
handler.tags = ['anime']
handler.command = ['komikindo']

export default handler
