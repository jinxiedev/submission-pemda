import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan URL NHentai!\n\nContoh:\n${prefix + command} https://nhentai.net/g/598016`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const url = encodeURIComponent(text.trim())
const api = `https://${global.VsunseeApi}/vsunseeV8/nhentai/detail?apikey=${global.VsunseeApikey}&url=${url}`
const res = await axios.get(api)
const { status, result } = res.data
if (!status || !result) {
await reaction(m.chat, '❌')
console.log("NHentaiDetail API Response Error:", res.data)
return m.reply(`*[ ❌ ]* Gagal mengambil data doujin.`)
}

const info = result
const coverUrl = info.cover.startsWith('//') ? `https:${info.cover}` : info.cover
const caption = `📖 *${info.title.main || "Tanpa Judul"}*\n🈁 *Judul Jepang:* ${info.title.japanese || "-"}\n🎨 *Artist:* ${info.artists}\n🏷️ *Tag:* ${info.tags}\n💬 *Bahasa:* ${info.languages}\n📂 *Kategori:* ${info.categories}\n📄 *Halaman:* ${info.pages}\n🕒 *Upload:* ${info.uploadDate}\n\n🪄 _Powered By Vann Ryuichi_`


try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}

const preview = info.images.slice(0, 10)
const cards = []
for (let i = 0; i < preview.length; i++) {
const imgUrl = preview[i].startsWith('//') ? `https:${preview[i]}` : preview[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(imgUrl) }, { upload: vanzz.waUploadToServer })

const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...img
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `📄 Halaman ${i + 1}/${info.pages}`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"Salin Link\",\"id\":\"nhdetail-${i}\",\"copy_code\":\"${info.url}\"}` }
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)

let listText = caption + `\n\n⚠️ *Gagal Load Slide Button*\n📸 *Preview Gambar (Max 5):*\n`
for (let i = 0; i < Math.min(info.images.length, 5); i++) {
const imgUrl = info.images[i].startsWith('//') ? `https:${info.images[i]}` : info.images[i]
try {
const imageBuffer = await axios.get(imgUrl, { responseType: 'arraybuffer' })
await vanzz.sendMessage(m.chat, { 
image: Buffer.from(imageBuffer.data), caption: `Halaman ${i + 1}/${info.pages}` 
}, { quoted: qtext })
} catch (imageSendError) {
console.log(`Gagal kirim gambar ke-${i+1}, kirim teks sebagai gantinya.`)
listText += `🖼️ Halaman ${i + 1}: ${imgUrl} (Gagal dimuat)\n`
}
}

await vanzz.sendMessage(m.chat, { text: listText.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("NHentaiDetail General Error:", e?.response?.data || e)
}
}

handler.help = ['Nhentai Detail']
handler.tags = ['anime']
handler.command = ['nhentaidetail']

export default handler
