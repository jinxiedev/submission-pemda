import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan URL anime!\n\nContoh:\n${prefix + command} naruto-shippuuden`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/animeLovers/detail?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !result?.data?.length) {
await reaction(m.chat, '❌')
console.log("AnimeLoversDetail API Response Error:", res.data)
return m.reply(`*[❌]* Data tidak ditemukan.`)
}

const info = result.data[0]
const caption = `🎬 *${info.judul}*\n📺 *Tipe:* ${info.type}\n📊 *Status:* ${info.status}\n⭐ *Rating:* ${info.rating}\n🕒 *Rilis:* ${info.published}\n🏢 *Studio:* ${info.author}\n🎭 *Genre:* ${info.genre.join(', ')}\n📖 *Sinopsis:* ${info.sinopsis.length > 400 ? info.sinopsis.substring(0, 400) + '...' : info.sinopsis}\n\n🪄 _Powered By Vann Ryuichi_`


try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}

const chapters = info.chapter.slice(0, 10)
const cards = []
for (let i = 0; i < chapters.length; i++) {
const c = chapters[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(info.cover) }, { upload: vanzz.waUploadToServer })

const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...img
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `📺 *${c.ch}*\n📅 ${c.date}`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin Link Chapter\",\"id\":\"alch-${i}\",\"copy_code\":\"${c.url}\"}` }
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)

let textRes = caption + `\n\n📜 *Daftar Chapter:*\n`
for (let i = 0; i < Math.min(info.chapter.length, 10); i++) {
let c = info.chapter[i]
textRes += `📺 ${c.ch}\n🔗 ${c.url}\n\n`
}
await vanzz.sendMessage(m.chat, { text: textRes.trim(), quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("AnimeLoversDetail General Error:", e?.response?.data || e)
}
}

handler.help = ['AnimeLovers Detail']
handler.tags = ['anime']
handler.command = ['animeloversdetail']

export default handler
