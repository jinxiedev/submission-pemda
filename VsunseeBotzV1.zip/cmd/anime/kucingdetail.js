import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan ID video!\n\nContoh:\n${prefix + command} 49196`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/kucing/detail?apikey=${global.VsunseeApikey}&id=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !result) {
await reaction(m.chat, '❌')
console.log("KucingDetail API Response Error:", res.data)
return m.reply(`*[❌]* Video tidak ditemukan.`)
}

const info = result
const caption = `🎬 *${info.title}*\n📅 *Tanggal:* ${info.date}\n📚 *Parodi:* ${info.content.match(/Parody\\s*:\\s*(.*?)\\r?\\n/i)?.[1] || '-'}\n🏢 *Studio:* ${info.content.match(/Producers\\s*:\\s*(.*?)\\r?\\n/i)?.[1] || '-'}\n⏱️ *Durasi:* ${info.content.match(/Duration\\s*:\\s*(.*?)\\r?\\n/i)?.[1] || '-'}\n💾 *Ukuran:* ${info.content.match(/Size\\s*:\\s*(.*?)\\r?\\n/i)?.[1] || '-'}\n\n🪄 _Powered By Vann Ryuichi_`


try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}

const downloads = info.download || []
const cards = []

for (let d of downloads) {
let img = await prepareWAMessageMedia({ image: await getImageBuffer(info.image) }, { upload: vanzz.waUploadToServer })
let textDl = `📦 *Resolusi ${d.type}P*\n`
for (let l of d.links) {
textDl += `🔗 ${l.name}\n`
}
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...img
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: textDl
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin Link Mp4Upload ${d.type}P\",\"id\":\"kcd-${d.type}\",\"copy_code\":\"${d.links[0].link}\"}` }
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)

let teks = caption + `\n\n📦 *Link Download:*\n`
const downloads = info.download || []
for (let d of downloads) {
teks += `\n🎞️ *${d.type}P*\n`
for (let l of d.links) teks += `🔗 ${l.name}: ${l.link}\n`
}
await vanzz.sendMessage(m.chat, { text: teks.trim(), quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("KucingDetail General Error:", e?.response?.data || e)
}
}

handler.help = ['Anime Kucing Detail']
handler.tags = ['anime']
handler.command = ['kucingdetail']

export default handler
