import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan judul anime!\n\nContoh:\n${prefix + command} naruto`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/animeLovers/search?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !result?.data?.length) {
await reaction(m.chat, '❌')
console.log("AnimeLovers API Response Error:", res.data)
return m.reply(`*[❌]* Tidak ada hasil untuk *${text}*.`)
}

const list = result.data[0]?.result || []

try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}
const cards = []
for (let i = 0; i < Math.min(list.length, 10); i++) {
const item = list[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(item.cover) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🎬 *${item.judul}*\n📺 ID: ${item.url}` }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"🔖 Salin ID Anime\",\"id\":\"al-${i}\",\"copy_code\":\"${item.url}\"}` }
]
})
}
cards.push(card)
}
const msg = await generateWAMessageFromContent(
m.chat,
{
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*📺 Hasil Pencarian AnimeLovers:*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
},
{ userJid: m.chat, quoted: m }
)
await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)
// FALLBACK: KIRIM GAMBAR SATU PER SATU (MAX 5)
let textList = `⚠️ *Gagal Load Slide Button*\n\n📺 *Hasil Pencarian AnimeLovers:*\n@${m.sender.split('@')[0]}\n\n`
for (let i = 0; i < Math.min(list.length, 5); i++) {
const item = list[i]
textList += `🎬 *${item.judul}*\n🔗 ${item.url}\n\n`
try {
const imageBuffer = await axios.get(item.cover, { responseType: 'arraybuffer' })
await vanzz.sendMessage(m.chat, { 
image: Buffer.from(imageBuffer.data), caption: `🎬 ${item.judul}\n🔗 ${item.url}` 
}, { quoted: qtext })
} catch (imageSendError) {
console.log(`Gagal kirim gambar ke-${i+1}, kirim teks sebagai gantinya.`)
await vanzz.sendMessage(m.chat, { text: `Gagal mengirim gambar untuk ${item.judul}. Link: ${item.url}` }, { quoted: qtext })
}
}

await vanzz.sendMessage(m.chat, { text: textList.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("AnimeLovers General Error:", e?.response?.data || e)
}
}

handler.help = ['Search AnimeLovers']
handler.tags = ['anime']
handler.command = ['animelovers']

export default handler
