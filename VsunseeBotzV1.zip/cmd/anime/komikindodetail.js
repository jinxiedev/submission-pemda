import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan URL komik!\n\nContoh:\n${prefix + command} https://kmkindo.click/?page=manga&id=159998`)
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const api = `https://${global.VsunseeApi}/vsunseeV8/komikindo/detail?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`
const res = await axios.get(api)
const { status, result } = res.data
if (!status || !result?.["0"]) {
await reaction(m.chat, '❌')
console.log("KomikindoDetail API Response Error:", res.data)
return m.reply(`*[❌]* Gagal mengambil data komik.`)
}
const info = result["0"]

const authors = info.author.map(a => a.name).join(', ')
const genres = info.genre.map(g => g.name).join(', ')
const caption = `📚 *${info.title}*\n⭐ *Score:* ${info.score}\n📘 *Tipe:* ${info.type}\n📊 *Status:* ${info.status}\n✍️ *Author:* ${authors}\n🎭 *Genre:* ${genres}\n🎯 *Demographic:* ${info.demographic.map(d => d.name).join(', ')}\n📔 *Tema:* ${info.theme.map(t => t.name).join(', ')}\n\n📝 *Sinopsis:*\n${info.synopsis.length > 400 ? info.synopsis.substring(0, 400) + '...' : info.synopsis}\n\n🪄 _Powered By Vann Ryuichi_`

try {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}
const chaps = info.data.slice(0, 10)
const cards = []

for (let i = 0; i < chaps.length; i++) {
const c = chaps[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(info.cover) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `📖 *Chapter ${c.chapter}*\n📅 URL: ${c.url}` }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin Link Download\",\"id\":\"kmkd-${i}\",\"copy_code\":\"${c.download}\"}` }
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

} catch (slideError) {
console.log("Slide Button Error, initiating fallback:", slideError)

let teks = caption + `\n\n📦 *Daftar Chapter:*\n`
for (let c of info.data.slice(0, 10)) {
teks += `📖 ${c.chapter}\n🔗 ${c.url}\n`
}
await vanzz.sendMessage(m.chat, { text: teks.trim(), quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("KomikindoDetail General Error:", e?.response?.data || e)
}
}

handler.help = ['Komikindo Detail']
handler.tags = ['anime']
handler.command = ['komikindodetail']

export default handler
