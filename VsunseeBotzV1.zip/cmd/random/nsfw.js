import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let mediaUrl = `https://${global.VsunseeApi}/vsunseeV8/nsfw?apikey=${global.VsunseeApikey}`
let res = await fetch(mediaUrl, { method: 'HEAD' })
let contentType = res.headers.get('content-type') || ""
await reaction(m.chat, '✨')
let msg = {}
if (contentType.startsWith('image/')) {
msg = {
image: { url: mediaUrl },
caption: `🔞 *NSFW RANDOM IMAGE*\n\n🪄 _Powered By Vann Ryuichi_`
}
} else if (contentType.startsWith('video/')) {
msg = {
video: { url: mediaUrl },
mimetype: contentType,
caption: `🔞 *NSFW RANDOM VIDEO*\n\n🪄 _Powered By Vann Ryuichi_`
}
} else {
return vanzz.sendMessage(m.chat, { text: `⚠️ Tidak dapat mengenali format media.\n🔗 ${mediaUrl}` }, { quoted: qtext })
}
if (modesend !== false) {
msg.contextInfo = {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: contentType.startsWith('image/') ? "NSFW RANDOM IMAGE" : "NSFW RANDOM VIDEO",
body: contentType.startsWith('image/') ? "Klik untuk melihat gambar" : "Klik untuk memutar video",
thumbnailUrl: mediaUrl,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: mediaUrl
}
}
}
await vanzz.sendMessage(m.chat, msg, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("NSFW Error:", e)
}
}

handler.help = ['Random Nsfw']
handler.tags = ['random']
handler.command = ['nsfw']

export default handler