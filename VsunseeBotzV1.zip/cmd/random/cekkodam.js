import axios from 'axios'
import "../../settings/config.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try {
if (!text) return m.reply(`🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nama_kamu\n\n📍 Contoh:\n${prefix + command} Vanz`)

await vanzz.sendMessage(m.chat, { react: { text: '🔮', key: m.key } })
const apiUrl = `https://${global.VsunseeApi}/vsunseeV8/cekkodam?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`
const res = await axios.get(apiUrl, { timeout: 15000 })
const { status, result } = res.data

if (!status || !result?.message) return vanzz.sendMessage(m.chat, { text: '❌ Gagal menemukan khodam.' })

await vanzz.sendMessage(m.chat, {
text: result.message,
contextInfo: {
externalAdReply: {
title: `🔮 Khodam ${result.nama}`,
body: `✨ ${result.khodam}`,
thumbnailUrl: global.ThumbnailUrl,
sourceUrl: apiUrl,
mediaType: 1,
renderLargerThumbnail: true
}
}
})
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('CEKKODAM ERROR:', e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Cek Khodam Nama']
handler.tags = ['random']
handler.command = ['cekkodam']

export default handler