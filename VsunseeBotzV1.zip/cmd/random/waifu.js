import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let imageUrl = `https://${global.VsunseeApi}/vsunseeV8/waifu?apikey=${global.VsunseeApikey}`
await reaction(m.chat, '✨')
let msg = {
image: { url: imageUrl },
caption: `🖼️ *RANDOM WAIFU*\n\n🪄 _Powered By Vann Ryuichi_`
}
if (modesend !== false) {
msg.contextInfo = {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: "Waifu Image",
body: "Klik untuk melihat gambar",
thumbnailUrl: imageUrl,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: imageUrl
}
}
}
await vanzz.sendMessage(m.chat, msg, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("WAIFU Error:", e)
}
}

handler.help = ['Random Waifu']
handler.tags = ['random']
handler.command = ['waifu']

export default handler