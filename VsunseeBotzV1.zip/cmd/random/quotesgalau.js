import axios from 'axios'
import "../../settings/config.js"

let handler = async (m, { vanzz, prefix, command }) => {
try {
await vanzz.sendMessage(m.chat, { react: { text: '🔎', key: m.key } })
const apiUrl = `https://${global.VsunseeApi}/vsunseeV8/quotesgalau?apikey=${global.VsunseeApikey}`
const res = await axios.get(apiUrl, { timeout: 15000 })
const { status, result } = res.data
if (!status || !result) return vanzz.sendMessage(m.chat, { text: '❌ Gagal mengambil quote.' })
await vanzz.sendMessage(m.chat, {
text: result,
contextInfo: {
externalAdReply: {
title: 'Quotes Galau 💔',
body: 'Vanzz Ryuichi',
thumbnailUrl: global.ThumbnailUrl,
sourceUrl: apiUrl,
mediaType: 1,
renderLargerThumbnail: true
}
}
})
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('QUOTESG collapse ERROR:', e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Random Quotes Galau']
handler.tags = ['random']
handler.command = ['quotesgalau']

export default handler