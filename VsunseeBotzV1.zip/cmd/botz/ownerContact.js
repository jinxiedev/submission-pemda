import { qtext } from "../../source/quoted.js"; 
import '../../settings/config.js';

let handler = async (m, { vanzz, from }) => {
try {
const ownerNumber = '6288276746473';
const ownerName = global.nameown;

const vCard = `BEGIN:VCARD\nVERSION:3.0\nFN:${ownerName}\nTEL;waid=${ownerNumber}:${ownerNumber}\nEND:VCARD`;

await vanzz.sendMessage(m.chat, {
    contacts: {
        displayName: global.nameown,
        contacts: [{ vcard: vCard }],
    },
}, { quoted: qtext });

} catch (err) {
console.error("OWNER HANDLER ERROR:", err);
await vanzz.sendMessage(m.chat, { text: "❌ Terjadi kesalahan saat mengirim kontak owner." }); 
}
}

handler.help = ["Contact Owner"];
handler.tags = ["botz"];
handler.command = ["owner"];

export default handler;