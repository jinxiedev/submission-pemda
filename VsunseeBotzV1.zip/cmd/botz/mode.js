import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzz, reaction }) => {
try {
await reaction(m.chat, '🧠')
await vanzreply(m, `🤖 Bot Mode: ${vanzz.public ? 'Public' : 'Self'}`)
await reaction(m.chat, '☑️')
} catch (e) {
console.error('MODE CHECK ERROR:', e)
await reaction(m.chat, '🙅‍♂️')
await vanzreply(m, '❌ Failed To Check Mode')
}
}

handler.help = ['Cek Mode Bot']
handler.tags = ['botz']
handler.command = ['mode']

export default handler