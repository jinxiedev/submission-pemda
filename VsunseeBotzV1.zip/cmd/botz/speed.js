import moment from 'moment-timezone'
import { runtime } from '../../source/myfunc.js'
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m) => {
try {
const start = Date.now()
const latency = Date.now() - start
const speed = moment
.duration(Date.now() - parseInt(m.messageTimestamp.toString()) * 1000)
.asSeconds()
.toFixed(2)
const up = runtime(process.uptime())

const teks = `
• 📶 *Ping:* ${latency} ms (${speed} sec)
• ⏱️ *Runtime:* ${up}
`
await vanzreply(m, teks)
} catch (err) {
console.error('SPEED HANDLER ERROR:', err)
await vanzreply(m, '❌ Terjadi kesalahan saat menampilkan speed/runtime.')
}
}

handler.help = ['Cek Latensy Dan Speed Respond']
handler.tags = ['botz']
handler.command = ['speed', 'runtime']

export default handler