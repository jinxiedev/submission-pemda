import { createCanvas, loadImage } from 'canvas';
import os from 'os';
import nou from 'node-os-utils'; 
import speed from 'performance-now'; 
import { runtime } from '../../source/myfunc.js'; 
import { vanzreply } from '../../source/vanzreply.js'; 
import { qtext } from "../../source/quoted.js";

const WIDTH = 800;
const HEIGHT = 600;
const COLOR_BG = '#121212';
const COLOR_CARD = '#1e1e1e';
const COLOR_TEXT = '#ffffff';
const COLOR_SUBTEXT = '#aaaaaa';
const COLOR_OPERATIONAL = '#28a745'; // Hijau
const COLOR_WARNING = '#ffc107';   // Oranye
const COLOR_PRIMARY = '#007bff';   // Biru
const CORNER_RADIUS = 30; // Sudut

function roundRect(ctx, x, y, width, height, radius) {
ctx.beginPath();
ctx.moveTo(x + radius, y);
ctx.lineTo(x + width - radius, y);
ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
ctx.lineTo(x + width, y + height - radius);
ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
ctx.lineTo(x + radius, y + height);
ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
ctx.lineTo(x, y + radius);
ctx.quadraticCurveTo(x, y, x + radius, y);
ctx.closePath();
}

/**
 * kotak metrik CPU, Memory, Disk
 */
function drawMetricCard(ctx, x, y, cardW, cardH, title, usage, subtext, detail, color) { 
const padding = 20;

ctx.fillStyle = COLOR_CARD;
roundRect(ctx, x, y, cardW, cardH, CORNER_RADIUS); 
ctx.fill();

ctx.fillStyle = COLOR_SUBTEXT;
ctx.font = '16px sans-serif';
ctx.fillText(title, x + padding, y + 30);

ctx.fillStyle = (title.includes("Disk") && usage > 60) ? COLOR_WARNING : COLOR_OPERATIONAL;
ctx.beginPath();
ctx.arc(x + cardW - padding, y + 25, 5, 0, Math.PI * 2, true);
ctx.fill();

ctx.fillStyle = COLOR_TEXT;
ctx.font = '36px sans-serif';
ctx.fillText(`${usage}%`, x + padding, y + 80);

ctx.fillStyle = COLOR_SUBTEXT;
ctx.font = '12px sans-serif';
ctx.fillText(subtext, x + padding, y + 100);
ctx.fillText(detail, x + padding, y + 115);

const barY = y + cardH - 25;
const barW = cardW - 2 * padding; 
ctx.fillStyle = '#333333';
ctx.fillRect(x + padding, barY, barW, 6);

ctx.fillStyle = color;
ctx.fillRect(x + padding, barY, barW * (usage / 100), 6);
}

/**
 * grafik Network Latency
 */
function drawLatencyChart(ctx, x, y, w, h, data, ping) {
const padding = 30;
const chartW = w - 2 * padding;
const chartH = h - 2 * padding;

ctx.fillStyle = COLOR_CARD;
roundRect(ctx, x, y, w, h, CORNER_RADIUS); 
ctx.fill();

ctx.fillStyle = COLOR_TEXT;
ctx.font = '18px sans-serif';
ctx.fillText('Network Latency', x + padding, y + 30);

ctx.fillStyle = COLOR_PRIMARY;
ctx.font = '24px sans-serif';
ctx.fillText(`${ping}ms`, x + w - padding - ctx.measureText(`${ping}ms`).width, y + 30);

if (data.length === 0) data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; 
const maxVal = Math.max(...data, 50, 100); 
const stepX = chartW / (data.length - 1);

ctx.strokeStyle = COLOR_PRIMARY;
ctx.lineWidth = 2;
ctx.beginPath();

data.forEach((value, index) => {
const pointX = x + padding + index * stepX;
const pointY = y + h - padding - (value / maxVal) * chartH; 

if (index === 0) {
ctx.moveTo(pointX, pointY);
} else {
ctx.lineTo(pointX, pointY);
}
});

ctx.stroke();
 
ctx.strokeStyle = '#333333';
ctx.lineWidth = 1;
ctx.font = '10px sans-serif';
ctx.fillStyle = COLOR_SUBTEXT;
for (let i = 0; i <= 100; i += 25) {
const lineY = y + h - padding - (i / maxVal) * chartH;
ctx.beginPath();
ctx.moveTo(x + padding, lineY);
ctx.lineTo(x + w - padding, lineY);
ctx.stroke();
ctx.fillText(i.toString(), x + 5, lineY + 3);
}
}


/**
 * seluruh dashboard
 */
async function drawDashboard(serverData) {
const canvas = createCanvas(WIDTH, HEIGHT);
const ctx = canvas.getContext('2d');

ctx.fillStyle = COLOR_BG;
ctx.fillRect(0, 0, WIDTH, HEIGHT);

const margin = 30;
const startX = margin;
const startY = margin;
const gap = 20; 
const numColumns = 3;

const totalContentWidth = WIDTH - 2 * margin; 
const calculatedCardW = (totalContentWidth - (numColumns - 1) * gap) / numColumns;
const cardH_metric = 150; 
const cardH_info = 100;   

const now = new Date();
const formattedTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
const formattedDate = now.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });

ctx.fillStyle = COLOR_TEXT;
ctx.font = '24px sans-serif';
ctx.fillText('INFORMASI VPS SERVER', startX, startY + 10);

ctx.fillStyle = COLOR_SUBTEXT;
ctx.font = '14px sans-serif';
ctx.fillText('Real-Time Performance Report For Kanatasg', startX, startY + 30);

ctx.fillStyle = COLOR_OPERATIONAL;
ctx.font = '14px sans-serif';
ctx.fillText('Operational', WIDTH - 200, startY + 10);
ctx.fillStyle = COLOR_SUBTEXT;
ctx.fillText(`Last Ping: ${serverData.ping}ms`, WIDTH - 200, startY + 30);
ctx.fillText(`Updated: ${formattedTime}`, WIDTH - 200, startY + 50);

const overviewY = startY + 70;
ctx.fillStyle = '#1a1a1a';
roundRect(ctx, startX, overviewY, totalContentWidth, 80, CORNER_RADIUS); 
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '18px sans-serif';
ctx.fillText('System Overview', startX + 20, overviewY + 25);
ctx.font = '14px sans-serif';
ctx.fillText(`OS: ${serverData.os}`, startX + 20, overviewY + 50);
ctx.fillText(`CPU: ${serverData.cpuCores} cores`, startX + 300, overviewY + 50);

const metricsY = overviewY + 80 + gap;
drawMetricCard(
ctx, startX, metricsY, calculatedCardW, cardH_metric, // [1] CPU
'# CPU Usage', serverData.cpuUsage, 
`${serverData.cpuCores} Cores`, `${serverData.cpuModel.substring(0, 30)}...`, 
COLOR_PRIMARY
);
drawMetricCard(
ctx, startX + calculatedCardW + gap, metricsY, calculatedCardW, cardH_metric, // [2] Memory
'= Memory', serverData.memUsage, 
`${serverData.memUsed} GiB / ${serverData.memTotal} GiB`, '', 
COLOR_OPERATIONAL
);
drawMetricCard(
ctx, startX + 2 * (calculatedCardW + gap), metricsY, calculatedCardW, cardH_metric, // [3] Disk (Masalah lebar teratasi di sini)
'💿 Disk', serverData.diskUsage, 
`${serverData.diskUsed} GiB / ${serverData.diskTotal} GiB`, '', 
COLOR_WARNING
);

const infoY = metricsY + cardH_metric + gap; 


ctx.fillStyle = COLOR_CARD;
roundRect(ctx, startX, infoY, calculatedCardW, cardH_info, CORNER_RADIUS); 
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '16px sans-serif';
ctx.fillText('CPU Model', startX + 20, infoY + 30);
ctx.fillStyle = COLOR_OPERATIONAL;
ctx.beginPath();
ctx.arc(startX + calculatedCardW - 20, infoY + 25, 5, 0, Math.PI * 2, true);
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '14px sans-serif';
const fullModel = serverData.cpuModel;
const maxChars = 20;
const line1 = fullModel.length > maxChars ? fullModel.substring(0, maxChars).trim() : fullModel;
const line2 = fullModel.length > maxChars ? fullModel.substring(maxChars).trim() : '';
ctx.fillText(line1 + (line2 ? '...' : ''), startX + 20, infoY + 60);
if (line2) {
 ctx.fillText(line2, startX + 20, infoY + 75);
}


ctx.fillStyle = COLOR_CARD;
roundRect(ctx, startX + calculatedCardW + gap, infoY, calculatedCardW, cardH_info, CORNER_RADIUS); 
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '16px sans-serif';
ctx.fillText('Operating System', startX + calculatedCardW + gap + 20, infoY + 30); 
ctx.fillStyle = COLOR_OPERATIONAL;
ctx.beginPath();
ctx.arc(startX + calculatedCardW + gap + calculatedCardW - 20, infoY + 25, 5, 0, Math.PI * 2, true); 
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '14px sans-serif';
ctx.fillText(serverData.os, startX + calculatedCardW + gap + 20, infoY + 60); 

ctx.fillStyle = COLOR_CARD;
roundRect(ctx, startX + 2 * (calculatedCardW + gap), infoY, calculatedCardW, cardH_info, CORNER_RADIUS); // [3] Uptime (Masalah lebar teratasi di sini)
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '16px sans-serif';
ctx.fillText('Uptime', startX + 2 * (calculatedCardW + gap) + 20, infoY + 30);
ctx.fillStyle = COLOR_OPERATIONAL;
ctx.beginPath();
ctx.arc(startX + 2 * (calculatedCardW + gap) + calculatedCardW - 20, infoY + 25, 5, 0, Math.PI * 2, true);
ctx.fill();
ctx.fillStyle = COLOR_TEXT;
ctx.font = '14px sans-serif';
ctx.fillText(serverData.uptime, startX + 2 * (calculatedCardW + gap) + 20, infoY + 60);

const chartY = infoY + cardH_info + gap; 
drawLatencyChart(ctx, startX, chartY, totalContentWidth, 180, serverData.latencyHistory, serverData.ping);

return canvas.toBuffer('image/png');
}



// HANDLER 
let handler = async (m, { vanzz }) => {
try {

const totalRam = os.totalmem();
const freeRam = os.freemem();
const usedRam = totalRam - freeRam;
const cpus = os.cpus();
const cpuModel = cpus.length ? cpus[0].model : 'N/A';
const cpuCores = cpus.length;
const cpuUsage = await nou.cpu.usage(); 

let driveInfo = { totalGb: 0, usedGb: 0, usedPercentage: 0 };
try {
const driveData = await nou.drive.info();
driveInfo.totalGb = parseFloat(driveData.totalGb) || 0;
driveInfo.usedGb = parseFloat(driveData.usedGb) || 0;
if (driveInfo.totalGb > 0) {
driveInfo.usedPercentage = ((driveInfo.usedGb / driveInfo.totalGb) * 100);
}
} catch (e) {
console.error('Drive Info Error:', e);
}

const start = speed();
const temp = speed(); 
const latency = ((temp - start) * 1000).toFixed(0); 

const latencyHistory = global.latencyHistory || [15, 18, 20, 19, 17, 22, 25, 30, 28, 21];

const data = {
os: `${os.type()} ${os.release()}`,
cpuCores: cpuCores,
uptime: runtime(os.uptime()),
ping: latency,
cpuUsage: parseFloat(cpuUsage.toFixed(2)),
memUsage: parseFloat(((usedRam / totalRam) * 100).toFixed(2)),
memUsed: parseFloat((usedRam / (1024 ** 3)).toFixed(2)),
memTotal: parseFloat((totalRam / (1024 ** 3)).toFixed(2)),
diskUsage: parseFloat(driveInfo.usedPercentage.toFixed(2)),
diskUsed: parseFloat(driveInfo.usedGb.toFixed(2)),
diskTotal: parseFloat(driveInfo.totalGb.toFixed(2)),
cpuModel: cpuModel,
latencyHistory: latencyHistory
};

const buffer = await drawDashboard(data);
await vanzz.sendMessage(m.chat, { image: buffer, caption: " " }, { quoted: qtext });

} catch (error) {
console.error('Handler Error:', error);
await vanzreply(m, '❌ Terjadi kesalahan saat mengirim.\n' + error.message);
}
}

handler.help = ['Check Spesifikasi Server Bot']
handler.tags = ['botz']
handler.command = ['ping', 'uptime']

export default handler
