import fs from 'fs'
import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📨',key:m.key}})
let thumbBuffer
if(global.ThumbnailUrl?.startsWith('http')){
const res=await axios.get(global.ThumbnailUrl,{responseType:'arraybuffer'})
thumbBuffer=Buffer.from(res.data)
}else{
thumbBuffer=fs.existsSync(global.ThumbnailUrl)?fs.readFileSync(global.ThumbnailUrl):Buffer.alloc(0)
}
const invit=generateWAMessageFromContent(
m.chat,
proto.Message.fromObject({
groupInviteMessage:{
groupJid:global.GroupID,
inviteCode:"D6ZkmV5xPqx18wp68gAJOZ",
inviteExpiration:Math.floor(Date.now()/1000)+7*24*60*60,
groupName:"Hytam",
jpegThumbnail:thumbBuffer,
caption:"📩 Bergabung Dengan Kami Di Group Orang Hytam\nhttps://chat.whatsapp.com/D6ZkmV5xPqx18wp68gAJOZ",
contextInfo:{mentionedJid:[m.sender]}
}
}),
{userJid:m.sender,quoted:m}
)
await vanzz.relayMessage(m.chat,invit.message,{messageId:invit.key.id})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('GROUP INVITE ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['invitegroup']
handler.tags=['botz']
handler.command=['invitegroup']

export default handler