import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzreply }) => {
await vanzreply(m, 'Botz Active 🗯')
}

handler.help = ['tes']
handler.tags = ['botz']
handler.command = ['tes']

export default handler