import fs from "fs"
import path from "path"
import { pathToFileURL } from "url"
import "../../settings/config.js"
import "../../settings/thumb.js"
import { Ucapan } from "../../source/events/ucapan.js"
import { loadingProgress } from "../../source/events/loading.js"

let handler = async (m,{vanzz,pushName,runtime,sender})=>{
let old=performance.now()
await vanzz.sendMessage(m.chat,{react:{text:'☄️',key:m.key}})
await loadingProgress(vanzz, m.chat, m)
const user=global.db?.users?.[m.sender]||{role:"User"}
let neww=performance.now()
let speed=((neww-old)/1000).toFixed(4)
const ownerList=Array.isArray(global.owner)?global.owner.join(',').split(',').map(v=>v.trim()):(global.owner||'').split(',').map(v=>v.trim())
const dbOwners=(global.db?.owners||[]).map(v=>v.trim())
const isOwner=ownerList.includes(sender.split('@')[0])||dbOwners.includes(sender.split('@')[0])||m.key.fromMe
const premiumPath=path.join(process.cwd(),'source','database','premium.json')
let premiumUsers=[]
if(fs.existsSync(premiumPath)){try{premiumUsers=JSON.parse(fs.readFileSync(premiumPath))}catch{}}
const userId=sender.replace(/[^0-9]/g,'')
const isPremium=premiumUsers.includes(userId)
const predikat=isOwner?'Owner 👑':isPremium?'Premium 💎':'User ✨'
const cmdDir=path.join(process.cwd(),'cmd')
let categories={}
const scanCommands=async(dir)=>{
const entries=fs.readdirSync(dir,{withFileTypes:true})
for(const entry of entries){
const fullPath=path.join(dir,entry.name)
if(entry.isDirectory()){
await scanCommands(fullPath)
}else if(entry.name.endsWith('.js')){
try{
const plugin=await import(`${pathToFileURL(fullPath)}?update=${Date.now()}`)
const data=plugin.default||{}
if(data.tags&&data.command){
data.tags.forEach(tag=>{
if(!categories[tag])categories[tag]=[]
categories[tag].push(data.command.map(cmd=>`␥.${cmd}`).join('\n'))
})
}
}catch(e){
console.error('Gagal load plugin:',fullPath,e.message)
}
}
}
}
await scanCommands(cmdDir)
function formatCategoryName(str){
return str.replace(/_/g,' ').split(' ').map(w=>w.charAt(0).toUpperCase()+w.slice(1).toLowerCase()).join(' ')
}
let menuText=''
for(const[tag,cmds]of Object.entries(categories)){
const categoryName=formatCategoryName(tag)

menuText+=`「 \`×̷̷͜流 Cmd ${categoryName} 流̷̷͜×\`̷ 」\n${cmds.flat().join('\n')}\n\n`
}
const buttons=[
{title:'🏠 ʙᴀᴄᴋ ᴍᴇɴᴜ',description:'🔙 ᴋᴇ ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ',id:'.menu'},
{title:'👑 ᴏᴡɴᴇʀ',description:'☄️ ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ',id:'.owner'}
]
const message={
footer:global.namebotz,
headerType:1,
viewOnce:false,
image:{url:global.ThumbnailUrl},
caption:`\`🔖 ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ʙᴏᴛᴢ\`\n⌬ ʙᴏᴛ ɴᴀᴍᴇ: ${global.namebotz}\n⌬ ᴍᴏᴅᴇ: ${vanzz.public?'Public':'Self'}\n⌬ sᴘᴇᴇᴅ: ${speed} Sec\n⌬ ʀᴜɴᴛɪᴍᴇ: ${runtime(process.uptime())}\n⌬ ʟᴀɴɢᴜᴀɢᴇ: Java Script\n\n\`🦠 ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ᴜꜱᴇʀ\`\n⌬ ɴᴀᴍᴀ: ${pushName}\n⌬ ɴᴏᴍᴏʀ: ${sender.split('@')[0]}\n⌬ ᴘʀᴇᴅɪᴋᴀᴛ: ${predikat}\n⌬ ʀᴏʟᴇ: ${user.role}\n\n\n${menuText}`,
buttons:[
{
buttonId:'action',
buttonText:{displayText:'Pilih Opsi'},
type:4,
nativeFlowInfo:{
name:'single_select',
paramsJson:JSON.stringify({
title:'🔖 ꜱᴇʟᴇᴄᴛ ᴏᴘᴛɪᴏɴ',
sections:[
{
title:'ᴠᴀɴɴ ʀʏᴜɪᴄʜɪ🩸',
rows:buttons.map(btn=>({
title:btn.title,
description:btn.description||'',
id:btn.id
}))
}
]
})
}
}
],
contextInfo:{
forwardingScore:999,
isForwarded:true,
mentionedJid:[m.sender],
forwardedNewsletterMessageInfo:{
newsletterName:global.nameown,
newsletterJid:global.ChannelID
},
externalAdReply:{
title:global.namebotz,
body:`${Ucapan()}`,
thumbnailUrl:global.AvatarUrl,
sourceUrl:global.ChannelWA,
mediaType:1,
renderLargerThumbnail:false
}
}
}
await vanzz.sendMessage(m.chat,message,{quoted:null})
}
handler.help=['Semua Fitur']
handler.tags=['menu']
handler.command=['menuall']
export default handler