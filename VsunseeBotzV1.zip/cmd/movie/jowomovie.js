import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🎥')
const modesend = global.modesend

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/jowomovie/list?apikey=${global.VsunseeApikey}&category=hot`)
if (!res.data.status) return m.reply('*[❌]* Tidak ada data movie ditemukan.')

const list = res.data.result.result
if (modesend === 'button') {
const cards = []
for (let i = 0; i < Math.min(list.length, 10); i++) {
const mv = list[i]
let img = await prepareWAMessageMedia({ image: { url: mv.thumb } }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🎬 *${mv.title}*\n🆔 VID: ${mv.vid}` }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin VID\",\"id\":\"jowo-${i}\",\"copy_code\":\"${mv.vid}\"}` }
]
})
}
cards.push(card)
}
const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: { message: { interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🎬 *Daftar Movie Terpopuler (JowoMovie)*\n@${m.sender.split('@')[0]}` }),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
}) } }
}, { userJid: m.chat, quoted: m })
await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
} else {
let teks = `🎬 *Daftar Movie Terpopuler (JowoMovie)*\n\n`
for (let mv of list.slice(0, 10)) {
teks += `🎥 *${mv.title}*\n🆔 VID: ${mv.vid}\n\n`
}
await vanzz.sendMessage(m.chat, { text: teks.trim(), quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("JowoMovie Error:", e)
}
}

handler.help = ['Jowomovie Search']
handler.tags = ['movie']
handler.command = ['jowomovie']

export default handler