import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
await reaction(m.chat, '🐉')
const modesend = global.modesend
try {
if (!text) return m.reply(`⚠️ Masukkan judul donghua!\n\nContoh:\n${prefix + command} Hitori No Shita`)
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/donghub/search?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !Array.isArray(result) || !result.length) return m.reply(`*[❌]* Tidak ada hasil ditemukan.`)

if (modesend === 'button') {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}
const cards = []
for (let i = 0; i < Math.min(result.length, 10); i++) {
const item = result[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(item.image) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🎬 *${item.title}*\n📺 *Tipe:* ${item.type}\n📦 *Status:* ${item.episode_info}` }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin Link Nonton\",\"id\":\"donghub-${i}\",\"copy_code\":\"${item.url}\"}` }
]
})
}
cards.push(card)
}
const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*🐲 Hasil Pencarian Donghua:*\n@${m.sender.split('@')[0]}`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })
await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
} else {
let textMsg = `🐉 *Hasil Pencarian Donghua:*\n\n`
for (let i = 0; i < Math.min(result.length, 10); i++) {
const d = result[i]
textMsg += `🎬 *${d.title}*\n📺 ${d.type} | ${d.episode_info}\n🔗 ${d.url}\n\n`
}
await vanzz.sendMessage(m.chat, { text: textMsg.trim(), quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("Donghub Error:", e)
}
}

handler.help = ['Donghub Search']
handler.tags = ['movie']
handler.command = ['donghub']

export default handler