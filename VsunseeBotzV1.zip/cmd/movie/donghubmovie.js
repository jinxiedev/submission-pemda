import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🎞️')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/donghub/movies?apikey=${global.VsunseeApikey}`)
const { status, result } = res.data
if (!status || !Array.isArray(result) || !result.length) return m.reply(`*[❌]* Tidak ada movie ditemukan.`)

if (modesend === 'button') {
async function getImageBuffer(url) {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data)
}
const cards = []
for (let i = 0; i < Math.min(result.length, 10); i++) {
const item = result[i]
let img = await prepareWAMessageMedia({ image: await getImageBuffer(item.image) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🎥 *${item.title}*\n📺 *Status:* ${item.status || '-'}\n📦 *Info:* ${item.episode_info}` }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_url", "buttonParamsJson": `{\"display_text\":\"🌐 Buka di Donghub\",\"url\":\"${item.url}\"}` }
]
})
}
cards.push(card)
}
const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*🎬 Daftar Donghua Movie (Donghub):*\n@${m.sender.split('@')[0]}`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: m })
await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
} else {
let listText = `🎬 *Daftar Donghua Movie:*\n\n`
for (let i = 0; i < Math.min(result.length, 10); i++) {
const mv = result[i]
listText += `🎥 *${mv.title}*\n📺 ${mv.status}\n🔗 ${mv.url}\n\n`
}
await vanzz.sendMessage(m.chat, { text: listText.trim(), quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("DonghubMovie Error:", e)
}
}

handler.help = ['Donghub Movie Detail']
handler.tags = ['movie']
handler.command = ['donghubmovie']

export default handler