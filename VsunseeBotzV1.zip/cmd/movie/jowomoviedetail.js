import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"
import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from '@whiskeysockets/baileys'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan VID movie!\n\nContoh:\n${prefix + command} 12412`)
await reaction(m.chat, '⏳')
const modesend = global.modesend

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/jowomovie/detail?apikey=${global.VsunseeApikey}&vid=${text}`)
if (!res.data.status || !res.data.result.success) return m.reply('*[❌]* Data tidak ditemukan.')

const eps = res.data.result.result.slice(0, 20)
const caption = `🎞️ *JowoMovie Player*\n🆔 VID: ${text}\n📺 Total Episode: ${res.data.result.result.length}\n\nPilih salah satu episode di bawah buat salin link video 🔽`

if (modesend === 'button') {
const cards = []
for (let i = 0; i < eps.length; i++) {
const e = eps[i]
let img = await prepareWAMessageMedia({ image: { url: e.thumb } }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({ text: `🎬 *Episode ${e.dramaNum}*\n🔗 Klik tombol di bawah buat salin link M3U8` }),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{ "name": "cta_copy", "buttonParamsJson": `{\"display_text\":\"📋 Salin Link M3U8\",\"id\":\"ep-${i}\",\"copy_code\":\"${e.playUrl}\"}` }
]
})
}
cards.push(card)
}
const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: { message: { interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
}) } }
}, { userJid: m.chat, quoted: m })
await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
} else {
let teks = caption + '\n\n'
for (let e of eps) {
teks += `🎬 *Episode ${e.dramaNum}*\n🔗 ${e.playUrl}\n\n`
}
await vanzz.sendMessage(m.chat, { text: teks.trim(), quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("JowoMovieDetail Error:", e)
}
}

handler.help = ['Jowomovie Detail']
handler.tags = ['movie']
handler.command = ['jowomoviedetail']

export default handler