import axios from 'axios'
import "../../settings/config.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try {
if (!text) return m.reply(`🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} <kata kunci>\n\n📍 Contoh:\n${prefix + command} Cat`)

await vanzz.sendMessage(m.chat, { react: { text: '🎬', key: m.key } })
const apiUrl = `https://${global.VsunseeApi}/vsunseeV8/tiktoks?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(text)}`
const res = await axios.get(apiUrl, { timeout: 20000 })
const { status, data } = res.data
if (!status || !data?.length) return vanzz.sendMessage(m.chat, { text: '❌ Tidak ada hasil video TikTok ditemukan.' })

const vid = data[0] // ambil video pertama
const caption = `🎥 *TikTok Search Result*\n\n📌 *Judul:* ${vid.title || '-'}\n👤 *Author:* ${vid.author?.nickname || vid.author?.unique_id || '-'}\n🎶 *Audio:* ${vid.music_info?.title || '-'}\n💬 *Views:* ${vid.play_count?.toLocaleString() || 0}\n❤️ *Likes:* ${vid.digg_count?.toLocaleString() || 0}\n🔁 *Shares:* ${vid.share_count?.toLocaleString() || 0}\n\n🌐 *URL Video:* [Klik di sini](${vid.play})`

await vanzz.sendMessage(m.chat, {
video: { url: vid.play },
caption,
contextInfo: {
externalAdReply: {
title: vid.author?.nickname || 'TikTok Video',
body: vid.title?.slice(0, 70) || 'TikTok Content',
thumbnailUrl: vid.cover || global.ThumbnailUrl,
sourceUrl: vid.play,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: m })

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('TIKTOKS ERROR:', e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
await vanzz.sendMessage(m.chat, { text: '❌ Terjadi kesalahan saat mengambil data TikTok.' })
}
}

handler.help = ['Cari video TikTok']
handler.tags = ['search']
handler.command = ['tiktoksearch']

export default handler