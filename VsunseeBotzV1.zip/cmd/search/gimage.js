import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci gambar!\n\nContoh:\n${prefix+command} kucing makan ikan`)
await reaction(m.chat,'🔍')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/gimage?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,results}=res.data
if(!status||!Array.isArray(results)||!results.length)return m.reply(`*[❌]* Tidak ada gambar ditemukan.`)

if(modesend==='xreply'){
let teks=`🖼️ *Hasil Pencarian Google Image: ${text}*\n\n`
for(const r of results.slice(0,5)){
teks+=`📸 *${r.image_name}*\n🔗 ${r.original_url}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"Google Image Search",body:"Hasil pencarian gambar dari Google",thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg",mediaType:1,renderLargerThumbnail:true,showAdAttribution:false,sourceUrl:"https://www.google.com/imghp"}}},{quoted:qtext})
}

else if(modesend==='button'){
async function getBuffer(url){const a=await axios.get(url,{responseType:'arraybuffer'});return Buffer.from(a.data)}
const cards=[]
for(let i=0;i<Math.min(results.length,10);i++){
const imgd=results[i]
let img=await prepareWAMessageMedia({image:await getBuffer(imgd.preview_url)},{upload:vanzz.waUploadToServer})
const card={
header:proto.Message.InteractiveMessage.Header.fromObject({hasMediaAttachment:true,...img}),
body:proto.Message.InteractiveMessage.Body.fromObject({text:`🖼️ *${imgd.image_name}*`}),
nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({buttons:[
{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"🔗 Lihat Gambar Asli\",\"url\":\"${imgd.original_url}\"}`}
]})
}
cards.push(card)
}
const msg=await generateWAMessageFromContent(m.chat,{viewOnceMessageV2Extension:{message:{interactiveMessage:proto.Message.InteractiveMessage.fromObject({
body:proto.Message.InteractiveMessage.Body.fromObject({text:`🐾 *Hasil Gambar dari Google:*\n@${m.sender.split('@')[0]}`}),
carouselMessage:proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards})
})}}},{userJid:m.chat,quoted:qtext})
await vanzz.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
}

else{
let teks=`🖼️ *Hasil Pencarian Google Image: ${text}*\n\n`
for(const r of results.slice(0,10)){
teks+=`📸 *${r.image_name}*\n🔗 ${r.original_url}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Google Image.*')
}
}

handler.help=['Gimage Search']
handler.tags=['search']
handler.command=['gimage']

export default handler