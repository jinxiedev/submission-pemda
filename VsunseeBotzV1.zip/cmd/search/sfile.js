import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan nama file untuk dicari!\n\nContoh:\n${prefix+command} pdf`)
await reaction(m.chat,'📂')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/sfile?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan di Sfile.`)

let teks=`📂 *Hasil Sfile untuk:* _${text}_\n\n`
for(const f of result.slice(0,10)){
teks+=`📄 *${f.title}*\n💾 Ukuran: ${f.size}\n🔗 [Unduh File](${f.link})\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"Sfile Mobi",
body:"Sumber: sfile.mobi",
thumbnailUrl:"https://cdn.iconscout.com/icon/free/png-512/free-download-folder-1771196-1508874.png",
sourceUrl:"https://sfile.mobi/",
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Sfile.*')
}
}

handler.help=['Sfile Search']
handler.tags=['search']
handler.command=['sfile']

export default handler