import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan nama artis atau lagu!\n\nContoh:\n${prefix+command} Alan Walker`)
await reaction(m.chat,'🎧')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/soundcl?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan untuk *${text}* di SoundCloud.*`)

let teks=`🎶 *Hasil Pencarian SoundCloud untuk:* _${text}_\n\n`
for(const s of result.slice(0,10)){
teks+=`🎵 *${s.title}*\n🔗 [Kunjungi](${s.url})\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"SoundCloud Search",
body:"Sumber: soundcloud.com (via Vsunsee API)",
thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/2/20/SoundCloud_logo.svg",
sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/soundcl?q=${encodeURIComponent(text)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari SoundCloud API.*')
}
}

handler.help=['SoundCloud Search Music']
handler.tags=['search']
handler.command=['soundcloud']

export default handler