import yts from 'yt-search'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan judul yang akan dicari!\n\nContoh:\n${prefix + command} Doraemon`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const result = await yts(text)
if (!result || !result.videos || !result.videos.length) {
await reaction(m.chat, '❌')
return m.reply('❌ Tidak ada hasil ditemukan untuk pencarian tersebut.')
}
const vid = result.videos[0]
const url = encodeURIComponent(vid.url)
const teks = `🎬 *YouTube Search Result*\n\n📌 *Judul:* ${vid.title}\n⏱ *Durasi:* ${vid.timestamp}\n👁 *Views:* ${vid.views}\n📅 *Upload:* ${vid.ago}\n📎 *Link:* ${vid.url}`

if (modesend === 'button') {
await vanzz.sendMessage(m.chat, {
image: { url: vid.thumbnail },
caption: teks,
footer: "🔎 YouTube Search",
buttons: [
{ buttonId: `.ytmp4 ${url}`, buttonText: { displayText: '🎥 Video | MP4' }, type: 1 },
{ buttonId: `.ytmp3 ${url}`, buttonText: { displayText: '🎵 Audio | MP3' }, type: 1 }
],
headerType: 1
}, { quoted: qtext })
} else if (modesend === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: {
externalAdReply: {
title: vid.title,
body: "🔎 YouTube Search Result",
thumbnailUrl: vid.thumbnail,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: vid.url
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
image: { url: vid.thumbnail },
caption: teks,
viewOnce: true
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("YTS Error:", e)
}
}

handler.help = ['yts']
handler.tags = ['search']
handler.command = ['yts', 'ytsearch']

export default handler