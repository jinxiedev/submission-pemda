import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan topik pencarian!\n\nContoh:\n${prefix + command} dinosaurus`)
await reaction(m.chat, '📚')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/wikipedia?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, results } = res.data
if (!status || !Array.isArray(results) || !results.length) return m.reply(`*[❌]* Tidak ada hasil ditemukan.`)

let teks = `📘 *Hasil Pencarian Wikipedia:*\n\n`
for (const r of results.slice(0, 5)) {
teks += `🧩 *${r.title}*\n`
if (r.thumbnail) teks += `🖼️ ${r.thumbnail}\n`
teks += `${r.extract.slice(0, 400)}...\n`
teks += `🌐 [Baca Selengkapnya](${r.url})\n\n`
}

if (modesend === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: "Wikipedia",
body: "Sumber: id.wikipedia.org",
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/6/63/Wikipedia-logo.png",
sourceUrl: "https://id.wikipedia.org",
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error(e)
m.reply(`*[❌]* Gagal mengambil data dari Wikipedia.`)
}
}

handler.help = ['Wikipedia Search']
handler.tags = ['search']
handler.command = ['wikipedia']

export default handler