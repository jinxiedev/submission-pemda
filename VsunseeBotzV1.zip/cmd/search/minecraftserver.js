import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci server!\n\nContoh:\n${prefix+command} creative`)
await reaction(m.chat,'⛏️')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/minecraftserver?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(text)}`)
const{status,results}=res.data
if(!status||!Array.isArray(results)||!results.length)return m.reply(`*[❌]* Tidak ada server ditemukan untuk _${text}_.*`)

let teks=`🎮 *Server Minecraft untuk:* _${text}_\n\n`
for(const s of results.slice(0,10)){
teks+=`🏷️ *${s.name}*\n🌐 IP: ${s.ip}\n⚙️ Versi: ${s.version}\n🎯 Mode: ${s.gamemode}\n📡 Status: ${s.status}\n👥 Pemain: ${s.players}\n📝 Deskripsi: ${s.description?.slice(0,200)||'-'}\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"Minecraft Server List",
body:"Sumber: minecraft.buzz (via Vsunsee API)",
thumbnailUrl:results[0].image||"https://upload.wikimedia.org/wikipedia/en/5/51/Minecraft_cover.png",
sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/minecraftserver?query=${encodeURIComponent(text)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Minecraft Server API.*')
}
}

handler.help=['Search Minecraft Server']
handler.tags=['search']
handler.command=['minecraftserver']

export default handler