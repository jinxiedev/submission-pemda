import axios from "axios"
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan nama lagu atau artis!\n\nContoh:\n${prefix + command} Last Child`)
await reaction(m.chat, '🎧')
const modesend = global.modesend

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/spotify?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, results } = res.data
if (!status || !Array.isArray(results) || !results.length)
return m.reply(`*[❌]* Tidak ditemukan hasil Spotify untuk "${text}".*`)

let teks = `🎶 *Hasil Pencarian Spotify untuk:* _${text}_\n\n`
for (const s of results.slice(0, 10)) {
let durasi = `${Math.floor(s.duration_ms / 60000)}:${String(Math.floor((s.duration_ms % 60000) / 1000)).padStart(2, '0')}`
teks += `🎵 *${s.title}*\n👤 Artis: ${s.artists.join(', ')}\n💽 Album: ${s.album}\n⏱️ Durasi: ${durasi}\n🔗 [Dengarkan di Spotify](${s.url})\n\n`
}

if (modesend === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: "Spotify Music Search",
body: "Sumber: open.spotify.com (via Vsunsee API)",
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/1/19/Spotify_logo_without_text.svg",
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/spotify?q=${encodeURIComponent(text)}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
console.error(e)
await reaction(m.chat, '❌')
m.reply('*[❌]* Gagal mengambil data dari Spotify API.*')
}
}

handler.help = ['Spotify Search Music']
handler.tags = ['search']
handler.command = ['spotify']

export default handler