import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan nama package NPM!\n\nContoh:\n${prefix+command} baileys`)
await reaction(m.chat,'🔍')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/npm?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan di NPM.`)
async function getBuffer(url){const a=await axios.get(url,{responseType:'arraybuffer'});return Buffer.from(a.data)}
const npmIcon="https://upload.wikimedia.org/wikipedia/commons/d/db/Npm-logo.svg"

if(modesend==='xreply'){
let teks=`📦 *Hasil Pencarian NPM: ${text}*\n\n`
for(let r of result.slice(0,5)){
teks+=`📘 *${r.title}*\n👤 ${r.author}\n⬇️ ${r.download.monthly.toLocaleString()} / bulan\n🗓️ ${new Date(r.update).toLocaleDateString('id-ID')}\n🔗 ${r.links.npm}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"NPM Package Search",body:"Hasil pencarian NPM",thumbnailUrl:npmIcon,mediaType:1,renderLargerThumbnail:true,showAdAttribution:false,sourceUrl:"https://www.npmjs.com"}}},{quoted:qtext})
}else if(modesend==='button'){
const cards=[]
for(let i=0;i<Math.min(result.length,10);i++){
const r=result[i]
let img=await prepareWAMessageMedia({image:await getBuffer(npmIcon)},{upload:vanzz.waUploadToServer})
const card={
header:proto.Message.InteractiveMessage.Header.fromObject({hasMediaAttachment:true,...img}),
body:proto.Message.InteractiveMessage.Body.fromObject({text:`📦 *${r.title}*\n👤 ${r.author}\n⬇️ ${r.download.monthly.toLocaleString()} / bulan\n🗓️ ${new Date(r.update).toLocaleDateString('id-ID')}`}),
nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({buttons:[
{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"🌐 NPM Page\",\"url\":\"${r.links.npm}\"}`},
r.links.repository?{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"📁 Repository\",\"url\":\"${r.links.repository}\"}`}:{},
r.links.homepage?{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"🏠 Homepage\",\"url\":\"${r.links.homepage}\"}`}:{}
].filter(Boolean)})
}
cards.push(card)
}
const msg=await generateWAMessageFromContent(m.chat,{viewOnceMessageV2Extension:{message:{interactiveMessage:proto.Message.InteractiveMessage.fromObject({
body:proto.Message.InteractiveMessage.Body.fromObject({text:`📚 *Hasil Pencarian NPM*`}),
carouselMessage:proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards})
})}}},{userJid:m.chat,quoted:qtext})
await vanzz.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
}else{
let teks=`📦 *Hasil Pencarian NPM: ${text}*\n\n`
for(let r of result.slice(0,5)){
teks+=`📘 *${r.title}*\n👤 ${r.author}\n⬇️ ${r.download.monthly.toLocaleString()} / bulan\n🗓️ ${new Date(r.update).toLocaleDateString('id-ID')}\n🔗 ${r.links.npm}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}
await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari NPM.*')
}
}

handler.help=['Npm Search']
handler.tags=['search']
handler.command=['npmsearch']

export default handler