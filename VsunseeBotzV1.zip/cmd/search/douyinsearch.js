import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from "axios"
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix+command} Naga`)
await reaction(m.chat,'🎬')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/douyin?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan di Douyin untuk "${text}".*`)
async function getBuffer(url){const r=await axios.get(url,{responseType:'arraybuffer'});return Buffer.from(r.data)}
if(modesend==='button'){
const cards=[]
for(const data of result.slice(0,10)){
const vid=data.aweme_info
if(!vid||!vid.video)continue
const desc=vid.desc||'Tanpa judul'
const videoUrl=vid.video.play_addr?.url_list?.[0]||''
if(!videoUrl)continue
const thumb=vid.video.cover?.url_list?.[0]||"https://upload.wikimedia.org/wikipedia/en/a/a9/Douyin_logo.png"
const author=vid.author?.nickname||'Unknown'
const durasi=(vid.video.duration/1000).toFixed(0)+"s"
const ukuran=(vid.video.play_addr?.data_size?((vid.video.play_addr.data_size/1024/1024).toFixed(2)+' MB'):'-')
let img=await prepareWAMessageMedia({image:await getBuffer(thumb)},{upload:vanzz.waUploadToServer})
const card={
header:proto.Message.InteractiveMessage.Header.fromObject({hasMediaAttachment:true,...img}),
body:proto.Message.InteractiveMessage.Body.fromObject({text:`🎞️ *${desc}*\n👤 ${author}\n🕒 Durasi: ${durasi}\n💾 Ukuran: ${ukuran}`}),
nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({buttons:[
{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"▶️ Tonton Video\",\"url\":\"${videoUrl}\"}`},
{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"👤 Profil\",\"url\":\"https://www.douyin.com/user/${vid.author?.sec_uid||''}\"}`}
]})
}
cards.push(card)
}
if(!cards.length)return m.reply('*[❌]* Tidak ada video valid ditemukan.*')
const msg=await generateWAMessageFromContent(m.chat,{viewOnceMessageV2Extension:{message:{interactiveMessage:proto.Message.InteractiveMessage.fromObject({body:proto.Message.InteractiveMessage.Body.fromObject({text:`🎥 *Hasil Pencarian Douyin:* _${text}_`}),carouselMessage:proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards})})}}},{userJid:m.chat,quoted:qtext})
await vanzz.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
await reaction(m.chat,'✅')
return
}
if(modesend==='xreply'){
let teks=`🎬 *Hasil Pencarian Douyin: ${text}*\n\n`
for(const data of result.slice(0,5)){
const vid=data.aweme_info
const desc=vid.desc||'Tanpa judul'
const link=vid.video?.play_addr?.url_list?.[0]
if(link)teks+=`🎞️ ${desc}\n👤 ${vid.author?.nickname||'Unknown'}\n🔗 ${link}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"Douyin Search",body:"Sumber: douyin.com (via Vsunsee API)",thumbnailUrl:"https://upload.wikimedia.org/wikipedia/en/a/a9/Douyin_logo.png",sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/douyin?query=${encodeURIComponent(text)}`,mediaType:1,renderLargerThumbnail:true}}},{quoted:qtext})
await reaction(m.chat,'✅')
return
}
else{
let teks=`🎥 *Hasil Pencarian Douyin untuk:* _${text}_\n\n`
for(const data of result.slice(0,10)){
const vid=data.aweme_info
const desc=vid.desc||'Tanpa judul'
const link=vid.video?.play_addr?.url_list?.[0]
if(link)teks+=`🎞️ ${desc}\n👤 ${vid.author?.nickname||'Unknown'}\n🔗 ${link}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
await reaction(m.chat,'✅')
}
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Douyin API.*')
}
}

handler.help=['Douyin Search Video']
handler.tags=['search']
handler.command=['douyin']

export default handler