import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan judul lagu!\n\nContoh:\n${prefix+command} Fix You`)
await reaction(m.chat,'🎵')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/lyrics?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!result)return m.reply(`*[❌]* Tidak ditemukan lirik lagu untuk "${text}".*`)

let teks=`🎧 *Lirik Lagu:* _${text}_\n\n${result.trim()}`

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks,
contextInfo:{
externalAdReply:{
title:"Lyrics Finder",
body:"Powered by Vsunsee API",
thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Music_Icon.svg/512px-Music_Icon.svg.png",
sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/lyrics?q=${encodeURIComponent(text)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Lyrics API.*')
}
}

handler.help=['lyrics Search']
handler.tags=['search']
handler.command=['lyrics']

export default handler