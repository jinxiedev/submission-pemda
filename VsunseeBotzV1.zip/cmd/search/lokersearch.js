import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
let [job,city,jumlah]=text.split('|').map(a=>a?.trim())
if(!job||!city)return m.reply(`⚠️ Format salah!\n\nContoh:\n${prefix+command} kasir D.I.Y | Sukamara | 1`)
await reaction(m.chat,'💼')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/loker?apikey=${global.VsunseeApikey}&pekerjaan=${encodeURIComponent(job)}&kota=${encodeURIComponent(city)}&jumlah=${jumlah||1}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada lowongan untuk _${job}_ di _${city}_.*`)

let teks=`💼 *Lowongan untuk:* _${job}_ di _${city}_\n\n`
for(const l of result){
teks+=`🏢 *${l.judul}*\n👔 Perusahaan: ${l.perusahaan}\n📍 Lokasi: ${l.lokasi}\n📅 Tanggal: ${l.tanggal}\n💰 Gaji: ${l.gaji}\n📝 ${l.deskripsi}\n🔗 [Lihat Selengkapnya](${l.link})\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"Job Finder",
body:"Sumber: JobStreet (via Vsunsee API)",
thumbnailUrl:result[0].logo||"https://upload.wikimedia.org/wikipedia/commons/f/fd/Briefcase_icon.svg",
sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/loker?pekerjaan=${encodeURIComponent(job)}&kota=${encodeURIComponent(city)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Job Finder API.*')
}
}

handler.help=['Cari Loker']
handler.tags=['search']
handler.command=['lokersearch']

export default handler