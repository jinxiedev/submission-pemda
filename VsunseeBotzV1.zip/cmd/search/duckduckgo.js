import axios from "axios"
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js"

let handler=async(m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix+command} cat`)
await reaction(m.chat,'🦆')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/duck?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!result)return m.reply(`*[❌]* Tidak ada hasil untuk "${text}".*`)
let teks=`🔍 *Hasil Pencarian DuckDuckGo untuk:* _${text}_\n\n`
if(result.heading)teks+=`📌 *Topik Utama:* ${result.heading}\n\n`
if(result.abstractUrl)teks+=`🌐 [Baca Selengkapnya](${result.abstractUrl})\n\n`
function extractTopics(topics){
let arr=[]
for(const item of topics){
if(item.Topics)arr.push(...extractTopics(item.Topics))
else arr.push(item)
}
return arr
}
const allTopics=result.relatedTopics?extractTopics(result.relatedTopics):[]
if(allTopics.length){
for(const item of allTopics.slice(0,15)){
const judul=item.Text?.replace(/\s+/g,' ').trim()||'Tanpa Judul'
const url=item.FirstURL||''
teks+=`🔹 *${judul}*\n🔗 [Kunjungi](${url})\n\n`
}
}else teks+='❗ Tidak ditemukan hasil terkait.'
if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"DuckDuckGo Instant Search",body:"Sumber: duckduckgo.com (via Vsunsee API)",thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/DuckDuckGo_Logo.svg/512px-DuckDuckGo_Logo.svg.png",sourceUrl:`https://duckduckgo.com/?q=${encodeURIComponent(text)}`,mediaType:1,renderLargerThumbnail:true}}},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}
await reaction(m.chat,'✅')
}catch(e){
console.error(e)
await reaction(m.chat,'❌')
m.reply('*[❌]* Gagal mengambil data dari DuckDuckGo API.*')
}
}

handler.help=['DuckDuckgo Search']
handler.tags=['search']
handler.command=['duckduckgo']

export default handler