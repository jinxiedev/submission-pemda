import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan nama aplikasi!\n\nContoh:\n${prefix+command} Termux`)
await reaction(m.chat,'💡')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/fdroid?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const data=res.data
const result=Array.isArray(data?.result)?data.result:[]
if(!data?.status||result.length===0)return m.reply(`*[❌]* Tidak ada hasil ditemukan di F-Droid untuk "${text}".*`)
if(modesend==='xreply'){
let teks=`💡 *Hasil F-Droid untuk:* _${text}_\n\n`
for(const a of result.slice(0,5)){
teks+=`📦 *${a.name}*\n🧾 ${a.description}\n📜 Lisensi: ${a.license}\n🔗 ${a.link}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"F-Droid Repository",body:"Sumber: f-droid.org",thumbnailUrl:result[0]?.icon||"https://upload.wikimedia.org/wikipedia/commons/3/3f/F-Droid_Logo_2015.png",mediaType:1,renderLargerThumbnail:true,showAdAttribution:false,sourceUrl:"https://f-droid.org"}}},{quoted:qtext})
}else{
let teks=`💡 *Hasil F-Droid untuk:* _${text}_\n\n`
for(const a of result.slice(0,10)){
teks+=`📦 *${a.name}*\n🧾 ${a.description}\n📜 Lisensi: ${a.license}\n🔗 ${a.link}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}
await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari F-Droid.*')
}
}

handler.help=['F-Droid Search Apps']
handler.tags=['search']
handler.command=['fdroid']

export default handler