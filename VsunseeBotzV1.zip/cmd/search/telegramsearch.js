import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci channel!\n\nContoh:\n${prefix+command} HAD WHATSAPP`)
await reaction(m.chat,'💬')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/telegram?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan untuk _${text}_ di Telegram.*`)

let teks=`💬 *Hasil Channel Telegram untuk:* _${text}_\n\n`
for(const ch of result.slice(0,10)){
teks+=`📢 *${ch.name}*\n👥 Anggota: ${ch.members}\n🏷️ Kategori: ${ch.category}\n📝 Deskripsi: ${ch.description||'-'}\n🔗 [Kunjungi Channel](${ch.link})\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"Telegram Channel Finder",
body:"Sumber: tgramsearch.com (via Vsunsee API)",
thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/8/82/Telegram_logo.svg",
sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/telegram?query=${encodeURIComponent(text)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari Telegram API.*')
}
}

handler.help=['Telegram Search Channel']
handler.tags=['search']
handler.command=['telegramsearch']

export default handler