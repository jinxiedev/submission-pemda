import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan kata untuk dicari di KBBI!\n\nContoh:\n${prefix + command} semangka`)
await reaction(m.chat, '📖')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/kbbi?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !result || !result.kata) return m.reply(`*[❌]* Kata tidak ditemukan di KBBI.`)

let teks = `📘 *Hasil KBBI untuk:* _${text}_\n\n`
for (const ent of result.kata) {
const key = Object.keys(ent)[0]
const val = ent[key]
teks += `🔹 *${key}*\n`
if (val.makna?.length) {
for (const mkn of val.makna) {
teks += `📗 *${mkn.kelas_kata}*\n${mkn.deskripsi}\n\n`
}
}
if (val.gabungan_kata?.length) teks += `🧩 *Gabungan kata:* ${val.gabungan_kata.join(', ')}\n\n`
}

if (modesend === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: "Kamus Besar Bahasa Indonesia (KBBI)",
body: "Sumber resmi: kbbi.kemdikbud.go.id",
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/f/f5/Logo_KBBI.png",
sourceUrl: "https://kbbi.kemdikbud.go.id",
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error(e)
m.reply(`*[❌]* Gagal mengambil data dari KBBI.`)
}
}

handler.help = ['Kamus Besar Bahasa Indonesia']
handler.tags = ['search']
handler.command = ['kbbi']

export default handler