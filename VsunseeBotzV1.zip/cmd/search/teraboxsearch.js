import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix+command} movie`)
await reaction(m.chat,'🎬')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/terabox?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!result?.result?.groups)return m.reply(`*[❌]* Tidak ada hasil grup ditemukan di TeraBox.*`)

const groups=result.result.groups
let teks=`🎬 *Hasil Grup TeraBox untuk:* _${text}_\n\n`
for(const g of groups.slice(0,10)){
teks+=`🎞️ *${g.group_name}*\n👥 Anggota: ${g.members_num}\n📦 File: ${g.file_cnt}\n🔗 Group ID: ${g.group_id}\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"TeraBox Groups",
body:"Sumber: terabox.com (via Vsunsee API)",
thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/8/87/Terabox_logo.svg",
sourceUrl:`https://${global.VsunseeApi}/vsunseeV8/terabox?query=${encodeURIComponent(text)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari TeraBox API.*')
}
}

handler.help=['Terabox Search']
handler.tags=['search']
handler.command=['teraboxsearch']

export default handler