import axios from "axios"
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix + command} Japanese`)
await reaction(m.chat, '🔍')
const modesend = global.modesend

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/xnxx?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { result, status } = res.data

if (!status || !Array.isArray(result) || !result.length)
return m.reply(`*[❌]* Tidak ditemukan hasil untuk "${text}".*`)

let teks = `🔞 *Hasil Pencarian Video XNXX untuk:* _${text}_\n\n`
for (let i = 0; i < Math.min(result.length, 10); i++) {
const v = result[i]
teks += `🎬 *${i + 1}. ${v.title}*\n🕒 ${v.info?.trim() || '-'}\n🔗 ${v.link}\n\n`
}

if (modesend === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: "XNXX Video Search",
body: "Sumber: xnxx.com (via Vsunsee API)",
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/1/16/XNXX_logo.svg",
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/xnxx?q=${encodeURIComponent(text)}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks.trim() }, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
console.error(e)
await reaction(m.chat, '❌')
m.reply('*[❌]* Gagal mengambil data dari XNXX API.*')
}
}

handler.help = ['Xnxx Search Video 18+']
handler.tags = ['search']
handler.command = ['xnxxsearch']

export default handler