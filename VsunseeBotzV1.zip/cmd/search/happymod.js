import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan nama aplikasi!\n\nContoh:\n${prefix+command} Dana`)
await reaction(m.chat,'💾')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/happymod?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan di HappyMod.`)

let teks=`💾 *Hasil HappyMod untuk:* _${text}_\n\n`
for(const app of result.slice(0,10)){
teks+=`🎮 *${app.name}*\n⭐ Rating: ${app.rating}\n🔗 [Download Mod](${app.url})\n\n`
}

if(modesend==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:"HappyMod",
body:"Sumber: happymod.to",
thumbnailUrl:"https://seeklogo.com/images/H/happymod-logo-7C62F2D708-seeklogo.com.png",
sourceUrl:"https://happymod.to/",
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari HappyMod.*')
}
}

handler.help=['Happymod Search APK']
handler.tags=['search']
handler.command=['happymod']

export default handler