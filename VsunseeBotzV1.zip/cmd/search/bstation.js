import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix+command} anime`)
await reaction(m.chat,'🎬')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/bstation-search?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan di BiliBili.`)
if(modesend==='xreply'){
let teks=`🎞️ *Hasil Pencarian BiliBili: ${text}*\n\n`
for(const v of result.slice(0,5)){
teks+=`🎬 *${v.title}*\n👤 ${v.uploader}\n⏱️ ${v.duration} | ${v.views}\n🔗 ${v.url}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"BiliBili Search",body:"Hasil pencarian video BiliBili",thumbnailUrl:"https://upload.wikimedia.org/wikipedia/commons/5/5c/Bilibili_logo.svg",mediaType:1,renderLargerThumbnail:true,showAdAttribution:false,sourceUrl:"https://www.bilibili.tv"}}},{quoted:qtext})
}
else if(modesend==='button'){
async function getBuffer(url){const a=await axios.get(url,{responseType:'arraybuffer'});return Buffer.from(a.data)}
const cards=[]
for(let i=0;i<Math.min(result.length,10);i++){
const v=result[i]
let img=await prepareWAMessageMedia({image:await getBuffer(v.thumbnail)},{upload:vanzz.waUploadToServer})
const card={
header:proto.Message.InteractiveMessage.Header.fromObject({hasMediaAttachment:true,...img}),
body:proto.Message.InteractiveMessage.Body.fromObject({text:`🎬 *${v.title}*\n👤 ${v.uploader}\n⏱️ ${v.duration} | ${v.views}`}),
nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({buttons:[{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"▶️ Tonton Video\",\"url\":\"${v.url}\"}`},{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"👤 Profil Uploader\",\"url\":\"${v.uploaderUrl}\"}`}]})
}
cards.push(card)
}
const msg=await generateWAMessageFromContent(m.chat,{viewOnceMessageV2Extension:{message:{interactiveMessage:proto.Message.InteractiveMessage.fromObject({body:proto.Message.InteractiveMessage.Body.fromObject({text:`🎥 *Hasil Pencarian BiliBili:*\n@${m.sender.split('@')[0]}`}),carouselMessage:proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards})})}}},{userJid:m.chat,quoted:qtext})
await vanzz.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
}
else{
let teks=`🎞️ *Hasil Pencarian BiliBili: ${text}*\n\n`
for(const v of result.slice(0,10)){
teks+=`🎬 *${v.title}*\n👤 ${v.uploader}\n⏱️ ${v.duration} | ${v.views}\n🔗 ${v.url}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}
await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
m.reply('*[❌]* Gagal mengambil data dari BiliBili.*')
}
}

handler.help=['Bstation Search Video']
handler.tags=['search']
handler.command=['bstation']

export default handler