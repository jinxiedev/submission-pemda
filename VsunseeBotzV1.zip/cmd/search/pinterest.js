import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan kata kunci untuk mencari gambar!\n\nContoh:\n${prefix + command} car style`)
await reaction(m.chat, '📌')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/pinterest?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(text)}&type=image`)
const { status, result } = res.data
if (!status || !Array.isArray(result) || !result.length) return m.reply(`*[❌]* Tidak ada hasil ditemukan di Pinterest.`)

async function getBuffer(url) {
const a = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(a.data)
}

if (modesend === 'button') {
const cards = []
for (let i = 0; i < Math.min(result.length, 10); i++) {
const r = result[i]
let img = await prepareWAMessageMedia({ image: await getBuffer(r.image_url) }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({ hasMediaAttachment: true, ...img }),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `${r.description?.slice(0, 100) || 'Gambar tanpa deskripsi'}`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"🔗 Lihat di Pinterest\",\"url\":\"${r.pin}\"}`
}
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(
m.chat,
{
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `📍 *Hasil Pinterest untuk:* _${text}_`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
},
{ userJid: m.chat, quoted: qtext }
)
await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

else { 
let images = result.slice(0, 3)
for (const imgData of images) {
await vanzz.sendMessage(m.chat, {
image: { url: imgData.image_url },
caption: `📍 *Hasil Pinterest untuk:* _${text}_\n\n${imgData.description?.slice(0, 100) || 'Tanpa deskripsi'}\n\n🔗 ${imgData.pin}`
}, { quoted: qtext })
}
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error(e)
m.reply(`*[❌]* Gagal mengambil data dari Pinterest.`)
}
}

handler.help = ['Pinterest Search Image']
handler.tags = ['search']
handler.command = ['pinterest', 'pin']

export default handler