import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,reaction,text,prefix,command})=>{
if(!text)return m.reply(`⚠️ Masukkan kata kunci pencarian!\n\nContoh:\n${prefix+command} basebot`)
await reaction(m.chat,'🔍')
const modesend=global.modesend
try{
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/mediafiresearch?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const{status,result}=res.data
if(!status||!Array.isArray(result)||!result.length)return m.reply(`*[❌]* Tidak ada hasil ditemukan di MediaFire.`)

if(modesend==='xreply'){
let teks=`📁 *Hasil Pencarian MediaFire: ${text}*\n\n`
for(const r of result.slice(0,5)){
teks+=`📄 *${r.filename}*\n💾 ${r.filesize}\n🔗 ${r.url}\n🌐 ${r.source_title}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim(),contextInfo:{externalAdReply:{title:"MediaFire Search",body:"Hasil pencarian file MediaFire",thumbnailUrl:"https://cdn-icons-png.flaticon.com/512/906/906343.png",mediaType:1,renderLargerThumbnail:true,showAdAttribution:false,sourceUrl:"https://www.mediafire.com"}}},{quoted:qtext})
}

else if(modesend==='button'){
async function getImageBuffer(url){const res=await axios.get(url,{responseType:'arraybuffer'});return Buffer.from(res.data)}
const cards=[]
for(let i=0;i<Math.min(result.length,10);i++){
const f=result[i]
let img=await prepareWAMessageMedia({image:await getImageBuffer("https://cdn-icons-png.flaticon.com/512/906/906343.png")},{upload:vanzz.waUploadToServer})
const card={
header:proto.Message.InteractiveMessage.Header.fromObject({hasMediaAttachment:true,...img}),
body:proto.Message.InteractiveMessage.Body.fromObject({text:`📄 *${f.filename}*\n💾 ${f.filesize}`}),
nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({buttons:[
{"name":"cta_copy","buttonParamsJson":`{\"display_text\":\"📋 Salin Link Download\",\"id\":\"mf-${i}\",\"copy_code\":\"${f.url}\"}`},
{"name":"cta_url","buttonParamsJson":`{\"display_text\":\"🌐 Sumber Asli\",\"url\":\"${f.source_url}\"}`}
]})
}
cards.push(card)
}
const msg=await generateWAMessageFromContent(m.chat,{viewOnceMessageV2Extension:{message:{interactiveMessage:proto.Message.InteractiveMessage.fromObject({
body:proto.Message.InteractiveMessage.Body.fromObject({text:`📁 *Hasil Pencarian MediaFire:*\n@${m.sender.split('@')[0]}`}),
carouselMessage:proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards})
})}}},{userJid:m.chat,quoted:qtext})
await vanzz.relayMessage(m.chat,msg.message,{messageId:msg.key.id})
}

else{
let teks=`📁 *Hasil Pencarian MediaFire: ${text}*\n\n`
for(const r of result.slice(0,10)){
teks+=`📄 *${r.filename}*\n💾 ${r.filesize}\n🔗 ${r.url}\n🌐 ${r.source_title}\n\n`
}
await vanzz.sendMessage(m.chat,{text:teks.trim()},{quoted:qtext})
}

await reaction(m.chat,'✅')
}catch(e){
await reaction(m.chat,'❌')
console.error(e)
return m.reply(`*[❌]* Gagal mengambil data dari MediaFire.`)
}
}

handler.help=['Mediafire Search']
handler.tags=['search']
handler.command=['mediafiresearch']

export default handler