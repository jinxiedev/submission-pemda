import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL F-Droid!\n\nContoh:\n${prefix + command} https://f-droid.org/id/packages/dev.develsinthedetails.eatpoopyoucat`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/fdroiddl?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.downloadLink) {
await reaction(m.chat, '❌')
console.log("FDROID API Error:", data)
return
}

let result = data.result
let version = result.version || "-"
let requirement = result.requirement || "-"
let apkurl = result.downloadLink
let size = result.apkSize || "-"
let filename = `F-Droid_App_v${version}.apk`
let mimetype = 'application/vnd.android.package-archive'

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
document: { url: apkurl },
fileName: filename,
mimetype: mimetype,
caption: `📱 *F-DROID DOWNLOADER*\n\n🧩 *Versi:* ${version}\n📏 *Ukuran:* ${size}\n⚙️ *Kebutuhan:* ${requirement}\n🔗 *Link:* ${apkurl}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
document: { url: apkurl },
fileName: filename,
mimetype: mimetype,
caption: `📱 *F-DROID DOWNLOADER*\n\n🧩 *Versi:* ${version}\n📏 *Ukuran:* ${size}\n⚙️ *Kebutuhan:* ${requirement}\n🔗 *Link:* ${apkurl}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${filename} • F-Droid`,
body: `📦 Klik untuk mengunduh aplikasi (${size})`,
thumbnailUrl: "https://f-droid.org/repo/icons-640/dev.develsinthedetails.eatpoopyoucat.23.png",
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("FDROID Error:", e)
}
}

handler.help = ['Fdroid Downloader']
handler.tags = ['downloader']
handler.command = ['fdroiddl']

export default handler