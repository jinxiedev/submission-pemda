import axios from 'axios'

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!text)return vanzz.sendMessage(m.chat,{
text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} <link_instagram>\n\n📍 Contoh:\n${prefix+command} https://www.instagram.com/p/DQHpUbPD184/`
},{quoted:qtext})

await vanzz.sendMessage(m.chat,{react:{text:'⏳',key:m.key}})

const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/instagramdl?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`
const res=await axios.get(apiUrl,{responseType:'json'})

if(!res.data?.status||!res.data?.result?.length)
return m.reply('❌ Gagal mengambil data dari Instagram.')

for(const item of res.data.result){
if(item.type==='image'){
await vanzz.sendMessage(m.chat,{
image:{url:item.url},
caption:`📸 *Instagram Image Downloader*\n✅ Berhasil Mengambil Gambar`
},{quoted:m})
}else if(item.type==='video'){
await vanzz.sendMessage(m.chat,{
video:{url:item.url},
caption:`🎥 *Instagram Video Downloader*\n✅ Video Berhasil Diunduh`
},{quoted:m})
}}

await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('INSTAGRAMDL ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Instagram Downloader']
handler.tags=['downloader']
handler.command=['igdl','instagramdl']

export default handler