import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
if (!text) return m.reply("⚠️ Masukkan URL YouTube!")
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
let api1 = `https://${global.VsunseeApi}/vsunseeV8/ytmp3?apikey=${global.VsunseeApikey}&url=${url}`
let api2 = `https://${global.VsunseeApi}/vsunseeV8/savetube?apikey=${global.VsunseeApikey}&url=${url}&format=mp3`
let res1 = await axios.get(api1)
let data1 = res1.data

let audioUrl, title, thumb, duration
if (data1 && data1.status && data1.result?.dlurl) {
audioUrl = data1.result.dlurl
title = decodeURIComponent(data1.result.dlurl.split("title=")[1] || "Audio YouTube")
thumb = "https://i.ytimg.com/vi/" + text.split("v=")[1]?.split("&")[0] + "/hqdefault.jpg"
duration = "-"
} else {
let res2 = await axios.get(api2)
let data2 = res2.data
if (!data2 || !data2.status) {
await reaction(m.chat, '❌')
console.log("YTMP3 API Error:", data1, data2)
return
}
audioUrl = data2.dl
title = data2.title
thumb = data2.thumb
duration = data2.duration + "s"
}

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
audio: { url: audioUrl },
mimetype: 'audio/mp4'
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
audio: { url: audioUrl },
mimetype: 'audio/mp4',
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: title,
body: `🎵 MP3 • ${duration}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("YTMP3 Error:", e)
}
}

handler.help = ['Youtube Music Downloader']
handler.tags = ['downloader']
handler.command = ['ytmp3']

export default handler