import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL Pinterest!\n\nContoh:\n${prefix + command} https://www.pinterest.com/pin/211174978673416`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/pinterestdl?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data
if (!data || !data.status || !data.media?.url) {
await reaction(m.chat, '❌')
console.log("PINTEREST API Error:", data)
return
}

let media = data.media
let title = media.title || "Pinterest Media"
let type = media.type || "-"
let quality = media.quality || "-"
let size = media.size || "-"
let thumb = media.thumbnail || media.url
let source = data.source || text
let mediaUrl = media.url

await reaction(m.chat, '✨')
if (modesend === false) {
if (type.match(/jpg|png|jpeg/i)) {
await vanzz.sendMessage(m.chat, {
image: { url: mediaUrl },
caption: `📌 *PINTEREST DOWNLOADER*\n\n📷 *Judul:* ${title}\n💾 *Tipe:* ${type.toUpperCase()}\n🎚️ *Kualitas:* ${quality}\n📦 *Ukuran:* ${size}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: mediaUrl },
mimetype: 'video/mp4',
caption: `📌 *PINTEREST DOWNLOADER*\n\n🎥 *Judul:* ${title}\n💾 *Tipe:* ${type.toUpperCase()}\n🎚️ *Kualitas:* ${quality}\n📦 *Ukuran:* ${size}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
}
} else {
if (type.match(/jpg|png|jpeg/i)) {
await vanzz.sendMessage(m.chat, {
image: { url: mediaUrl },
caption: `📌 *PINTEREST DOWNLOADER*\n\n📷 *Judul:* ${title}\n💾 *Tipe:* ${type.toUpperCase()}\n🎚️ *Kualitas:* ${quality}\n📦 *Ukuran:* ${size}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 📍`,
body: `📸 Pinterest Media • ${quality}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: mediaUrl },
mimetype: 'video/mp4',
caption: `📌 *PINTEREST DOWNLOADER*\n\n🎥 *Judul:* ${title}\n💾 *Tipe:* ${type.toUpperCase()}\n🎚️ *Kualitas:* ${quality}\n📦 *Ukuran:* ${size}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 📍`,
body: `🎥 Pinterest Video • ${quality}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("PINTEREST Error:", e)
}
}

handler.help = ['Pinterest Downloader']
handler.tags = ['downloader']
handler.command = ['pinterestdl']

export default handler