import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL SnackVideo!\n\nContoh:\n${prefix + command} https://s.snackvideo.com/p/dwlMd51U`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/snackvideo?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.downloadUrl) {
await reaction(m.chat, '❌')
console.log("SNACKVIDEO API Error:", data)
return
}

let result = data.result
let video = result.downloadUrl
let thumb = result.thumbnail
let title = "SnackVideo Downloader"
let source = text

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *SNACKVIDEO DOWNLOADER*\n\n📌 *Sumber:* ${source}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *SNACKVIDEO DOWNLOADER*\n\n📌 *Sumber:* ${source}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎞️`,
body: `🎥 SnackVideo Downloader`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("SNACKVIDEO Error:", e)
}
}

handler.help = ['Snackvideo Downloader']
handler.tags = ['downloader']
handler.command = ['snackvideodl']

export default handler