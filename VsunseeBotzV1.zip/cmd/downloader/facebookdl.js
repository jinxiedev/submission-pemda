import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL!\n\nContoh:\n${prefix + command} https://www.facebook.com/share/r/12BFZAtjpS8/?mibextid=qDwCgo`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/facebook?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data

if (!data || !data.status || !data.result?.media) {
await reaction(m.chat, '❌')
console.log("FACEBOOK API Error:", data)
return
}

let result = data.result
let title = result.title || "Facebook Downloader"
let duration = result.duration || "-"
let thumb = result.thumbnail || ""
let videoUrl = result.media
let source = text

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
caption: `🎬 *FACEBOOK DOWNLOADER*\n\n📌 *Judul:* ${title}\n🕒 *Durasi:* ${duration}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
caption: `🎬 *FACEBOOK DOWNLOADER*\n\n📌 *Judul:* ${title}\n🕒 *Durasi:* ${duration}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎞️`,
body: `🎥 Facebook Downloader`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("FACEBOOK Error:", e)
}
}

handler.help = ['Facebook Video Downloader']
handler.tags = ['downloader']
handler.command = ['facebookdl']

export default handler