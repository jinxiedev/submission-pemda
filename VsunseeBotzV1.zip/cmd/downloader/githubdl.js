import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL GitHub Repository!\n\nContoh:\n${prefix + command} https://github.com/Vanxzofc/VsimSc`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/github?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.download) {
await reaction(m.chat, '❌')
console.log("GITHUB API Error:", data)
return
}

let result = data.result
let owner = result.owner || "-"
let repo = result.repo || "-"
let language = result.language || "-"
let stars = result.stars || 0
let forks = result.forks || 0
let size = result.size_mb || "-"
let update = result.last_update || "-"
let zip = result.download

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
document: { url: zip },
fileName: `${repo}.zip`,
mimetype: 'application/zip',
caption: `🐙 *GITHUB DOWNLOAD*\n\n👤 *Owner:* ${owner}\n📦 *Repository:* ${repo}\n💻 *Bahasa:* ${language}\n⭐ *Stars:* ${stars}\n🍴 *Forks:* ${forks}\n📏 *Ukuran:* ${size} MB\n🕒 *Update Terakhir:* ${update}\n\n⬇️ *Download ZIP:* ${zip}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
document: { url: zip },
fileName: `${repo}.zip`,
mimetype: 'application/zip',
caption: `🐙 *GITHUB DOWNLOAD*\n\n👤 *Owner:* ${owner}\n📦 *Repository:* ${repo}\n💻 *Bahasa:* ${language}\n⭐ *Stars:* ${stars}\n🍴 *Forks:* ${forks}\n📏 *Ukuran:* ${size} MB\n🕒 *Update Terakhir:* ${update}\n\n⬇️ *Download ZIP:* ${zip}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${repo} • GitHub Repository`,
body: `📦 ${owner} | ${language}`,
thumbnailUrl: "https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png",
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("GITHUB Error:", e)
}
}

handler.help = ['Github Downloader']
handler.tags = ['downloader']
handler.command = ['githubdl', 'gitclone']

export default handler