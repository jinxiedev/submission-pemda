import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL Video!\n\nContoh:\n${prefix + command} https://www.xnxx.com/video-1avb175f/cute_japanese_high_student_girl_gets_fucked_doggy_in_classroom._cum_extreme`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/xnxxdl?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data

if (!data || !data.status || !data.result?.files?.high) {
await reaction(m.chat, '❌')
console.log("XNXX API Error:", data)
return
}

let result = data.result
let title = result.title || "XNXX Downloader"
let duration = result.duration || "-"
let info = result.info?.trim() || "-"
let video = result.files.high || result.files.low
let thumb = result.image || result.files.thumb || result.files.thumb69
let source = result.URL || text

await reaction(m.chat, '✨')

if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *XNXX DOWNLOADER*\n\n📌 *Judul:* ${title}\n🕒 *Durasi:* ${duration}s\n📄 *Info:* ${info}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *XNXX DOWNLOADER*\n\n📌 *Judul:* ${title}\n🕒 *Durasi:* ${duration}s\n📄 *Info:* ${info}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎞️`,
body: `🎥 Video • Durasi ${duration}s`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("XNXX Error:", e)
}
}

handler.help = ['Xnxx Downloader']
handler.tags = ['downloader']
handler.command = ['xnxxdl']

export default handler