import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL MediaFire!\n\nContoh:\n${prefix + command} https://www.mediafire.com/file/1iu7hqs377e96uf/qioV19(Beal).zip/file`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/mediafire?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.link) {
await reaction(m.chat, '❌')
console.log("MEDIAFIRE API Error:", data)
return
}

let result = data.result
let filename = result.filename || "MediaFire_File"
let fileurl = result.link

let extMatch = filename.match(/\.[0-9A-Za-z]+$/)
let ext = extMatch ? extMatch[0].toLowerCase() : (fileurl.split('.').pop().split('?')[0] || 'bin')
if (!filename.includes(ext)) filename += '.' + ext

let mimetype = 'application/octet-stream'
if (/(zip|rar|7z)$/i.test(ext)) mimetype = 'application/zip'
else if (/(apk)$/i.test(ext)) mimetype = 'application/vnd.android.package-archive'
else if (/(mp3|wav|m4a)$/i.test(ext)) mimetype = 'audio/mpeg'
else if (/(mp4|mkv|avi)$/i.test(ext)) mimetype = 'video/mp4'
else if (/(pdf)$/i.test(ext)) mimetype = 'application/pdf'
else if (/(txt|log|json)$/i.test(ext)) mimetype = 'text/plain'

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
document: { url: fileurl },
fileName: filename,
mimetype: mimetype,
caption: `📦 *MEDIAFIRE DOWNLOADER*\n\n📁 *Nama File:* ${filename}\n⬇️ *Link:* ${fileurl}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
document: { url: fileurl },
fileName: filename,
mimetype: mimetype,
caption: `📦 *MEDIAFIRE DOWNLOADER*\n\n📁 *Nama File:* ${filename}\n⬇️ *Link:* ${fileurl}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${filename} • MediaFire File`,
body: `📁 Klik untuk mengunduh file`,
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/7/7e/Mediafire_logo.png",
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("MEDIAFIRE Error:", e)
}
}

handler.help = ['Mediafire Downloader']
handler.tags = ['downloader']
handler.command = ['mediafire']

export default handler