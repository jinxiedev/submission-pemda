import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL SoundCloud!\n\nContoh:\n${prefix + command} https://m.soundcloud.com/teguh-hariyadi-652597010/anji-dia`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/soundclouddl?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.url) {
await reaction(m.chat, '❌')
console.log("SOUNDCLOUD API Error:", data)
return
}

let result = data.result
let title = result.title || "SoundCloud Track"
let user = result.user || "-"
let duration = result.duration ? `${(result.duration / 1000).toFixed(0)}s` : "-"
let audio = result.url
let thumb = result.thumbnail
let source = text

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
audio: { url: audio },
mimetype: 'audio/mp4'
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
audio: { url: audio },
mimetype: 'audio/mp4',
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎧`,
body: `🎵 ${user} • ${duration}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("SOUNDCLOUD Error:", e)
}
}

handler.help = ['Soundcloud Downloader']
handler.tags = ['downloader']
handler.command = ['soundclouddl']

export default handler