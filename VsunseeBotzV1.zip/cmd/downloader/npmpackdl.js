import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan nama package NPM!\n\nContoh:\n${prefix + command} baileys-x`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/npmPack?apikey=${global.VsunseeApikey}&package=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.tarball) {
await reaction(m.chat, '❌')
console.log("NPMPACK API Error:", data)
return
}

let packageName = data.package || text.trim()
let tarball = data.tarball
let filename = `${packageName}.tgz`

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
document: { url: tarball },
fileName: filename,
mimetype: 'application/gzip',
caption: `📦 *NPM PACKAGE DOWNLOADER*\n\n📘 *Package:* ${packageName}\n📎 *Tarball:* ${tarball}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
document: { url: tarball },
fileName: filename,
mimetype: 'application/gzip',
caption: `📦 *NPM PACKAGE DOWNLOADER*\n\n📘 *Package:* ${packageName}\n📎 *Tarball:* ${tarball}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${packageName} • NPM Package`,
body: `📦 Klik untuk mengunduh file .tgz`,
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/d/db/Npm-logo.svg",
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: `https://www.npmjs.com/package/${packageName}`
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("NPMPACK Error:", e)
}
}

handler.help = ['Npm Package Downloader']
handler.tags = ['downloader']
handler.command = ['npmpack']

export default handler