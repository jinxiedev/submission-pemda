import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL Twitter!\n\nContoh:\n${prefix + command} https://twitter.com/9GAG/status/1661175429859012608`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/twitterdl?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.downloadLink) {
await reaction(m.chat, '❌')
console.log("TWITTER API Error:", data)
return
}

let result = data.result
let title = result.videoTitle || "Twitter Video"
let desc = result.videoDescription || "-"
let thumb = result.imgUrl
let video = result.downloadLink
let source = text

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *TWITTER DOWNLOADER*\n\n📌 *Judul:* ${title}\n📝 *Deskripsi:* ${desc}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *TWITTER DOWNLOADER*\n\n📌 *Judul:* ${title}\n📝 *Deskripsi:* ${desc}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎞️`,
body: `🎥 Twitter Downloader`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("TWITTER Error:", e)
}
}

handler.help = ['Twitter Downloader']
handler.tags = ['downloader']
handler.command = ['twitterdl']

export default handler