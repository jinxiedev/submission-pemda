import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL Spotify!\n\nContoh:\n${prefix + command} https://open.spotify.com/intl-id/track/3Puhw21QI2MKR4rdvyPuIb`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/spotify?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data
if (!data || !data.status || !data.result?.dlink) {
await reaction(m.chat, '❌')
console.log("SPOTIFY API Error:", data)
return
}

let result = data.result
let title = result.title || "Spotify Track"
let artist = result.artist || "-"
let album = result.album || "-"
let duration = result.duration || "-"
let thumb = result.image || ""
let audio = result.dlink
let source = result.source || text

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
audio: { url: audio },
mimetype: 'audio/mp4'
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
audio: { url: audio },
mimetype: 'audio/mp4',
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎧`,
body: `🎵 ${artist} • ${duration}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("SPOTIFY Error:", e)
}
}

handler.help = ['Spotify Downloader Music']
handler.tags = ['downloader']
handler.command = ['spotifydl']

export default handler