import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let query = text ? encodeURIComponent(text) : "doraemon"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/playyta?apikey=${global.VsunseeApikey}&q=${query}`)
const data = res.data
if (!data || !data.status || !data.audio?.download_url) {
await reaction(m.chat, '❌')
console.log("PlayYTA API Error:", data)
return
}
await reaction(m.chat, '✨')

let title = data.video.title
let duration = data.video.duration
let views = data.video.views
let urlVideo = data.video.url
let audio = data.audio.download_url
let thumbnail = "https://i.ytimg.com/vi/ztAx-aqeRIg/hqdefault.jpg"

if (modesend === false) {
await vanzz.sendMessage(m.chat, {
audio: { url: audio },
mimetype: 'audio/mp4'
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
audio: { url: audio },
mimetype: 'audio/mp4',
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: title,
body: `${views} views • ${duration}`,
thumbnailUrl: thumbnail,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: urlVideo
}
}
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("PlayYTA Error:", e)
}
}

handler.help = ['Play YouTube Music']
handler.tags = ['downloader']
handler.command = ['play']

export default handler