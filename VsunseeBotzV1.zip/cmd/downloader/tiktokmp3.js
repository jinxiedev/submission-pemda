import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🎧')
const modesend = global.modesend
try {
if (!text) {
await reaction(m.chat, '⚠️')
return
}
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tiktok?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const d = res.data
if (!d.status || !d.result || !d.result.audio_url) {
await reaction(m.chat, '❌')
return
}
await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
audio: { url: d.result.audio_url },
mimetype: 'audio/mpeg'
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
audio: { url: d.result.audio_url },
mimetype: 'audio/mpeg',
ptt: false,
contextInfo: {
externalAdReply: {
title: '🎵 TikTok Audio Downloader',
body: 'Audio berhasil diambil dari TikTok',
thumbnailUrl: 'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl: d.result.audio_url,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
console.error('TIKTOKMP3 ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Tiktok Mp3 Downloader']
handler.tags = ['downloader']
handler.command = ['ttmp3']

export default handler