import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return m.reply(`⚠️ Masukkan URL TikTok!\n\nContoh:\n${prefix + command} https://vt.tiktok.com/xxxx`)
await reaction(m.chat, '🕒')
const modesend = global.modesend
try {
const api = `https://${global.VsunseeApi}/vsunseeV8/tiktok-v2?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`
const res = await axios.get(api)
const data = res.data

const slides = data?.result?.data?.images || []
const info = data?.result?.data || {}
if (!data?.status || slides.length === 0) {
console.log('⚠️ Tidak ada data slide ditemukan dari API TikTok')
return m.reply('*[❌]* Gagal mengambil data slide TikTok atau URL tidak valid.*')
}

if (modesend === 'xreply' || modesend === 'false') {
for (const s of slides.slice(0, 10)) {
await vanzz.sendMessage(m.chat, { image: { url: s } }, { quoted: qtext })
}
await reaction(m.chat, '✅')
return
}

async function getBuffer(url) {
const a = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(a.data)
}

const cards = []
for (let i = 0; i < Math.min(slides.length, 10); i++) {
const url = slides[i]
const buffer = await getBuffer(url)
const media = await prepareWAMessageMedia({ image: buffer }, { upload: vanzz.waUploadToServer })
const card = {
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
imageMessage: media.imageMessage
}),
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `📸 Slide ${i + 1}`
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [
{
name: 'cta_url',
buttonParamsJson: JSON.stringify({
display_text: '🔗 Lihat Gambar',
url
})
}
]
})
}
cards.push(card)
}

const msg = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `👤 Author: ${info.author?.unique_id || '-'}`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
})
}
}
}, { userJid: m.chat, quoted: qtext })

await vanzz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
await reaction(m.chat, '✅')
} catch (e) {
console.error('TIKTOKSLIDE ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
await vanzz.sendMessage(
m.chat,
{
text: `❌ *Gagal mengambil data TikTok!*\n\n🧩 *Error:* ${e?.response?.status || e.code || e.message}\n📜 *Response:* ${JSON.stringify(
e?.response?.data || {},
null,
2
).slice(0, 2000)}`
},
{ quoted: qtext }
)
}
}

handler.help=['Download Image Tiktok Slide ']
handler.tags=['downloader']
handler.command=['tiktokslide']

export default handler