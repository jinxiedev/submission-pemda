import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
if (!text) return m.reply("⚠️ Masukkan URL YouTube!")
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
let api1 = `https://${global.VsunseeApi}/vsunseeV8/ytmp4?apikey=${global.VsunseeApikey}&url=${url}&quality=720`
let api2 = `https://${global.VsunseeApi}/vsunseeV8/savetube?apikey=${global.VsunseeApikey}&url=${url}&format=mp4`
let res1 = await axios.get(api1)
let data1 = res1.data

let videoUrl, title, thumb, duration
if (data1 && data1.status && data1.result?.dlurl) {
videoUrl = data1.result.dlurl
title = decodeURIComponent(data1.result.dlurl.split("title=")[1] || "Video YouTube")
thumb = "https://i.ytimg.com/vi/" + text.split("v=")[1]?.split("&")[0] + "/hqdefault.jpg"
duration = data1.quality ? `${data1.quality}p` : "-"
} else {
let res2 = await axios.get(api2)
let data2 = res2.data
if (!data2 || !data2.status) {
await reaction(m.chat, '❌')
console.log("YTMP4 API Error:", data1, data2)
return
}
videoUrl = data2.dl
title = data2.title
thumb = data2.thumb
duration = data2.format + "p"
}

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
caption: `🎬 ${title}\n📺 Quality: ${duration}`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
caption: `🎬 ${title}\n📺 Quality: ${duration}`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: title,
body: `🎥 MP4 • ${duration}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("YTMP4 Error:", e)
}
}

handler.help = ['Youtube Video Downloader']
handler.tags = ['downloader']
handler.command = ['ytmp4']

export default handler