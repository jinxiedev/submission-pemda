import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
if (!text) return m.reply("⚠️ Masukkan URL TikTok!\n\nContoh:\n.tiktok https://vt.tiktok.com/ZSULgV6tm/")
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tiktok-v2?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data
if (!data || !data.status || !data.result?.data?.play) {
await reaction(m.chat, '❌')
console.log("TIKTOK API Error:", data)
return
}
let result = data.result.data
let videoUrl = result.hdplay || result.play
let title = result.title || `🎬 Video TikTok oleh ${result.author?.nickname || "Unknown"}`
let thumb = result.cover || result.ai_dynamic_cover || result.origin_cover
let duration = result.duration ? `${result.duration}s` : "-"
let author = result.author?.nickname || "Unknown"
let stats = `👁️ ${result.play_count?.toLocaleString() || 0}  💬 ${result.comment_count?.toLocaleString() || 0}  ❤️ ${result.digg_count?.toLocaleString() || 0}`

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
caption: `🎵 *TIKTOK DOWNLOADER*\n\n👤 *Author:* ${author}\n🕒 *Durasi:* ${duration}\n📈 *Statistik:* ${stats}\n🎧 *Sound:* ${result.music_info?.title || "Original Sound"}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
caption: `🎵 *TIKTOK DOWNLOADER*\n\n👤 *Author:* ${author}\n🕒 *Durasi:* ${duration}\n📈 *Statistik:* ${stats}\n🎧 *Sound:* ${result.music_info?.title || "Original Sound"}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${author} 🎭`,
body: `🎬 TikTok • ${duration}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("TIKTOK CASE Error:", e)
}
}

handler.help = ['Tiktok Downloader']
handler.tags = ['downloader']
handler.command = ['tiktok','tt']

export default handler