import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL CapCut!\n\nContoh:\n${prefix + command} https://www.capcut.com/tv2/ZSBwF9X2g/`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/capcut?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data
if (!data || !data.status || !data.result?.videoUrl) {
await reaction(m.chat, '❌')
console.log("CAPCUT API Error:", data)
return
}

let result = data.result
let title = result.title || "CapCut Template"
let author = result.author?.name || "Unknown"
let avatar = result.author?.avatarUrl || result.posterUrl
let pengguna = result.pengguna || "-"
let likes = result.likes || "-"
let date = result.date || "-"
let video = result.videoUrl
let thumb = result.posterUrl

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *CAPCUT TEMPLATE DOWNLOADER*\n\n📌 *Judul:* ${title}\n👤 *Author:* ${author}\n📅 *Tanggal:* ${date}\n📈 *Pengguna:* ${pengguna}\n❤️ *Likes:* ${likes}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *CAPCUT TEMPLATE DOWNLOADER*\n\n📌 *Judul:* ${title}\n👤 *Author:* ${author}\n📅 *Tanggal:* ${date}\n📈 *Pengguna:* ${pengguna}\n❤️ *Likes:* ${likes}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 📹`,
body: `🎥 CapCut Template by ${author}`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("CAPCUT Error:", e)
}
}

handler.help = ['Capcut Video Downloader']
handler.tags = ['downloader']
handler.command = ['capcutdl']

export default handler