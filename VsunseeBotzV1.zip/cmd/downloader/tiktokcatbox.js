import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m,{vanzz,prefix,command,text})=>{
const modesend=global.modesend
const mode=(modesend==='xreply'||modesend==='button')?'xreply':'false'
try{
await vanzz.sendMessage(m.chat,{react:{text:'🎬',key:m.key}})
if(!text){
await vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah!*\n\nGunakan format:\n${prefix+command} url_tiktok\n\n📍 Contoh:\n${prefix+command} https://vt.tiktok.com/ZSUjt9jKS/`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}})
return
}
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tiktoktocatbox?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const teks=`🎬 *TikTok to Catbox*\n\n🎥 Video URL:\n${d.result.video_catbox||'-'}\n🎧 Audio URL:\n${d.result.audio_catbox||'-'}\n\n🌐 Sumber: ${text}`
if(mode==='xreply'){
await vanzz.sendMessage(m.chat,{
video:{url:d.result.video_catbox},
caption:teks,
contextInfo:{
externalAdReply:{
title:'🎵 TikTok Downloader',
body:'Video berhasil diunggah ke Catbox',
thumbnailUrl:'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl:d.result.video_catbox,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
if(d.result.audio_catbox)await vanzz.sendMessage(m.chat,{audio:{url:d.result.audio_catbox},mimetype:'audio/mpeg'},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{video:{url:d.result.video_catbox},caption:teks},{quoted:qtext})
if(d.result.audio_catbox)await vanzz.sendMessage(m.chat,{audio:{url:d.result.audio_catbox},mimetype:'audio/mpeg'},{quoted:qtext})
}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('TIKTOKCATBOX ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}
}

handler.help=['TikTok To Catbox']
handler.tags=['downloader']
handler.command=['tiktokcatbox']

export default handler