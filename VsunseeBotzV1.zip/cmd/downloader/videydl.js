import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL Videy!\n\nContoh:\n${prefix + command} https://videy.co/v?id=HNbmwhTi1`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
let url = encodeURIComponent(text.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/videy?apikey=${global.VsunseeApikey}&url=${url}`)
const data = res.data

if (!data || !data.status || !data.result) {
await reaction(m.chat, '❌')
console.log("VIDEY API Error:", data)
return
}

let video = data.result
let title = "Videy Downloader"
let thumb = "https://cdn.videy.co/favicon.png"
let source = text

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *VIDEY DOWNLOADER*\n\n📌 *Sumber:* ${source}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
video: { url: video },
mimetype: 'video/mp4',
caption: `🎬 *VIDEY DOWNLOADER*\n\n📌 *Sumber:* ${source}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} 🎞️`,
body: `🎥 Videy Downloader`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: source
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("VIDEY Error:", e)
}
}

handler.help = ['Videy Downloader']
handler.tags = ['downloader']
handler.command = ['videydl']

export default handler