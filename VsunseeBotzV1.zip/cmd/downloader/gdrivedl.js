import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL Google Drive!\n\nContoh:\n${prefix + command} https://drive.google.com/file/d/1AfkahBoAeYQ4AUZKLZdI4KxJi42xSyrV/view?usp=drivesdk`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/gdrive?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.downloadLink) {
await reaction(m.chat, '❌')
console.log("GDRIVE API Error:", data)
return
}

let result = data.result
let fileId = result.fileId || "-"
let fileurl = result.downloadLink
let info = result.info || "-"
let filename = `GDrive_File_${fileId}.zip`

let ext = (fileurl.split('.').pop().split('?')[0] || 'bin').toLowerCase()
let mimetype = 'application/octet-stream'
if (/(zip|rar|7z)$/i.test(ext)) mimetype = 'application/zip'
else if (/(apk)$/i.test(ext)) mimetype = 'application/vnd.android.package-archive'
else if (/(mp3|wav|m4a)$/i.test(ext)) mimetype = 'audio/mpeg'
else if (/(mp4|mkv|avi)$/i.test(ext)) mimetype = 'video/mp4'
else if (/(pdf)$/i.test(ext)) mimetype = 'application/pdf'
else if (/(txt|log|json)$/i.test(ext)) mimetype = 'text/plain'

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
document: { url: fileurl },
fileName: filename,
mimetype: mimetype,
caption: `📂 *GOOGLE DRIVE DOWNLOADER*\n\n🆔 *File ID:* ${fileId}\n📎 *Download Link:* ${fileurl}\nℹ️ *Info:* ${info}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
document: { url: fileurl },
fileName: filename,
mimetype: mimetype,
caption: `📂 *GOOGLE DRIVE DOWNLOADER*\n\n🆔 *File ID:* ${fileId}\n📎 *Download Link:* ${fileurl}\nℹ️ *Info:* ${info}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${filename} • Google Drive File`,
body: `📥 Klik untuk mengunduh file dari GDrive`,
thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/d/da/Google_Drive_logo.png",
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("GDRIVE Error:", e)
}
}

handler.help = ['Google Drive Files Downloader']
handler.tags = ['downloader']
handler.command = ['gdrivedl']

export default handler