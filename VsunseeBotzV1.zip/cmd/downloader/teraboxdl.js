import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, command, prefix }) => {
if (!text) return m.reply(`⚠️ Masukkan URL TeraBox!\n\nContoh:\n${prefix + command} https://1024terabox.com/s/1dpDQcReXa2rT9dMMdtM6Yw`)
await reaction(m.chat, '🗯')
const modesend = global.modesend
try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/teraboxdl?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text.trim())}`)
const data = res.data

if (!data || !data.status || !data.result?.download_link) {
await reaction(m.chat, '❌')
console.log("TERABOX API Error:", data)
return
}

let result = data.result
let title = result.title || "TeraBox_File"
let size = result.size || "-"
let thumb = result.thumbnail
let fileurl = result.download_link

let extMatch = title.match(/\.[0-9A-Za-z]+$/)
let ext = extMatch ? extMatch[0].toLowerCase() : (fileurl.split('.').pop().split('?')[0] || 'bin')

let mimetype = 'application/octet-stream'
if (/(zip|rar|7z)$/i.test(ext)) mimetype = 'application/zip'
else if (/(apk)$/i.test(ext)) mimetype = 'application/vnd.android.package-archive'
else if (/(mp3|wav|m4a)$/i.test(ext)) mimetype = 'audio/mpeg'
else if (/(mp4|mkv|avi)$/i.test(ext)) mimetype = 'video/mp4'
else if (/(pdf)$/i.test(ext)) mimetype = 'application/pdf'
else if (/(txt|log|json)$/i.test(ext)) mimetype = 'text/plain'

await reaction(m.chat, '✨')
if (modesend === false) {
await vanzz.sendMessage(m.chat, {
document: { url: fileurl },
fileName: title,
mimetype: mimetype,
caption: `📦 *TERABOX DOWNLOADER*\n\n📁 *Nama File:* ${title}\n📏 *Ukuran:* ${size}\n🔗 *Link:* ${fileurl}\n\n🪄 _Powered By Vann Ryuichi_`
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, {
document: { url: fileurl },
fileName: title,
mimetype: mimetype,
caption: `📦 *TERABOX DOWNLOADER*\n\n📁 *Nama File:* ${title}\n📏 *Ukuran:* ${size}\n🔗 *Link:* ${fileurl}\n\n🪄 _Powered By Vann Ryuichi_`,
contextInfo: {
mentionedJid: [m.sender],
isForwarded: false,
externalAdReply: {
title: `${title} • TeraBox File`,
body: `📥 Klik untuk mengunduh (${size})`,
thumbnailUrl: thumb,
mediaType: 1,
renderLargerThumbnail: true,
showAdAttribution: false,
sourceUrl: text
}
}
}, { quoted: qtext })
}
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("TERABOX Error:", e)
}
}

handler.help = ['Terabox Downloader']
handler.tags = ['downloader']
handler.command = ['teraboxdl']

export default handler