import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/robloxtopplay?apikey=${global.VsunseeApikey}`)
const { status, games } = res.data

if (!status || !Array.isArray(games) || !games.length) {
await reaction(m.chat, '❌')
console.log("ROBLOX TOP PLAY API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: '❌ Tidak ada data game ditemukan.' }, { quoted: m })
}

const top = games.slice(0, 10).map(v =>
`#${v.rank} *${v.name}*\n👥 ${v.players.toLocaleString()} pemain\n👍 ${v.likes}\n🔗 ${v.playUrl}`).join('\n\n')

const caption = `🎮 *ROBLOX TOP 10 PLAYED GAMES*\n\n${top}\n\n📊 Data by Vsunsee API`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `🔥 Roblox Top Games`,
body: `Top 10 most played games on Roblox`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: games[0].playUrl,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('ROBLOX TOP PLAY General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Top Game Roblox']
handler.tags = ['check']
handler.command = ['robloxtopplay']

export default handler
