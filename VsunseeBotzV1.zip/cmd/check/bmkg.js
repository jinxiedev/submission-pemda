import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cekgempa?apikey=${global.VsunseeApikey}`)
let data = res.data
const { status, result } = data
if (!status || !result) {
await reaction(m.chat, '❌')
console.log("BMKG API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: '❌ Tidak ada data gempa terkini ditemukan.' }, { quoted: m })
}

const caption = `🌏 *Info Gempa Terkini BMKG*\n\n📍 *Lokasi:* ${result.lokasi}\n🕒 *Waktu:* ${result.waktu}\n💥 *Magnitude:* ${result.magnitude}\n📏 *Kedalaman:* ${result.kedalaman}\n📌 *Koordinat:* ${result.koordinat}\n⚠️ *Potensi:* ${result.potensi}\n💬 *Dirasakan:* ${result.dirasakan}\n\n🛰️ _Data bersumber dari BMKG Indonesia_`

try {
await vanzz.sendMessage(m.chat, {
text: caption,
contextInfo: {
externalAdReply: {
title: `🌋 Gempa Terkini - BMKG`,
body: `${result.waktu} | ${result.lokasi}`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://bmkg.go.id`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("BMKG General Error:", e?.response?.data || e)
}
}

handler.help = ['Cek Info Gempa BMKG']
handler.tags = ['check']
handler.command = ['bmkg']

export default handler
