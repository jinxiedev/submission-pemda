import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, {
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nomor_hp\n\n📍 Contoh:\n${prefix + command} 6285754661077`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cek-nomor?apikey=${global.VsunseeApikey}&nomor=${encodeURIComponent(text)}`)
const r = res.data.data
if (!r || !r.nomor) {
await reaction(m.chat, '❌')
console.log("CEK NOMOR API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ Nomor *${text}* tidak ditemukan.` }, { quoted: m })
}

const caption = `📞 *Cek Nomor*\n\n🔢 *Nomor:* ${r.nomor}\n📡 *Operator:* ${r.operator}\n💳 *Tipe:* ${r.tipe}\n📍 *Lokasi:* ${r.lokasi_perkiraan}\n🗒️ *Catatan:* ${r.catatan}`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `📱 Nomor ${r.operator}`,
body: 'Data diambil dari Vsunsee API',
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://wa.me/${r.nomor.replace(/^0/, '62')}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('CEK NOMOR General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek Nomor HP']
handler.tags = ['check']
handler.command = ['ceknomor']

export default handler
