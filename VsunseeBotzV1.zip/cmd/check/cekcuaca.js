import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text) return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} nama_kota\n\n📍 Contoh:\n${prefix+command} Sukamara`},{quoted:qtext})

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cekcuaca?apikey=${global.VsunseeApikey}&kota=${encodeURIComponent(text)}`)
const r=res.data
if(!r||!r.lokasi){
await reaction(m.chat, '❌')
console.log("CEK CUACA API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `*[ ❌ ]* Data cuaca untuk *${text}* tidak ditemukan.` }, { quoted: m })
}

const caption=`🌤️ *Info Cuaca Saat Ini*\n\n📍 *Lokasi:* ${r.lokasi}\n🌡️ *Suhu:* ${r.suhu}\n💧 *Kelembaban:* ${r.kelembaban}\n💨 *Angin:* ${r.angin}\n☁️ *Kondisi:* ${r.kondisi}\n🗒️ *Sumber:* ${r.info}`

try {
const msgData={
text:caption,
contextInfo:{
externalAdReply:{
title:`🌦️ Cuaca di ${r.lokasi}`,
body:'Data diambil dari Vsunsee API',
thumbnailUrl:global.ThumbCheck,
sourceUrl:`https://wttr.in/${encodeURIComponent(r.lokasi)}`,
mediaType:1,
renderLargerThumbnail:true
}
}
}
await vanzz.sendMessage(m.chat,msgData,{quoted:qtext})

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("CEK CUACA General Error:", e?.response?.data || e)
}
}

handler.help = ['Cek Cuaca Kota']
handler.tags = ['check']
handler.command = ['cekcuaca']

export default handler
