import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, {
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nomor_resi|ekspedisi\n\n📍 Contoh:\n${prefix + command} SPXID054330680586|shopee-express`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const [resi, ekspedisi] = text.split('|')
if (!resi || !ekspedisi)
return vanzz.sendMessage(m.chat, { text: `⚠️ Format salah!\nGunakan format:\n${prefix + command} nomor_resi|ekspedisi` }, { quoted: m })

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cekresi?apikey=${global.VsunseeApikey}&noresi=${encodeURIComponent(resi)}&ekspedisi=${encodeURIComponent(ekspedisi)}`)
const { status, result } = res.data
if (!status || !result?.data) {
await reaction(m.chat, '❌')
console.log("CEK RESI API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ Nomor resi *${resi}* tidak ditemukan.` }, { quoted: m })
}

const info = result.data
const track = info.history.slice(0, 5).map(v => `🕒 *${v.tanggal}*\n📍 ${v.keterangan}`).join('\n\n')
const caption = `📦 *CEK RESI ${info.ekspedisi.toUpperCase()}*\n\n🔢 *Resi:* ${info.resi}\n🚚 *Status:* ${info.status}\n📅 *Tanggal Kirim:* ${info.tanggalKirim}\n📍 *Posisi Terakhir:* ${info.lastPosition}\n☎️ *CS:* ${info.customerService}\n\n🧭 *Riwayat Terbaru:*\n${track}\n\n🔗 *Cek Lengkap:* ${info.shareLink}`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `📬 ${info.ekspedisi}`,
body: `Status: ${info.status}`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: info.shareLink,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('CEK RESI General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek Resi Paket']
handler.tags = ['check']
handler.command = ['cekresi']

export default handler
