import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, {
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nama_channel\n\n📍 Contoh:\n${prefix + command} indosiar`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/jadwaltv?apikey=${global.VsunseeApikey}&channel=${encodeURIComponent(text)}`)
const { status, result } = res.data

if (!status || !Array.isArray(result) || !result.length) {
await reaction(m.chat, '❌')
console.log("JADWALTV API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ Channel *${text}* tidak ditemukan atau tidak ada jadwal hari ini.` }, { quoted: m })
}

const jadwalList = result.slice(0, 10)
  .map((v, i) => `*${i + 1}.* 🕒 ${v.jam}\n🎬 ${v.acara}`)
  .join('\n\n')

const caption = `📡 *Jadwal TV: ${text.toUpperCase()}*\n\n${jadwalList}\n\n🕘 _Data diperbarui otomatis tiap hari._`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `📺 ${text.toUpperCase()} - Jadwal Siaran TV`,
body: 'Data diambil dari API Vsunsee',
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://jadwaltv.net/channel/${encodeURIComponent(text.toLowerCase())}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('JADWALTV General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek Jadwal TV']
handler.tags = ['check']
handler.command = ['jadwaltv']

export default handler
