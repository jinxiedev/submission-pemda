import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/growagarden?apikey=${global.VsunseeApikey}`)
const {status,result}=res.data
if(!status||!result?.data) {
await reaction(m.chat, '❌')
console.log("GROW A GARDEN API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: '❌ Data Grow a Garden tidak ditemukan.' }, { quoted: m })
}

const d=result.data
const seeds=d.seeds?.map(v=>`🌾 *${v.name}* — ${v.quantity}x`).join('\n')||'-'
const gear=d.gear?.map(v=>`⚙️ *${v.name}* — ${v.quantity}x`).join('\n')||'-'
const eggs=d.eggs?.map(v=>`🥚 *${v.name}* — ${v.quantity}x`).join('\n')||'-'
const cosmetics=d.cosmetics?.map(v=>`🎁 *${v.name}* — ${v.quantity}x`).join('\n')||'-'
const honey=d.honey?.map(v=>`🍯 *${v.name}* — ${v.quantity}x`).join('\n')||'-'
const events=d.events?.map(v=>`🎉 *${v.name}* — ${v.quantity}x`).join('\n')||'-'
const merchant=d.travelingMerchant
const merchItems=merchant?.items?.map(i=>`🛒 *${i.name}* — ${i.quantity}x`).join('\n')||'-'
const weatherNow=d.weather?.type?`🌤️ *Weather:* ${d.weather.type.toUpperCase()}`:'🌤️ *Weather:* Normal'

const caption=`🌱 *GROW A GARDEN STATUS*\n\n📅 *Last Update:* ${new Date(d.lastGlobalUpdate).toLocaleString()}\n${weatherNow}\n\n🏷️ *Merchant:* ${merchant?.merchantName||'Tidak ada'}\n🧺 *Items:*\n${merchItems}\n\n🌾 *Seeds:*\n${seeds}\n\n⚙️ *Gear:*\n${gear}\n\n🥚 *Eggs:*\n${eggs}\n\n🎁 *Cosmetics:*\n${cosmetics}\n\n🍯 *Honey Shop:*\n${honey}\n\n🎉 *Event Items:*\n${events}\n\n🔗 *Source:* Roblox Grow a Garden`

try {
const msgData={
text:caption,
contextInfo:{
externalAdReply:{
title:`🌿 ${merchant?.embedTitle||'Grow a Garden Data'}`,
body:'Live Garden Inventory & Merchant Info',
thumbnailUrl:global.ThumbCheck,
sourceUrl:'https://www.roblox.com/games/126884695634066',
mediaType:1,
renderLargerThumbnail:true
}
}
}
await vanzz.sendMessage(m.chat,msgData,{quoted:qtext})

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
}catch(e){
await reaction(m.chat, '❌')
console.error('GROW A GARDEN General ERROR:',e?.response?.data||e)
}}

handler.help=['Grow A Garden Tracker']
handler.tags=['check']
handler.command=['growagarden']

export default handler
