import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, { 
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} url_website\n\n📍 Contoh:\n${prefix + command} https://example.com`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/scanWebsite?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const data = res.data
if (!data.status || !data.data) {
await reaction(m.chat, '❌')
console.log("SCAN WEBSITE API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: '❌ Gagal memindai website, pastikan URL valid.' }, { quoted: m })
}

const d = data.data
const ssl = d.details.ssl || {}
const geo = d.details.geo || {}
const scan = d.scanSummary || {}

const teks = `🌐 *Hasil Pemindaian Website*\n\n` +
`🔗 *URL:* ${d.scannedUrl}\n` +
`🛡️ *Status:* ${scan.status_text} (${scan.status})\n` +
`📊 *Skor Keamanan:* ${scan.score}\n` +
`🚫 *Phishing:* ${scan.totals.phishing}\n` +
`☣️ *Malicious:* ${scan.totals.malicious}\n` +
`⚠️ *Suspicious:* ${scan.totals.suspicious}\n` +
`✅ *Clean:* ${scan.totals.clean}\n\n` +
`🌍 *Lokasi Server:*\n• Negara: ${geo.Country}\n• Kota: ${geo.City}\n• ISP: ${geo.ISP}\n• IP: ${geo.IP}\n\n` +
`🔐 *Informasi SSL:*\n• CN: ${ssl.Subject?.CN}\n• Issuer: ${ssl.Issuer?.CN}\n• Berlaku Hingga: ${ssl['Valid To']}\n• Sisa Hari: ${ssl['Days Remaining']} Hari\n\n` +
`💻 *Teknologi:* ${d.details.tech?.Server || '-'} | ${d.details.tech?.['X-Powered-By'] || '-'}\n` +
`━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* Vsunsee Security Scanner\n🔗 *https://${global.VsunseeApi}*`

try {
const msgData = {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: '🔎 Website Scanner',
body: `${d.domain} dinyatakan ${scan.status_text}`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: d.scannedUrl,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: teks.trim()
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('SCAN WEBSITE General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek Website Security']
handler.tags = ['check']
handler.command = ['scanweb']

export default handler
