import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, { 
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} username_tiktok\n\n📍 Contoh:\n${prefix + command} whyzzzxy`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tiktokearning?apikey=${global.VsunseeApikey}&user=${encodeURIComponent(text)}`)
const { status, result } = res.data

if (!status || !result?.data) {
await reaction(m.chat, '❌')
console.log("TIKTOK EARNING API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ Akun *${text}* tidak ditemukan.` }, { quoted: m })
}

const user = result.data

const caption = `🎵 *TIKTOK EARNING CHECK*\n\n👤 *Username:* ${user.username}\n📛 *Fullname:* ${user.fullname}\n🆔 *User ID:* ${user.user_id}\n📹 *Videos:* ${user.videos}\n❤️ *Likes:* ${user.hearts.toLocaleString()}\n👥 *Followers:* ${user.followers.toLocaleString()}\n💸 *Estimated Earning:* $${user.earnings.toFixed(2)}\n\n🕒 *Last Updated:* ${new Date(result.timestamp).toLocaleString()}`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `💵 ${user.username} — TikTok Earning`,
body: `Total earning: $${user.earnings.toFixed(2)} | Followers: ${user.followers.toLocaleString()}`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://www.tiktok.com/@${user.username}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('TIKTOK EARNING General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek TikTok Earning']
handler.tags = ['check']
handler.command = ['tiktokearning']

export default handler
