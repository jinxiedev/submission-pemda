import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cekgempa?apikey=${global.VsunseeApikey}`)
const r=res.data.result
if(!r||!r.lokasi){
await reaction(m.chat, '❌')
console.log("CEK GEMPA API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: '❌ Tidak ada data gempa terkini ditemukan.' }, { quoted: m })
}

const caption=`🌋 *Info Gempa Terkini BMKG*\n\n📍 *Lokasi:* ${r.lokasi}\n🕒 *Waktu:* ${r.waktu}\n💥 *Magnitudo:* ${r.magnitude}\n🌊 *Kedalaman:* ${r.kedalaman}\n📌 *Koordinat:* ${r.koordinat}\n⚠️ *Potensi:* ${r.potensi}\n🙌 *Dirasakan:* ${r.dirasakan}`

try {
const msgData={
text:caption,
contextInfo:{
externalAdReply:{
title:`🌋 Gempa Terkini - ${r.lokasi}`,
body:`${r.waktu}`,
thumbnailUrl:global.ThumbCheck,
sourceUrl:'https://bmkg.go.id',
mediaType:1,
renderLargerThumbnail:true
}
}
}
await vanzz.sendMessage(m.chat,msgData,{quoted:qtext})

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("CEK GEMPA General Error:", e?.response?.data || e)
}
}

handler.help=['Cek Gempa Terkini']
handler.tags=['check']
handler.command=['cekgempa']

export default handler
