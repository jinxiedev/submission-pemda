import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js"

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, { text: `⚠️ Masukkan nama daerah atau kode pos!\n\nContoh:\n${prefix + command} Sukamara\n${prefix + command} 34177` }, { quoted: m })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cekkodepos?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const { status, result } = res.data
if (!status || !Array.isArray(result) || !result.length) {
await reaction(m.chat, '❌')
console.log("CEK KODEPOS API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ Tidak ditemukan data untuk *${text}*.` }, { quoted: m })
}

let raw = result[0].propinsi
raw = raw.replace(/Ditemukan.*?(?=•)/s, '').trim()
raw = raw.replace(/\s+/g, ' ')

let entries = raw.split('•').map(v => v.trim()).filter(Boolean)
let formatted = entries.map((v, i) => `*${i + 1}.* ${v}`).join('\n\n')

if (formatted.length > 4000) formatted = formatted.slice(0, 4000) + '...'

const teks = `📍 *Hasil Pencarian Kode Pos untuk:* _${text}_\n\n${formatted}\n\n📬 _Sumber: posindonesia.co.id (via Vsunsee API)_`

try {
const msgData = {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: "📮 Cek Kode Pos Indonesia",
body: "Sumber: posindonesia.co.id (via Vsunsee API)",
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/cekkodepos?q=${encodeURIComponent(text)}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: teks.trim()
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('CEK KODEPOS General ERROR:', e?.response?.data || e)
vanzz.sendMessage(m.chat, { text: '*[❌]* Gagal mengambil data dari Kode Pos API.*' }, { quoted: m })
}
}

handler.help = ['Check KodePos']
handler.tags = ['check']
handler.command = ['cekkodepos']

export default handler
