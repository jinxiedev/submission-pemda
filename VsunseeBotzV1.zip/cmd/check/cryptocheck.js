import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, { 
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} symbol_crypto\n\n📍 Contoh:\n${prefix + command} BTCUSDT`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cryptoAnalytics?apikey=${global.VsunseeApikey}&symbol=${encodeURIComponent(text)}`)
const { status, result } = res.data

if (!status || !result) {
await reaction(m.chat, '❌')
console.log("CRYPTO CHECK API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ Symbol *${text}* tidak ditemukan.` }, { quoted: m })
}

const caption = `💰 *Crypto Analytics*\n\n` +
`💎 *${result.name} (${result.symbol})*\n` +
`📊 *Pair:* ${result.pair}\n` +
`💵 *Price:* $${result.currentPrice.toLocaleString()}\n` +
`📈 *Change 24h:* ${result.change24h}\n` +
`🏦 *Market Cap:* $${result.marketCap.toLocaleString()}\n` +
`🔄 *Volume 24h:* $${result.volume24h.toLocaleString()}\n` +
`💠 *Supply:* ${result.circulatingSupply.toLocaleString()} / ${result.totalSupply.toLocaleString()}\n` +
`🚀 *ATH:* $${result.ath.price.toLocaleString()} (${new Date(result.ath.date).toLocaleDateString()})\n` +
`📉 *ATL:* $${result.atl.price.toLocaleString()} (${new Date(result.atl.date).toLocaleDateString()})\n` +
`🕒 *Last Updated:* ${new Date(result.lastUpdated).toLocaleString()}\n\n` +
`🔗 *Source:* ${result.source}`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `📊 ${result.name} (${result.symbol})`,
body: `Last updated • ${result.source}`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://www.coingecko.com/en/coins/${result.id}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('CRYPTO CHECK General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek Harga & Data Crypto']
handler.tags = ['check']
handler.command = ['cekcrypto']

export default handler
