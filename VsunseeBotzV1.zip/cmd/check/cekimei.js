import axios from 'axios'
import "../../settings/config.js"
import '../../settings/thumb.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, reaction, text, prefix, command }) => {
if (!text)
return vanzz.sendMessage(m.chat, {
text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nomor_imei\n\n📍 Contoh:\n${prefix + command} 356938035643809`
}, { quoted: qtext })

await reaction(m.chat, '🗯')
await reaction(m.chat, '✨')

try {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/imei?apikey=${global.VsunseeApikey}&imei=${encodeURIComponent(text)}`)
const { status, data: imeiData } = res.data

if (!status || !imeiData?.result) {
await reaction(m.chat, '❌')
console.log("IMEI CHECK API Response Error:", res.data)
return vanzz.sendMessage(m.chat, { text: `❌ IMEI *${text}* tidak ditemukan.` }, { quoted: m })
}

const header = imeiData.result.header
const items = imeiData.result.items || []
const basic = items
  .filter(i => i.role === 'item')
  .map(v => `• *${v.title}:* ${v.content}`)
  .join('\n')

const caption = `📱 *IMEI CHECK RESULT*\n\n🔢 *IMEI:* ${header.imei}\n🏷️ *Brand:* ${header.brand}\n📦 *Model:* ${header.model}\n\n${basic}\n\n🌐 *Full Detail:*\nhttps://www.imei.info/phonedatabase/${header.model.toLowerCase().replace(/\s+/g, '-')}/`

try {
const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `📲 ${header.brand} ${header.model}`,
body: `IMEI: ${header.imei} | Checked via Vsunsee API`,
thumbnailUrl: global.ThumbCheck,
sourceUrl: `https://www.imei.info/phonedatabase/${header.model.toLowerCase().replace(/\s+/g, '-')}/`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}
await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

} catch (adReplyError) {
console.log("External Ad Reply Error, initiating fallback to send image:", adReplyError)
await vanzz.sendMessage(m.chat, {
image: { url: global.ThumbCheck },
caption: caption
}, { quoted: qtext })
}

await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.error('IMEI CHECK General ERROR:', e?.response?.data || e)
}
}

handler.help = ['Cek IMEI Device']
handler.tags = ['check']
handler.command = ['cekimei']

export default handler
