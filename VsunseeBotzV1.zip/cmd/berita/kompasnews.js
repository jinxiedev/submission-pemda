import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/kompas?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !Array.isArray(data.result) || !data.result.length) {
await reaction(m.chat, '❌')
console.log('KOMPAS API Error:', data)
return m.reply('❌ Gagal mengambil berita dari Kompas.')
}

let teks = `🗞️ *Berita Terbaru Kompas*\n\n`
data.result.forEach((item, i) => {
teks += `📰 *${i + 1}. ${item.title}*\n`
teks += `📅 ${item.date}\n`
teks += `🏷️ ${item.category}\n`
teks += `🔗 ${item.link}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* Kompas.com\n🔗 *API:* https://apiz.vsunsee.click`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'Kompas News',
body: 'Berita nasional, megapolitan, dan politik terkini',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('KOMPAS ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Kompas News']
handler.tags = ['news']
handler.command = ['kompasnews']

export default handler
