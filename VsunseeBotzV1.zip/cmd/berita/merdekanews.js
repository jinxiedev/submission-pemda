import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/merdeka?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !Array.isArray(data.result) || !data.result.length) {
await reaction(m.chat, '❌')
console.log('MERDEKA API Error:', data)
return m.reply('❌ Gagal mengambil berita dari Merdeka.com.')
}

let teks = `📰 *Berita Terbaru Merdeka.com*\n\n`
data.result.forEach((item, i) => {
teks += `📌 *${i + 1}. ${item.title}*\n`
teks += `📅 ${item.date}\n`
teks += `🏷️ ${item.category}\n`
teks += `📝 ${item.description}\n`
teks += `🔗 ${item.link}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* Merdeka.com\n🔗 *API:* https://apiz.vsunsee.click`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'Merdeka.com News',
body: 'Berita terkini dan update nasional hari ini',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('MERDEKA ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Merdeka News']
handler.tags = ['news']
handler.command = ['merdekanews']

export default handler