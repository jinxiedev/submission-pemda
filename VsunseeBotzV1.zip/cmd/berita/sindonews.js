import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/sindonews?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !Array.isArray(data.result) || !data.result.length) {
await reaction(m.chat, '❌')
console.log('SINDONEWS API Error:', data)
return m.reply('❌ Gagal mengambil berita dari Sindonews.')
}

let teks = `🗞️ *Berita Terbaru Sindonews*\n\n`
data.result.forEach((item, i) => {
teks += `📌 *${i + 1}. ${item.title}*\n`
teks += `🏷️ ${item.category}\n`
teks += `📅 ${item.date}\n`
teks += `🔗 ${item.link}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* Sindonews.com\n🔗 *API:* https://apiz.vsunsee.click`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'Sindonews News',
body: 'Update berita dari Sindonews',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('SINDONEWS ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Sindo News']
handler.tags = ['news']
handler.command = ['sindonews']

export default handler