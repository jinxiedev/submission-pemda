import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/liputan6?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !data.items) {
await reaction(m.chat, '❌')
console.log('LIPUTAN6 API Error:', data)
return m.reply('❌ Gagal mengambil berita dari Liputan6.')
}

let teks = `🗞️ *Liputan6 Terbaru*\n\n`
data.items.slice(0, 10).forEach((item, i) => {
teks += `📌 *${i + 1}. ${item.title}*\n`
teks += `🕓 ${new Date(item.published_at).toLocaleString('id-ID')}\n`
teks += `🔗 ${item.link}\n`
teks += `📝 ${item.summary || 'Tidak ada ringkasan.'}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* Liputan6.id\n🔗 *API:* https://${global.VsunseeApi}`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'Liputan6 News Feed',
body: 'Berita terbaru dari Liputan6.id',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('LIPUTAN6 ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Liputan6 News']
handler.tags = ['news']
handler.command = ['liputan6news']

export default handler