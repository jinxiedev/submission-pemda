import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/antara?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !Array.isArray(data.items) || !data.items.length) {
await reaction(m.chat, '❌')
console.log('ANTARA API Error:', data)
return m.reply('❌ Gagal mengambil berita dari Antara News.')
}

let teks = `🗞️ *Berita Terbaru Antara News*\n\n`
data.items.slice(0, 10).forEach((item, i) => {
teks += `📌 *${i + 1}. ${item.title}*\n`
teks += `🕒 ${new Date(item.published_at).toLocaleString('id-ID')}\n`
teks += `📰 ${item.summary || 'Tidak ada ringkasan.'}\n`
teks += `🔗 ${item.link}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* Antara News\n🔗 *https://apiz.vsunsee.click*`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'Antara News - Indonesia Update',
body: 'Berita nasional dan internasional terbaru',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('ANTARA ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Antara News']
handler.tags = ['news']
handler.command = ['antaranews']

export default handler