import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/cnbc?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !Array.isArray(data.items) || !data.items.length) {
await reaction(m.chat, '❌')
console.log('CNBC API Error:', data)
return m.reply('❌ Gagal mengambil berita dari CNBC Indonesia.')
}

let teks = `💼 *CNBC Indonesia Terbaru*\n\n`
data.items.slice(0, 10).forEach((item, i) => {
teks += `📰 *${i + 1}. ${item.title}*\n`
teks += `🔗 ${item.link}\n`
teks += `📝 ${item.summary || 'Tidak ada ringkasan.'}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* CNBC Indonesia\n🔗 *API:* https://apiz.vsunsee.click`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'CNBC Indonesia News',
body: 'Berita ekonomi dan bisnis terkini',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('CNBC ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Cnbc News']
handler.tags = ['news']
handler.command = ['cnbcnews']

export default handler
