import axios from 'axios'
import '../../settings/config.js'
import '../../settings/thumb.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction }) => {
await reaction(m.chat, '🗯')
try {
await reaction(m.chat, '✨')
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/jkt48?apikey=${global.VsunseeApikey}`)
const data = res.data

if (!data.status || !Array.isArray(data.result) || !data.result.length) {
await reaction(m.chat, '❌')
console.log('JKT48 API Error:', data)
return m.reply('❌ Gagal mengambil berita dari situs JKT48.')
}

let teks = `🎶 *Berita Terbaru JKT48*\n\n`
data.result.forEach((item, i) => {
teks += `✨ *${i + 1}. ${item.title}*\n`
teks += `📅 ${item.date}\n`
teks += `🔗 ${item.link}\n\n`
})
teks += `━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* JKT48.com\n🔗 *API:* https://apiz.vsunsee.click`

await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: 'JKT48 Official News',
body: 'Update terbaru dari situs resmi JKT48',
thumbnailUrl: global.ThumbNews,
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })

await reaction(m.chat, '✅')
} catch (e) {
console.error('JKT48 ERROR:', e?.response?.data || e)
await reaction(m.chat, '❌')
}
}

handler.help = ['Jkt48 News']
handler.tags = ['news']
handler.command = ['jkt48news']

export default handler