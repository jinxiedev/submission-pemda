import '../../settings/config.js'
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzz, text }) => {
try {
if (!text) return m.reply('⚠️ Masukkan teks yang ingin dikirim ke Channel WhatsApp.')
await vanzz.sendMessage(global.ChannelID, { text })
await vanzreply(m, '✅ Berhasil mengirim pesan ke Channel WhatsApp.')
} catch (e) {
console.error('UPCHTEXT ERROR:', e)
await vanzreply(m, '❌ Gagal mengirim pesan ke channel.')
}
}

handler.help = ['Up Chat Text Ke Channel']
handler.tags = ['community']
handler.command = ['upchtext']
handler.owner = true

export default handler