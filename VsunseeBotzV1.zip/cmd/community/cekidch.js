import fetch from 'node-fetch'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m, { text, prefix, command, vanzz, qtext }) => {
try {
if (!text) return m.reply(`⚠️ Contoh: ${prefix + command} https://whatsapp.com/channel/XXXXXXXXXXXXXXX`)
if (!text.includes('https://whatsapp.com/channel/')) return m.reply('❌ Link channel tidak valid!')
const result = text.split('https://whatsapp.com/channel/')[1]
const res = await vanzz.newsletterMetadata('invite', result)
const deskripsi = res.description || 'Tidak ada deskripsi.'
const teks = `📢 *INFORMASI CHANNEL WHATSAPP*

🆔 *ID:* ${res.id}
📛 *Nama:* ${res.name}
👥 *Total Pengikut:* ${res.subscribers}
📶 *Status:* ${res.state}
✅ *Verifikasi:* ${res.verification === 'VERIFIED' ? 'Terverifikasi' : 'Tidak'}

📝 *Deskripsi:*
${deskripsi}
`
const msgData = {
text: teks.trim(),
contextInfo: {
externalAdReply: {
title: res.name || 'WhatsApp Channel Info',
body: 'Tekan tombol di bawah untuk salin ID Channel',
thumbnailUrl: res.preview || 'https://files.catbox.moe/bsrbf2.jpeg',
sourceUrl: text,
mediaType: 1,
renderLargerThumbnail: true
}
},
buttons: [
{
buttonId: `copy_${res.id}`,
buttonText: { displayText: '📋 Salin ID Channel' },
type: 1
}
]
}
if (typeof msgData.text !== 'string') msgData.text = String(msgData.text || '')
if (modesend === 'xreply' || modesend === 'button') await vanzreply(m, msgData.text)
else await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('CEKIDCH ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Cek ID Channel Whatsapp']
handler.tags = ['community']
handler.command = ['cekidch']

export default handler