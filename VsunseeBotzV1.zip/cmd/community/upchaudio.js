import fs from 'fs'
import '../../settings/config.js'
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz})=>{
try{
let q=m.quoted?m.quoted:m
let mime=(q.msg||q).mimetype||''
if(!/audio/.test(mime))return m.reply('⚠️ Balas atau kirim VN (audio) yang ingin dikirim.')

const channelList=Array.isArray(global.ChannelID)?global.ChannelID:[global.ChannelID]
if(!channelList.length||!channelList[0])return m.reply('⚠️ Belum ada ChannelID diatur di config.js')

let media=await vanzz.downloadAndSaveMediaMessage(q)
let success=0

for(const id of channelList){
try{
await vanzz.sendMessage(id,{
audio:{url:media},
ptt:true,
contextInfo:{
externalAdReply:{
title:'🎧 Voice Note',
body:'VanzRyuichi🔖',
thumbnailUrl:'https://files.catbox.moe/mcs4y9.jpg',
sourceUrl:'https://whatsapp.com/channel/0029VbBS8on9cDDVHaTqil0k',
mediaType:1,
renderLargerThumbnail:true
}
}
})
success++
console.log(`✅ VN dikirim ke: ${id}`)
await new Promise(r=>setTimeout(r,1500))
}catch(err){
console.error(`❌ Gagal kirim ke ${id}:`,err.message)
}
}

fs.unlinkSync(media)
await vanzreply(m,`✅ Voice Note berhasil dikirim ke ${success}/${channelList.length} Channel.`)
}catch(e){
console.error('UPCHVN ERROR:',e)
await vanzreply(m,'❌ Gagal mengirim Voice Note ke channel.')
}
}

handler.help = ['Up Chat Audio Ke Channel']
handler.tags = ['community']
handler.command = ['upchvn']
handler.owner = true

export default handler