let handler = async (m, { text, vanzz, qtext, conn }) => {
try {
if (!text.includes('|')) return m.reply('⚠️ Format salah!\nContoh: /createch Nama Channel|Deskripsi Channel')
let [namach, dekssch] = text.split('|').map(s => s.trim())
if (!namach || !dekssch) return m.reply('⚠️ Format salah!\nContoh: /createch Nama Channel|Deskripsi Channel')

let channel = await vanzz.newsletterCreate(namach, dekssch)
let channelID = channel.id?.split('@')[0]
await vanzz.sendMessage(channel.id, { text: `Halo semua! 🎉\nSaluran *${namach}* berhasil dibuat ✅` })
let info = `✅ *Berhasil Membuat Channel WhatsApp*\n\n📌 *Nama:* ${namach}\n📝 *Deskripsi:* ${dekssch}\n\nSilakan Buka Saluran Melalui Halaman Saluran.`
await vanzz.sendMessage(m.chat, { text: info }, { quoted: qtext })
} catch (err) {
console.error('CREATE CHANNEL ERROR:', err)
m.reply('❌ Gagal membuat saluran. Pastikan format benar atau coba lagi nanti.')
}
}

handler.help = ['Create Channel Whatsapp']
handler.tags = ['community']
handler.command = ['createch']
handler.owner = true

export default handler