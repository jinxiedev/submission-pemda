import fs from 'fs'
import axios from 'axios'
import { upload } from '../../source/events/uploader.js'
import "../../settings/config.js"

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
const newsletterList = Array.isArray(global.ChannelID) ? global.ChannelID : [global.ChannelID]
if(!newsletterList.length||!newsletterList[0])return m.reply('⚠️ *Belum ada ChannelID diatur di config.js!*')

if((!m.quoted||!/image/.test((m.quoted.msg||m.quoted).mimetype))&&!m.message.imageMessage)
return m.reply(`🧩 *Format Salah*\n\nKirim atau reply gambar dengan caption URL tujuan.\nContoh:\n${prefix+command} https://github.com/VanzzRyuichi`)

let input=text?.trim()
if(!input)return m.reply('❌ Harap isi URL tujuan!')
if(!/^https?:\/\//.test(input))return m.reply('❌ Harap masukkan URL yang valid!')

await vanzz.sendMessage(m.chat,{react:{text:'📤',key:m.key}})
let qmsg=m.quoted?m.quoted:m
let media=await vanzz.downloadAndSaveMediaMessage(qmsg)
const cdn=await upload({path:media})
if(fs.existsSync(media))fs.unlinkSync(media)
const imageUrl=cdn[0]?.url
if(!imageUrl)return m.reply('❌ Upload gambar gagal!')

const titleText='📰 *Informasi Update*\nKlik tombol di bawah untuk melanjutkan.'
const footerText=' 🔖 VanzRyuichi'
const interactiveMessage={
interactiveMessage:{
title:titleText,
footer:footerText,
image:{url:imageUrl},
buttons:[
{
name:'cta_url',
buttonParamsJson:JSON.stringify({
display_text:'📂 Open Code',
url:input
})
},
{
name:'cta_url',
buttonParamsJson:JSON.stringify({
display_text:'🪐 My Channel',
url:'https://whatsapp.com/channel/0029VbBS8on9cDDVHaTqil0k'
})
},
{
name:'cta_copy',
buttonParamsJson:JSON.stringify({
display_text:'🌐 Copy Link',
copy_code:input
})
}
]
}
}

let success=0
for(const id of newsletterList){
try{
await vanzz.sendMessage(id,interactiveMessage)
console.log(`✅ Dikirim ke: ${id}`)
success++
await new Promise(r=>setTimeout(r,1500))
}catch(err){
console.error(`❌ Gagal kirim ke ${id}:`,err.message)
}
}

await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
await m.reply(`✅ *Berhasil mengirim ke ${success}/${newsletterList.length} channel:*\n${newsletterList.join('\n')}`)
}catch(e){
console.error(e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
await m.reply(`❌ *Terjadi kesalahan:* ${e.message}`)
}
}

handler.help=['Up Chat Button Ke Channel']
handler.tags=['community']
handler.command=['upchbutton']
handler.owner=true

export default handler