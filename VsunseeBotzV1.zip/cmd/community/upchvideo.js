import fs from 'fs'
import '../../settings/config.js'
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzz, text }) => {
try {
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!/video/.test(mime)) return m.reply('⚠️ Balas atau kirim video dengan caption.')
let media = await vanzz.downloadAndSaveMediaMessage(q)
let caption = text || ''
await vanzz.sendMessage(global.ChannelID, {
video: { url: media },
caption: caption
})
fs.unlinkSync(media)
await vanzreply(m, '✅ Video berhasil dikirim ke Channel WhatsApp.')
} catch (e) {
console.error('UPCHVID ERROR:', e)
await vanzreply(m, '❌ Gagal mengirim video ke channel.')
}
}

handler.help = ['Up Chat Video Ke Channel']
handler.tags = ['community']
handler.command = ['upchvid']
handler.owner = true

export default handler