import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!text)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} id_freefire\n\n📍 Contoh:\n${prefix+command} 55555555`},{quoted:qtext})

await vanzz.sendMessage(m.chat,{react:{text:'🎯',key:m.key}})

const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/ff?apikey=${global.VsunseeApikey}&id=${encodeURIComponent(text)}`)
const r=res.data.result
if(!r||!r.nickname){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}

const caption=`🎮 *Free Fire Stalker*\n\n👤 *Nickname:* ${r.nickname}\n🌍 *Region:* ${r.region}\n🆔 *Open ID:* ${r.open_id}`

const msgData={
image:{url:r.img_url},
caption,
contextInfo:{
externalAdReply:{
title:'Free Fire Player Info',
body:'Data diambil dari Vsunsee API',
thumbnailUrl:r.img_url,
sourceUrl:'https://ff.garena.com/',
mediaType:1,
renderLargerThumbnail:true
}
}
}

if (typeof msgData.caption !== 'string') msgData.caption = String(msgData.caption || '')
if (typeof msgData.text !== 'string') msgData.text = String(msgData.text || '')

if(modesend==='xreply'||modesend==='button'){
  await vanzreply(m, msgData.caption || '')
} else {
  await vanzz.sendMessage(m.chat, msgData, {quoted:qtext})
}

await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('FF STALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Free Fire Stalk']
handler.tags=['stalk']
handler.command=['ffstalk']

export default handler