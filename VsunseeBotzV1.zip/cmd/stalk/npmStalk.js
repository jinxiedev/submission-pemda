import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m, { vanzz, text, prefix, command, qtext }) => {
try {
if (!text)
return vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nama_package_npm\n\n📍 Contoh:\n${prefix + command} axios` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '📦', key: m.key } })

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/npmst?apikey=${global.VsunseeApikey}&name=${encodeURIComponent(text)}`)
const r = res.data.result
if (!r || !r.name) {
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}

const caption = `📦 *NPM Package Info*\n\n📛 *Nama:* ${r.name}\n🆕 *Versi Terbaru:* ${r.versionLatest}\n📜 *Versi Awal:* ${r.versionPublish}\n📈 *Total Update:* ${r.versionUpdate}\n🧩 *Dependencies (Terbaru):* ${r.latestDependencies}\n🧩 *Dependencies (Awal):* ${r.publishDependencies}\n📅 *Waktu Publish Awal:* ${r.publishTime}\n🕒 *Update Terakhir:* ${r.latestPublishTime}`

const msgData = {
text: caption,
contextInfo: {
externalAdReply: {
title: `📦 NPM: ${r.name}`,
body: 'Data diambil dari Vsunsee API',
thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/5968/5968322.png',
sourceUrl: `https://www.npmjs.com/package/${r.name}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}

if (typeof msgData.caption !== 'string') msgData.caption = String(msgData.caption || '')
if (typeof msgData.text !== 'string') msgData.text = String(msgData.text || '')

if (modesend === 'xreply' || modesend === 'button') await vanzreply(m, msgData.text || '')
else await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('NPM STALK ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['NPM Package Stalk']
handler.tags = ['stalk']
handler.command = ['npmstalk']

export default handler