import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(typeof text!=='string')text=String(text||'').trim()
await vanzz.sendMessage(m.chat,{react:{text:'📌',key:m.key}})
if(!text)
return vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} username_pinterest\n\n📍 Contoh:\n${prefix+command} xkxndke`)
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/pinterestst?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const r=d.result
const stats=r.stats||{}
const caption=`📌 *Pinterest Profile*\n\n👤 Username: ${r.username}\n🆔 ID: ${r.id}\n💬 Full Name: ${r.full_name||'-'}\n🌐 Profile: ${r.profile_url}\n📍 Location: ${r.location||'Tidak tersedia'}\n\n📊 Stats:\n📌 Pins: ${stats.pins||0}\n👥 Followers: ${stats.followers||0}\n➡️ Following: ${stats.following||0}\n🗂️ Boards: ${stats.boards||0}\n❤️ Likes: ${stats.likes||0}\n💾 Saves: ${stats.saves||0}\n\n🔗 Verified: ${r.is_verified?'✅ Ya':'❌ Tidak'}\n👔 Partner: ${r.is_partner?'✅ Ya':'❌ Tidak'}`
if(r.image&&r.image.original){
await vanzz.sendMessage(m.chat,{image:{url:r.image.original},caption},{quoted:null})
}else{
await vanzreply(m,caption)
}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('PINTEREST STALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Pinterest Stalk']
handler.tags=['stalk']
handler.command=['pintereststalk']

export default handler