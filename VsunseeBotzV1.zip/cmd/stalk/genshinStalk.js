import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!text)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} uid_genshin\n\n📍 Contoh:\n${prefix+command} 856012067`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'🎮',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/genshin?apikey=${global.VsunseeApikey}&uid=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const r=d.result
const charList=r.characters?.length?r.characters.slice(0,6).map(c=>`• ${c.name} (Lv.${c.level}) ✨ Bond: ${c.fetterLevel}`).join('\n'):'Tidak ada karakter ditemukan'
const caption=`🎮 *GENSHIN IMPACT PROFILE*\n\n👤 *Username:* ${r.username||'-'}\n🆔 *UID:* ${text}\n🏅 *Adventure Level:* ${r.level}\n🌎 *World Level:* ${r.worldLevel}\n📜 *Signature:* ${r.signature||'Tidak ada'}\n🏆 *Achievements:* ${r.achievements}\n⚔️ *Abyss:* Floor ${r.abyss?.floor||'-'} • Level ${r.abyss?.level||'-'}\n\n🎭 *Karakter Tersedia:*\n${charList}`
const msgData={
image:{url:r.nameCard},
caption,
contextInfo:{
externalAdReply:{
title:`🎮 Genshin: ${r.username||'Unknown'}`,
body:'Data berhasil diambil dari Vsunsee API',
thumbnailUrl:r.nameCard,
sourceUrl:`https://enka.network/u/${text}/`,
mediaType:1,
renderLargerThumbnail:true
}
}
}
if(typeof msgData.caption!=='string')msgData.caption=String(msgData.caption||'')
if(typeof msgData.text!=='string')msgData.text=String(msgData.text||'')
if(modesend==='xreply'||modesend==='button')await vanzreply(m,msgData.caption||'')
else await vanzz.sendMessage(m.chat,msgData,{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('GENSHIN STALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Genshin Impact Stalk']
handler.tags=['stalk']
handler.command=['genshinstalk']

export default handler