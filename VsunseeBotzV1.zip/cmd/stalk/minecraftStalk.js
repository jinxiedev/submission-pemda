import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(typeof text!=='string')text=String(text||'').trim()
if(!text)
return vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} username\n\n📍 Contoh:\n${prefix+command} Steve`)
await vanzz.sendMessage(m.chat,{react:{text:'⛏️',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/minecraftst?apikey=${global.VsunseeApikey}&username=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const r=d.result
const caption=`🎮 *Minecraft Player Info*\n\n🧱 *Username:* ${r.username}\n🪪 *UUID:* ${r.formattedId}\n🎨 *Skin Model:* ${r.avatar.skinModel}\n🧤 *Cape:* ${r.textures.cape?'Ada':'Tidak Ada'}\n\n🌐 *Skin URL:*\n${r.avatar.skin}\n\n🧩 *Checked via:* Vsunsee API`
if(r.avatar&&r.avatar.skin){
await vanzz.sendMessage(m.chat,{image:{url:r.avatar.skin},caption},{quoted:null})
}else{
await vanzreply(m,caption)
}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('MINECRAFT STALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Minecraft Stalk']
handler.tags=['stalk']
handler.command=['minecraftstalk']

export default handler