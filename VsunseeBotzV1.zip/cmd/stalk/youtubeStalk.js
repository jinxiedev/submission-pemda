import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m, { vanzz, text, prefix, command, qtext }) => {
try {
await vanzz.sendMessage(m.chat, { react: { text: '📡', key: m.key } })
if (!text)
return vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} nama_channel_youtube\n\n📍 Contoh:\n${prefix + command} Raflie GM` }, { quoted: qtext })

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/youtubest?apikey=${global.VsunseeApikey}&username=${encodeURIComponent(text)}`)
const r = res.data.result
if (!r || !r.channelMetadata) {
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}

const c = r.channelMetadata
const caption = `📺 *YouTube Channel Info*

👤 *Username:* ${c.username || '-'}
📦 *Subscribers:* ${c.subscriberCount || '-'}
🎞️ *Total Videos:* ${c.videoCount || '-'}
🔗 *Channel URL:* ${c.channelUrl || '-'}
📰 *RSS Feed:* ${c.rssUrl || '-'}`

const msgData = {
image: { url: c.avatarUrl },
caption,
contextInfo: {
externalAdReply: {
title: c.username || 'YouTube Channel',
body: 'Data diambil dari Vsunsee API',
thumbnailUrl: c.avatarUrl,
sourceUrl: c.channelUrl,
mediaType: 1,
renderLargerThumbnail: true
}
}
}

if (typeof msgData.caption !== 'string') msgData.caption = String(msgData.caption || '')
if (typeof msgData.text !== 'string') msgData.text = String(msgData.text || '')

if (modesend === 'xreply' || modesend === 'button') await vanzreply(m, msgData.caption)
else await vanzz.sendMessage(m.chat, msgData, { quoted: qtext })

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('YOUTUBE STALK ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['YouTube Stalk']
handler.tags = ['stalk']
handler.command = ['ytstalk']

export default handler