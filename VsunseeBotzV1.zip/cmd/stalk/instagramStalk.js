import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📸',key:m.key}})
if(!text)
return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} username_instagram\n\n📍 Contoh:\n${prefix+command} google`},{quoted:qtext})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/instagram?apikey=${global.VsunseeApikey}&username=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const ig=d.result
const caption=`👤 *${ig.full_name}* (@${ig.username})
${ig.is_verified?'✅ Akun Terverifikasi':''}
${ig.is_private?'🔒 Akun Privat':'🌐 Akun Publik'}

📊 *Statistik:*
👥 Followers : ${ig.followers_count.toLocaleString()}
➡️ Following : ${ig.following_count.toLocaleString()}
🖼️ Posts     : ${ig.posts_count.toLocaleString()}

📝 *Bio:* 
${ig.biography||'-'}

🔗 *Links:*
${ig.external_url?`🌐 ${ig.external_url}`:''}
${ig.bio_links?.length?ig.bio_links.map(l=>`• [${l.title}](${l.url})`).join('\n'):''}`
const msgData={
image:{url:ig.profile_pic_url},
caption,
contextInfo:{
externalAdReply:{
title:`📸 Instagram: ${ig.username}`,
body:'Data berhasil diambil dari Vsunsee API',
thumbnailUrl:ig.profile_pic_url,
sourceUrl:`https://instagram.com/${ig.username}`,
mediaType:1,
renderLargerThumbnail:true
}
}
}
if(typeof msgData.caption!=='string')msgData.caption=String(msgData.caption||'')
if(typeof msgData.text!=='string')msgData.text=String(msgData.text||'')
if(modesend==='xreply'||modesend==='button')await vanzreply(m,msgData.caption||'')
else await vanzz.sendMessage(m.chat,msgData,{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('IGSTALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Instagram Stalk']
handler.tags=['stalk']
handler.command=['igstalk']

export default handler