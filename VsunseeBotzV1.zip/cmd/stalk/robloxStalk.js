import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🎮',key:m.key}})
if(!text)
return vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} username_roblox\n\n📍 Contoh:\n${prefix+command} tisyxnom`)

const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/roblox?apikey=${global.VsunseeApikey}&username=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}

const r=d.result
const badge=r.badges?.length?`🏅 *Badge:* ${r.badges.map(b=>b.name).join(', ')}`:'❌ Tidak ada badge'

let caption=`🎮 *ROBLOX PLAYER INFO*

👤 *${r.displayName}* (@${r.username})
🆔 ID: ${r.id}
📅 Dibuat: ${new Date(r.created).toLocaleDateString('id-ID')}
🔰 Status: ${r.isBanned?'Banned 🚫':'Aktif ✅'} ${r.hasVerifiedBadge?'💎 Terverifikasi':''}
📊 *Statistik:*
👥 Teman: ${r.friendsCount}
👣 Followers: ${r.followersCount}
➡️ Following: ${r.followingCount}
🕹️ Status: ${r.presence.status} (${r.presence.lastLocation})

${badge}`

if (r.friendsList && r.friendsList.length > 0) {
    const maxFriends = 20;
    const friendsToShow = r.friendsList.slice(0, maxFriends);
    const remainingFriends = r.friendsList.length - friendsToShow.length;
    
    caption += `\n\n👥 *FRIENDS LIST (${r.friendsCount})*\n`;

    friendsToShow.forEach((friend, index) => {
        caption += `\n${index + 1}. *${friend.displayName}* (@${friend.username})`;
    });

    if (remainingFriends > 0) {
        caption += `\n\n_...dan ${remainingFriends} teman lainnya..._`;
    }
} else if (r.friendsCount > 0) {
    caption += `\n\n👥 *FRIENDS LIST*\n\n_API tidak mengembalikan detail daftar teman, tetapi jumlah teman adalah ${r.friendsCount}._`;
} else {
    caption += `\n\n👥 *FRIENDS LIST*\n\n_Pengguna ini tidak memiliki teman._`;
}

await vanzz.sendMessage(m.chat,{image:{url:r.avatar},caption},{quoted:null})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('ROBLOX STALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Roblox Stalk']
handler.tags=['stalk']
handler.command=['roblox','crx']

export default handler
