import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(typeof text!=='string')text=String(text||'').trim()
if(!text)
return vanzreply(m,`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} username_github\n\n📍 Contoh:\n${prefix+command} Vanxzofc`)
await vanzz.sendMessage(m.chat,{react:{text:'💻',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/githubst?apikey=${global.VsunseeApikey}&username=${encodeURIComponent(text)}`)
const r=res.data.result
if(!r||!r.login){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const caption=`🐙 *GitHub Stalker*\n\n👤 *Username:* ${r.login}\n📛 *Nama:* ${r.name||'-'}\n📖 *Bio:* ${r.bio||'-'}\n🏢 *Company:* ${r.company||'-'}\n📍 *Lokasi:* ${r.location||'-'}\n🌐 *Blog:* ${r.blog||'-'}\n📦 *Repos Publik:* ${r.public_repos}\n🧾 *Gists:* ${r.public_gists}\n👥 *Followers:* ${r.followers}\n🫱 *Following:* ${r.following}\n📅 *Dibuat:* ${r.created_at}\n🕒 *Update Terakhir:* ${r.updated_at}\n🔗 *Profil:* ${r.profile_url}`
if(r.avatar_url){
await vanzz.sendMessage(m.chat,{image:{url:r.avatar_url},caption},{quoted:null})
}else{
await vanzreply(m,caption)
}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('GITHUB STALK ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['GitHub Stalk']
handler.tags=['stalk']
handler.command=['githubstalk']

export default handler