import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

function getRandom(length) {
  return Math.floor(Math.random() * Math.pow(10, length))
}

let handler = async (m, { vanzz, text, prefix }) => {
try {
if (!text)
  return vanzreply(
    m,
    `⚠️ Format salah!\nGunakan: *${prefix}installpanel ipvps|pwvps|panel.com|node.com|ramserver*\n\nContoh:\n*${prefix}installpanel 1.1.1.1|rootpass|panel.com|node.com|100000*`
  )

let vii = text.split("|")
if (vii.length < 5)
  return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}installpanel ipvps|pwvps|panel.com|node.com|ramserver*`)

const ress = new Client()
const connSettings = {
  host: vii[0].trim(),
  port: "22",
  username: "root",
  password: vii[1].trim(),
}

const randomValue1 = getRandom(1)
const randomValue2 = getRandom(1)
const user = "admin" + randomValue1
const pass = "vanz" + randomValue2
const domainpanel = vii[2].trim()
const domainnode = vii[3].trim()
const ramserver = vii[4].trim()
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
try {
ress.exec(commandPanel, (err, stream) => {
if (err) {
console.error("❌ Gagal menjalankan commandPanel:", err)
return vanzreply(m, `❌ Gagal menjalankan commandPanel.\n\n📌 *Detail:*\n${err.message}`)
}

stream.on("close", async () => {
try {
ress.exec("bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)", async (err, stream) => {
if (err) {
console.error("❌ Gagal menjalankan createnode.sh:", err)
return vanzreply(m, `❌ Gagal menjalankan createnode.sh.\n\n📌 *Detail:*\n${err.message}`)
}

stream.on("close", async () => {
let teks = `*📦 Berikut Detail Akun Admin Panel:*\n\n*Username:* ${user}\n*Password:* ${pass}\n*Domain:* ${domainpanel}\n\n*Note:* Bot akan otomatis membuat allocation & token Wings 🔄\n\n*Cara Menjalankan Wings:*\nKetik *${prefix}startwings* ipvps|pwvps|tokenwings`
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })

await vanzz.sendMessage(m.chat, { text: "⚙️ Membuat allocation & token wings otomatis..." })
ress.exec(
  `bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/main/alocation.sh)`,
  (err, stream) => {
    if (err) {
      console.error("❌ Gagal menjalankan createallocation.sh:", err)
      return vanzreply(m, `❌ Gagal auto-create allocation.\n\n📌 *Detail:*\n${err.message}`)
    }
    stream.on("data", (data) => console.log("ALLOCATION:", data.toString()))
    stream.on("close", async () => {
      await vanzreply(m, "✅ Allocation & Token Wings berhasil dibuat otomatis!")
    })
  }
)
})

stream.on("data", async (data) => {
console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) stream.write("SGP\n")
if (data.toString().includes("Masukkan deskripsi lokasi: ")) stream.write("SUPPORT VANZ\n")
if (data.toString().includes("Masukkan domain: ")) stream.write(`${domainnode}\n`)
if (data.toString().includes("Masukkan nama node: ")) stream.write("NODE BY VANZ\n")
if (data.toString().includes("Masukkan RAM (dalam MB): ")) stream.write(`${ramserver}\n`)
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) stream.write(`${ramserver}\n`)
if (data.toString().includes("Masukkan Locid: ")) stream.write("1\n")
})
stream.stderr.on("data", async (data) => console.error("STDERR:", data.toString()))
})
} catch (error) {
console.error("❌ Gagal menjalankan instalWings:", error)
vanzreply(m, `❌ Gagal menjalankan instalWings.\n\n📌 *Detail:*\n${error.message}`)
}
})

stream.on("data", async (data) => {
console.log("Logger:", data.toString())
if (data.toString().includes("Input 0-6")) stream.write("1\n")
if (data.toString().includes("(y/N)")) stream.write("y\n")
if (data.toString().includes("Enter the panel address")) stream.write(`${domainpanel}\n`)
if (data.toString().includes("Database host username")) stream.write(`${user}\n`)
if (data.toString().includes("Database host password")) stream.write(`${pass}\n`)
if (data.toString().includes("Set the FQDN to use for Let's Encrypt")) stream.write(`${domainnode}\n`)
if (data.toString().includes("Enter email address for Let's Encrypt")) stream.write("vanz@gmail.com\n")
})

stream.stderr.on("data", (data) => console.error("STDERR:", data.toString()))
})
} catch (error) {
console.error("❌ Gagal menginstall Wings:", error)
vanzreply(m, `❌ Gagal menginstall Wings.\n\n📌 *Detail:*\n${error.message}`)
}
}

async function instalPanel() {
try {
ress.exec(commandPanel, (err, stream) => {
if (err) {
console.error("❌ Gagal menjalankan commandPanel:", err)
return vanzreply(m, `❌ Gagal menjalankan commandPanel.\n\n📌 *Detail:*\n${err.message}`)
}

stream.on("close", async () => {
try { await instalWings() } catch (error) {
console.error("❌ Gagal menjalankan instalWings:", error)
vanzreply(m, `❌ Gagal menjalankan instalWings.\n\n📌 *Detail:*\n${error.message}`)
}
})

stream.on("data", async (data) => {
console.log("Logger:", data.toString())
if (data.toString().includes("Input 0-6")) stream.write("0\n")
if (data.toString().includes("(y/N)")) stream.write("y\n")
if (data.toString().includes("Database name")) stream.write(`${user}\n`)
if (data.toString().includes("Database username")) stream.write(`${user}\n`)
if (data.toString().includes("Password (press enter")) stream.write(`${pass}\n`)
if (data.toString().includes("Select timezone")) stream.write("Asia/Jakarta\n")
if (data.toString().includes("Provide the email")) stream.write("vanz@gmail.com\n")
if (data.toString().includes("Email address for the initial admin")) stream.write("vanz@gmail.com\n")
if (data.toString().includes("Username for the initial admin")) stream.write(`${user}\n`)
if (data.toString().includes("First name for the initial admin")) stream.write("vanz\n")
if (data.toString().includes("Last name for the initial admin")) stream.write("ryuichi\n")
if (data.toString().includes("Password for the initial admin")) stream.write(`${pass}\n`)
if (data.toString().includes("Set the FQDN of this panel")) stream.write(`${domainpanel}\n`)
if (data.toString().includes("Do you want to automatically configure UFW")) stream.write("y\n")
if (data.toString().includes("Do you want to automatically configure HTTPS")) stream.write("y\n")
if (data.toString().includes("Select the appropriate number")) stream.write("1\n")
if (data.toString().includes("I agree that this HTTPS")) stream.write("y\n")
if (data.toString().includes("Proceed anyways")) stream.write("y\n")
if (data.toString().includes("(yes/no)")) stream.write("yes\n")
if (data.toString().includes("Initial configuration completed")) stream.write("y\n")
if (data.toString().includes("Still assume SSL")) stream.write("y\n")
if (data.toString().includes("Please read the Terms")) stream.write("y\n")
if (data.toString().includes("(A)gree/(C)ancel:")) stream.write("A\n")
})

stream.stderr.on("data", (data) => console.error("STDERR:", data.toString()))
})
} catch (error) {
console.error("❌ Gagal menginstall panel:", error)
vanzreply(m, `❌ Gagal menginstall panel.\n\n📌 *Detail:*\n${error.message}`)
}
}

ress.on("ready", async () => {
try {
await vanzreply(m, "⚙️ Memproses *install panel...* \nTunggu ±5 menit hingga proses selesai.")
ress.exec(deletemysql, async (err, stream) => {
if (err) {
console.error("❌ Error saat menjalankan deletemysql:", err)
return vanzreply(m, `❌ Gagal menjalankan perintah deletemysql.\n\n📌 *Detail:*\n${err.message}`)
}

stream.on("close", async () => {
try { await instalPanel() } catch (error) {
console.error("❌ Gagal menjalankan instalPanel:", error)
vanzreply(m, `❌ Gagal menjalankan instalPanel.\n\n📌 *Detail:*\n${error.message}`)
}
})
})
} catch (error) {
console.error("❌ Terjadi kesalahan saat memproses install panel:", error)
vanzreply(m, `❌ Terjadi kesalahan saat memproses install panel.\n\n📌 *Detail:*\n${error.message}`)
}
})

try { ress.connect(connSettings) } catch (error) {
console.error("❌ Gagal menghubungkan ke server:", error)
vanzreply(m, `❌ Gagal menghubungkan ke server.\n\n📌 *Detail:*\n${error.message}`)
}
} catch (e) {
console.error("ERROR:", e)
await vanzreply(m, `❌ Terjadi kesalahan tidak terduga.\n\n📌 ${e.message}`)
}
}

handler.help = ["Install Panel Pterodactyl"]
handler.tags = ["installer"]
handler.command = ["installpanel"]
handler.owner = true

export default handler