import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try{
if(!text) return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps|username|password*`)
let parts = text.split("|")
if(parts.length < 4) return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps|username|password*`)
const [ipvps, pwvps, username, password] = parts.map(p => p.trim())
const connSettings = { host: ipvps, port: '22', username: 'root', password: pwvps }
const rawCmd = `bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`
const conn = new Client()
await vanzz.sendMessage(m.chat, { react: { text: '⚙️', key: m.key } })
await vanzreply(m, '🔧 Menjalankan hackback... tunggu sebentar')
let out = ''
let errOut = ''
let finished = false
let sentCredentials = false
conn.on('ready', () => {
conn.exec(rawCmd, (err, stream) => {
if(err){ vanzreply(m, `❌ Gagal eksekusi: ${err.message}`); conn.end(); return }
stream.on('close', async () => {
finished = true
let summary = out || '(no output)'
let stderrSummary = errOut || '(no stderr)'
await vanzreply(m, `✅ Proses selesai\n\n📤 Output singkat:\n${summary}\n\n🛠 STDERR:\n${stderrSummary}\n\n🔐 Akun yang dibuat:\nUser: ${username}\nPass: ${password}`)
await vanzz.sendMessage(m.chat, { text: `User: ${username}\nPass: ${password}` }, { quoted: qtext })
conn.end()
})
.on('data', (data) => {
let s = data.toString()
out += s
if(/BERIKUT ADALAH LIST FITUR|PILIH THEME|Masukkan pilihan/i.test(s)){
try{ stream.write('7\n') }catch(e){}
}
if(/Masukkan Username Panel:|Masukkan username panel:|Masukkan Username Panel/i.test(s) && !sentCredentials){
try{ stream.write(username + '\n') }catch(e){}
}
if(/password login:|Masukkan password|Masukkan Password|Masukkan pw/i.test(s) && !sentCredentials){
try{ stream.write(password + '\n'); sentCredentials = true }catch(e){}
}
if(/AKUN TELAH DI ADD|AKSES BERHASIL|INSTALL SUCCESS/i.test(s)){
}
})
.stderr.on('data', (data) => { errOut += data.toString() })
})
})
.on('error', async (e) => { console.error(e); await vanzreply(m, `❌ Koneksi gagal: ${e.message}`) })
.connect(connSettings)
}catch(e){ console.error(e); await vanzreply(m, `❌ Error: ${e.message}`) }
}

handler.help = ['Hack Back Panel']
handler.tags = ['installer']
handler.command = ['hackback']
handler.owner = true

export default handler