import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try{
if(!text) return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps|pwbaru* atau *${prefix}${command} ipvps|pwvps*`)
let parts = text.split("|").map(p=>p.trim())
if(parts.length < 2) return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps|pwbaru* atau *${prefix}${command} ipvps|pwvps*`)
const [ipvps, pwvps] = parts
let newpw = parts.length >= 3 && parts[2] ? parts[2] : `vanz${Math.floor(1000 + Math.random() * 9000)}`
const connSettings = { host: ipvps, port: '22', username: 'root', password: pwvps }
const rawCmd = `bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`
const conn = new Client()
await vanzz.sendMessage(m.chat,{react:{text:'⚙️',key:m.key}})
await vanzreply(m,'🔧 Menjalankan ubah password VPS... tunggu sebentar')
let out = ''
let errOut = ''
let sent = 0
conn.on('ready',()=>{
conn.exec(rawCmd,(err,stream)=>{
if(err){vanzreply(m,`❌ Gagal eksekusi: ${err.message}`);conn.end();return}
stream.on('close',async()=>{
let summary = out || '(no output)'
let stderrSummary = errOut || '(no stderr)'
await vanzreply(m,`✅ Proses selesai\n\n📤 Output singkat:\n${summary}\n\n🛠 STDERR:\n${stderrSummary}\n\n🔐 Password baru: ${newpw}`)
await vanzz.sendMessage(m.chat,{text:`Password baru VPS: ${newpw}`},{quoted:qtext})
conn.end()
})
.on('data',(data)=>{
let s=data.toString()
out+=s
if(/BERIKUT ADALAH LIST FITUR|Masukkan pilihan/i.test(s)){
try{stream.write('8\n')}catch(e){}
}
if(/Masukkan Pw Baru|Masukkan Pw Baru:/i.test(s)&&sent===0){
try{stream.write(newpw+'\n');sent=1}catch(e){}
}
if(/Masukkan Ulang Pw Baru|Masukkan Ulang Pw Baru:/i.test(s)&&sent===1){
try{stream.write(newpw+'\n');sent=2}catch(e){}
}
})
.stderr.on('data',(data)=>{errOut+=data.toString()})
})
})
.on('error',async(e)=>{console.error(e);await vanzreply(m,`❌ Koneksi gagal: ${e.message}`)})
.connect(connSettings)
}catch(e){console.error(e);await vanzreply(m,`❌ Error: ${e.message}`)}
}

handler.help=['Ubah Password Vps']
handler.tags=['installer']
handler.command=['ubahpwvps']
handler.owner=true

export default handler