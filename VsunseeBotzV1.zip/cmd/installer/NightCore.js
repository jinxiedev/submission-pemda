import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try{
if(!text || !text.includes("|")) return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const [ipvps, passwd] = text.split("|").map(a=>a.trim())
if(!ipvps || !passwd) return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const connSettings = { host: ipvps, port: '22', username: 'root', password: passwd }
const rawCmd = `bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`
const conn = new Client()
await vanzz.sendMessage(m.chat,{react:{text:'⚙️',key:m.key}})
await vanzreply(m,'🔧 Memproses install *TEMA NIGHT CORE* pterodactyl...\n⏳ Tunggu ±3 menit hingga proses selesai...')
let out=''
let errOut=''
conn.on('ready',()=>{
conn.exec(rawCmd,(err,stream)=>{
if(err){vanzreply(m,`❌ Gagal eksekusi: ${err.message}`);conn.end();return}
stream.on('close',async()=>{
await vanzreply(m,'✅ Berhasil install *TEMA NIGHT CORE* pterodactyl')
await vanzz.sendMessage(m.chat,{text:`🎨 Tema: NIGHT CORE\n📦 Status: Berhasil terpasang ✅`},{quoted:qtext})
conn.end()
})
.on('data',(data)=>{
console.log(data.toString())
try{
stream.write(`1\n`)
stream.write(`y\n`)
}catch(e){}
})
.stderr.on('data',(data)=>{
console.log('STDERR: '+data)
errOut+=data.toString()
})
})
})
.on('error',async(e)=>{
console.log('Connection Error: '+e)
await vanzreply(m,'❌ Katasandi atau IP tidak valid.')
})
.connect(connSettings)
}catch(e){
console.error(e)
await vanzreply(m,`❌ Error: ${e.message}`)
}
}

handler.help=['Install tema NightCore']
handler.tags=['installer']
handler.command=['installtemanightcore']
handler.owner=true

export default handler