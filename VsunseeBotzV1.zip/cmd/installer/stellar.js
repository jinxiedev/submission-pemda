import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try{
if(!text || !text.includes("|")) return vanzreply(m,`⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const [ipvps, pwvps] = text.split("|").map(a=>a.trim())
if(!ipvps || !pwvps) return vanzreply(m,`⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const connSettings={host:ipvps,port:'22',username:'root',password:pwvps}
const conn=new Client()
await vanzz.sendMessage(m.chat,{react:{text:'⚙️',key:m.key}})
await vanzreply(m,'🔧 Memproses install *Tema Stellar* pterodactyl...\n⏳ Tunggu beberapa menit hingga proses selesai...')
let out=''
let errOut=''
conn.on('ready',()=>{
const mainCmd=`bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/main/installStellar.sh) || (
echo "[Fallback] Metode utama gagal, menjalankan alternatif..." &&
curl -sL https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/main/installStellar.sh -o installStellar.sh &&
dos2unix installStellar.sh &&
bash installStellar.sh
)`
conn.exec(mainCmd,(err,stream)=>{
if(err){vanzreply(m,`❌ Gagal eksekusi: ${err.message}`);conn.end();return}
stream.on('close',async()=>{
await vanzreply(m,'✅ Berhasil install *Tema Stellar* pterodactyl 🎨')
await vanzz.sendMessage(m.chat,{text:`🎨 Tema: STELLAR\n📦 Status: Berhasil terpasang ✅`},{quoted:qtext})
conn.end()
})
.on('data',(data)=>{
const s=data.toString()
out+=s
console.log(s)
if(/Apakah Anda yakin ingin menginstall/i.test(s)){
try{stream.write('y\n')}catch(e){}
}
})
.stderr.on('data',(data)=>{
errOut+=data.toString()
console.log('STDERR:',data.toString())
})
})
})
.on('error',async(e)=>{
console.error(e)
await vanzreply(m,`❌ Koneksi gagal: ${e.message}`)
})
.connect(connSettings)
}catch(e){
console.error(e)
await vanzreply(m,`❌ Error: ${e.message}`)
}
}

handler.help=['Install Tema Stellar']
handler.tags=['installer']
handler.command=['installtemastellar']
handler.owner=true

export default handler