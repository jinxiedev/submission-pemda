import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try{
if(!text || !text.includes("|")) return vanzreply(m,`⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const [ipvps, passwd] = text.split("|").map(a=>a.trim())
if(!ipvps || !passwd) return vanzreply(m,`⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const connSettings={host:ipvps,port:'22',username:'root',password:passwd}
const conn=new Client()
await vanzz.sendMessage(m.chat,{react:{text:'⚙️',key:m.key}})
await vanzreply(m,'🔧 Menginstall *Depend* dan *Tema Nebula* pterodactyl...\n⏳ Tunggu beberapa menit hingga proses selesai...')
let out='',errOut=''

conn.on('ready',()=>{
// STEP 1: install depend
const dependCmd=`bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
conn.exec(dependCmd,(err,stream)=>{
if(err){vanzreply(m,`❌ Gagal eksekusi depend: ${err.message}`);conn.end();return}
stream.on('close',()=>{
vanzreply(m,'✅ Depend selesai diinstall. Lanjut install tema Nebula...')
setTimeout(()=>{
// STEP 2: install theme nebula
const themeCmd=`bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`
conn.exec(themeCmd,(err2,stream2)=>{
if(err2){vanzreply(m,`❌ Gagal eksekusi tema: ${err2.message}`);conn.end();return}
stream2.on('close',async()=>{
await vanzreply(m,'✅ Berhasil install *Tema Nebula* pterodactyl 🎨')
await vanzz.sendMessage(m.chat,{text:`🎨 Tema: NEBULA\n📦 Status: Berhasil terpasang ✅`},{quoted:qtext})
conn.end()
})
.on('data',(data)=>{
console.log(data.toString())
try{
stream2.write(`10\n`)
stream2.write(`\n`)
stream2.write(`\n`)
stream2.write(`x\n`)
}catch(e){}
})
.stderr.on('data',(data)=>{
console.log('STDERR (theme): '+data)
errOut+=data.toString()
})
})
},4000) // delay sedikit biar stabil antar eksekusi
})
.on('data',(data)=>{
console.log(data.toString())
try{
stream.write(`11\n`)
stream.write(`A\n`)
stream.write(`Y\n`)
stream.write(`Y\n`)
}catch(e){}
})
.stderr.on('data',(data)=>{
console.log('STDERR (depend): '+data)
errOut+=data.toString()
})
})
})
.on('error',async(e)=>{
console.log('Connection Error: '+e)
await vanzreply(m,'❌ Katasandi atau IP tidak valid.')
})
.connect(connSettings)
}catch(e){
console.error(e)
await vanzreply(m,`❌ Error: ${e.message}`)
}
}

handler.help=['Install Tema Nebula']
handler.tags=['installer']
handler.command=['installtemanebula']
handler.owner=true

export default handler