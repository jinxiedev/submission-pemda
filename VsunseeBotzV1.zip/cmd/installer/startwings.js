import { Client } from "ssh2"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try {
if (!text)
return vanzreply(
m,
`⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps|token_node*\n\nContoh:\n*${prefix}${command} 1.1.1.1|rootpass|cd /etc/pterodactyl && sudo wings configure --panel-url https://panel.domain.com --token ptla_xxxxx --node 1*`
)

const t = text.split("|")
if (t.length < 3)
return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps|token_node*`)

const ipvps = t[0].trim()
const passwd = t[1].trim()
const token = t[2].trim()

const connSettings = {
host: ipvps,
port: "22",
username: "root",
password: passwd
}

const ress = new Client()

await vanzz.sendMessage(m.chat, { react: { text: "⚙️", key: m.key } })
await vanzreply(m, "🚀 Menjalankan konfigurasi & start Wings...")

ress.on("ready", async () => {
const execCmd = `
if [ -f /usr/local/bin/wings ]; then
  ${token} && systemctl enable wings && systemctl start wings
  sleep 3
  systemctl status wings | grep Active || echo "Gagal membaca status Wings"
else
  echo "Wings belum diinstal di server ini!"
fi
`

ress.exec(execCmd, (err, stream) => {
if (err) throw err
let output = ""

stream
.on("data", (data) => (output += data.toString()))
.on("close", async () => {
if (output.includes("Wings belum diinstal")) {
await vanzreply(m, "❌ Wings belum terinstal di server ini.")
} else if (output.includes("active (running)")) {
await vanzreply(m, "🟢 *Wings berhasil dijalankan & aktif!* ✅")
} else if (output.includes("inactive") || output.includes("dead")) {
await vanzreply(m, "🔴 *Wings sudah dijalankan tapi tidak aktif.*\nCoba restart manual: `systemctl restart wings`")
} else {
await vanzreply(m, "⚠️ Wings dijalankan tapi status tidak terbaca.\nJalankan manual: `systemctl status wings`")
}
await vanzz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
ress.end()
})
.stderr.on("data", (data) => console.error("STDERR:", data.toString()))
})
})

ress.on("error", async (err) => {
console.error("Connection Error:", err)
await vanzreply(m, "❌ Gagal terhubung ke VPS.\nPastikan IP dan password root benar!")
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
})

ress.connect(connSettings)
} catch (e) {
console.error("WINGS HANDLER ERROR:", e)
await vanzreply(m, `❌ Terjadi kesalahan saat menjalankan Wings.\n\n📌 ${e.message}`)
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
}
}

handler.help = ["Start Wings Node"]
handler.tags = ["installer"]
handler.command = ["startwings"]
handler.owner = true

export default handler