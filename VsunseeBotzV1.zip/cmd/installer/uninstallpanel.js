import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try {
if (!text)
  return vanzreply(
    m,
    `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*\n\nContoh:\n*${prefix}${command} 1.1.1.1|rootpass*`
  )

const [ipvps, passwd] = text.split("|").map(v => v.trim())
if (!ipvps || !passwd)
  return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)

const connSettings = {
  host: ipvps,
  port: "22",
  username: "root",
  password: passwd
}

const ress = new Client()

await vanzz.sendMessage(m.chat, { react: { text: "🧹", key: m.key } })
await vanzreply(m, "⚙️ Memulai proses *Uninstall Panel Pterodactyl...*\nHarap tunggu sekitar 1–2 menit.")

const fullCleanCommand = `
if (( $EUID != 0 )); then
  echo "❌ Silahkan masuk sebagai root!"
  exit 1
fi

echo "🧹 Menghapus layanan dan direktori Pterodactyl..."

# Stop dan disable semua service
systemctl stop wings 2>/dev/null
systemctl disable wings 2>/dev/null
systemctl stop nginx 2>/dev/null
systemctl stop mariadb 2>/dev/null
systemctl stop redis-server 2>/dev/null

# Hapus file & folder Pterodactyl
rm -rf /var/www/pterodactyl
rm -rf /etc/pterodactyl
rm -rf /var/lib/pterodactyl
rm -rf /etc/systemd/system/wings.service
rm -rf /etc/nginx/sites-enabled/pterodactyl.conf
rm -rf /etc/nginx/sites-available/pterodactyl.conf
rm -rf /usr/local/bin/composer
rm -rf /usr/local/bin/wings

# Hapus database dan user MySQL terkait pterodactyl
mysql -u root -e "DROP DATABASE IF EXISTS panel;"
mysql -u root -e "DROP USER IF EXISTS 'pterodactyl'@'localhost'; FLUSH PRIVILEGES;"

# Hapus cache dan log
rm -rf /root/.cache
rm -rf /root/.composer
rm -rf /root/.npm
rm -rf /tmp/*

# Bersihkan firewall rules
ufw disable >/dev/null 2>&1
iptables -F
iptables -X

# Reload daemon
systemctl daemon-reload
systemctl reset-failed

echo "✅ Semua file dan service Pterodactyl telah dihapus total!"
`

ress.on("ready", async () => {
  ress.exec(fullCleanCommand, (err, stream) => {
    if (err) {
      console.error("❌ Gagal menjalankan command uninstall:", err)
      return vanzreply(m, `❌ Gagal menjalankan uninstall panel.\n\n📌 *Detail:*\n${err.message}`)
    }

    stream
      .on("close", async () => {
        await vanzreply(m, "✅ *Panel & Wings berhasil dihapus sepenuhnya dari VPS!*\nServer kini bersih 🧼")
        await vanzz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
        ress.end()
      })
      .on("data", (data) => console.log("UNINSTALL:", data.toString()))
      .stderr.on("data", (data) => console.error("STDERR:", data.toString()))
  })
})

ress.on("error", async (err) => {
  console.error("Connection Error:", err)
  await vanzreply(m, "❌ Gagal terhubung ke VPS.\nPastikan IP dan password root benar!")
  await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
})

ress.connect(connSettings)
} catch (e) {
console.error("UNINSTALL PANEL ERROR:", e)
await vanzreply(m, `❌ Terjadi kesalahan saat uninstall panel.\n\n📌 ${e.message}`)
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
}
}

handler.help = ["Uninstall Panel Pterodactyl"]
handler.tags = ["installer"]
handler.command = ["uninstallpanel"]
handler.owner = true

export default handler