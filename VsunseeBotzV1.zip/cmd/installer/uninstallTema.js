import { Client } from "ssh2"
import { qtext } from "../../source/quoted.js"
import { vanzreply } from "../../source/vanzreply.js"

let handler = async (m, { vanzz, text, prefix, command }) => {
try {
if (!text)
return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*\n\nContoh:\n*${prefix}${command} 1.1.1.1|rootpass*`)
const [ipvps, pwvps] = text.split("|").map(v => v.trim())
if (!ipvps || !pwvps)
return vanzreply(m, `⚠️ Format salah!\nGunakan: *${prefix}${command} ipvps|pwvps*`)
const connSettings = {
host: ipvps.trim(),
port: "22",
username: "root",
password: pwvps.trim()
}
const commandExec = `bash <(curl -s https://raw.githubusercontent.com/VannDC/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`
const ress = new Client()
await vanzz.sendMessage(m.chat, { react: { text: "🎨", key: m.key } })
await vanzreply(m, "🎨 Memproses *uninstall tema Pterodactyl...*\nTunggu ±3 menit hingga selesai.")
ress.on("ready", () => {
ress.exec(commandExec, (err, stream) => {
if (err) {
console.error("❌ Kesalahan saat menjalankan perintah:", err)
return vanzreply(m, "❌ Terjadi kesalahan saat mengeksekusi perintah uninstall.")
}
stream
.on("close", async () => {
await vanzreply(m, "✅ *Berhasil uninstall tema Pterodactyl!*")
await vanzz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
ress.end()
})
.on("data", (data) => {
console.log("UNINSTALL THEME:", data.toString())
stream.write("2\n")
stream.write("y\n")
stream.write("x\n")
})
.stderr.on("data", (data) => {
console.error("❌ STDERR:", data.toString())
})
})
})
ress.on("error", async (err) => {
console.error("❌ Kesalahan Koneksi:", err)
await vanzreply(m, "❌ Gagal terhubung ke VPS. Pastikan IP & password root benar!")
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
})
ress.connect(connSettings)
} catch (e) {
console.error("❌ Terjadi Kesalahan:", e)
await vanzreply(m, "❌ Terjadi kesalahan yang tidak terduga.")
await vanzz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
}
}

handler.help = ["Uninstall Tema Pterodactyl"]
handler.tags = ["installer"]
handler.command = ["uninstalltema"]
handler.owner = true

export default handler