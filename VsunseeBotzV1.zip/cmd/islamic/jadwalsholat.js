import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'
const modesend = global.modesend

let handler = async (m,{vanzz,text,prefix,command,qtext})=>{
try{
if(!text)
return vanzz.sendMessage(m.chat,{text:`🕌 *Contoh:* ${prefix+command} Kota Metro`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'🕒',key:m.key}})

const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/jadwalsholat?apikey=${global.VsunseeApikey}&kota=${encodeURIComponent(text)}`)
const data=res.data
if(!data.status)return m.reply('❌ Gagal mengambil jadwal sholat, pastikan nama kota benar.')

let teks=`🕌 *Jadwal Sholat Wilayah ${data.kota}*\n📅 ${data.tanggal}\n\n`
teks+=`🌙 *Imsyak:* ${data.imsyak}\n`
teks+=`🕓 *Subuh:* ${data.subuh}\n`
teks+=`🌅 *Terbit:* ${data.terbit}\n`
teks+=`☀️ *Dhuha:* ${data.dhuha}\n`
teks+=`🏙️ *Dzuhur:* ${data.dzuhur}\n`
teks+=`🌇 *Ashar:* ${data.ashar}\n`
teks+=`🌆 *Maghrib:* ${data.maghrib}\n`
teks+=`🌃 *Isya:* ${data.isya}\n\n`
teks+=`━━━━━━━━━━━━━━━━━━━\n📢 *Sumber:* API Vsunsee\n🔗 *https://${global.VsunseeApi}*`

const msgData={
text:teks.trim(),
contextInfo:{
externalAdReply:{
title:`🕌 Jadwal Sholat ${data.kota}`,
body:`${data.tanggal}`,
thumbnailUrl:'https://files.catbox.moe/bsrbf2.jpeg',
sourceUrl:`https://${global.VsunseeApi}`,
mediaType:1,
renderLargerThumbnail:true
}
}
}

if(modesend==='xreply'||modesend==='button')await vanzreply(m,msgData.text)
else await vanzz.sendMessage(m.chat,msgData,{quoted:qtext})

await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('JADWALSHOLAT ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Jadwal Sholat']
handler.tags=['islamic']
handler.command=['jadwalsholat']

export default handler