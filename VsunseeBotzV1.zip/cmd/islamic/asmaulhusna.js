import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📿',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/islamic/asmaulhusna?apikey=${global.VsunseeApikey}`)
const data=res.data
if(!data.status)return m.reply('❌ Gagal mengambil data Asmaul Husna.')
let teks=`📿 *99 Asmaul Husna*\n\n`
for(const i of data.result)teks+=`*${i.number}. ${i.latin}* (${i.arab})\n_${i.arti_id}_\n\n`
await vanzreply(m,teks.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('ASMAULHUSNA ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Asmaul Husna']
handler.tags=['islamic']
handler.command=['asmaulhusna']

export default handler