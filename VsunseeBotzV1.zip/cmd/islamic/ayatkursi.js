import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📖',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/islamic/ayatkursi?apikey=${global.VsunseeApikey}`)
const data=res.data
if(!data.status)return m.reply('❌ Gagal mengambil data Ayat Kursi.')
const r=data.result
const teks=`📖 *${r.title}*\n\n🕋 *Arabic:* ${r.arabic}\n\n🔤 *Latin:* ${r.latin}\n\n🗣️ *Terjemahan:* ${r.translation}\n📚 *Referensi:* ${r.reference}`
await vanzreply(m,teks.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('AYATKURSI ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Ayat Kursi']
handler.tags=['islamic']
handler.command=['ayatkursi']

export default handler