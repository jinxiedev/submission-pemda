import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'🕌',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/islamic/bacaansholat?apikey=${global.VsunseeApikey}`)
const data=res.data
if(!data.status)return m.reply('❌ Gagal mengambil data bacaan sholat.')
let teks=`🕌 *Bacaan Sholat Lengkap*\n`
for(const x of data.result){
teks+=`\n📖 *${x.name}*\n\n🕋 *Arab:* ${x.arabic}\n\n🔤 *Latin:* ${x.latin}\n\n🗣️ *Terjemahan:* ${x.terjemahan}\n────────────────────────────`
}
await vanzreply(m,teks.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('BACAANSHOLAT ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Bacaan Sholat Lengkap']
handler.tags=['islamic']
handler.command=['bacaansholat']

export default handler