import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz,text,prefix,command})=>{
try{
if(!text)return m.reply(`🕌 Masukkan nama nabi!\n\nContoh:\n${prefix+command} adam\n${prefix+command} musa\n${prefix+command} ibrahim`)
await vanzz.sendMessage(m.chat,{react:{text:'📜',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/kisahnabi?apikey=${global.VsunseeApikey}&nabi=${encodeURIComponent(text.toLowerCase())}`)
const data=res.data
if(!data.status)return m.reply(`❌ ${data.error}`)
const r=data.result
const teks=`📖 *Kisah Nabi ${r.name}*\n\n📅 *Tahun Kelahiran:* ${r.tahun_kelahiran}\n📍 *Tempat Lahir:* ${r.tempat_lahir}\n📊 *Usia:* ${r.usia} tahun\n\n────────────────────────────\n${r.description}`
await vanzreply(m,teks.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('KISAHNABI ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Kisah Nabi']
handler.tags=['islamic']
handler.command=['kisahnabi']

export default handler