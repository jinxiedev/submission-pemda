import axios from 'axios'
import "../../settings/config.js"
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m,{vanzz,text,prefix,command})=>{
try{
if(!text)return m.reply(`🕌 Masukkan nama sholat yang benar!\n\nContoh:\n${prefix+command} subuh\n${prefix+command} dzuhur\n${prefix+command} ashar\n${prefix+command} maghrib\n${prefix+command} isha`)
await vanzz.sendMessage(m.chat,{react:{text:'🙏',key:m.key}})
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/islamic/niatsholat?apikey=${global.VsunseeApikey}&sholat=${encodeURIComponent(text.toLowerCase())}`)
const data=res.data
if(!data.status)return m.reply(`❌ ${data.error}`)
const r=data.result
const teks=`🕌 *Niat Sholat ${r.solat.toUpperCase()}*\n\n📖 *Arab:* ${r.arabic}\n\n🔤 *Latin:* ${r.latin}\n\n🗣️ *Terjemahan:* ${r.translation_id}`
await vanzreply(m,teks.trim())
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('NIATSHOLAT ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Niat Sholat']
handler.tags=['islamic']
handler.command=['niatsholat']

export default handler