import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

try {
await vanzz.sendMessage(m.chat, { react: { text: '⚙️', key: m.key } })

if (command === 'webtoapp' || command === 'createapp') {
if (!text || !text.includes('|')) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} url|email|nama_aplikasi|app_icon|splash_icon` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}
const [url, email, appName, appIcon, splashIcon] = text.split('|').map(a => a.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/toapp/create?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(url)}&email=${encodeURIComponent(email)}&appName=${encodeURIComponent(appName)}&appIcon=${encodeURIComponent(appIcon)}&splashIcon=${encodeURIComponent(splashIcon)}`)
const data = res.data
if (!data.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const teks = `🚀 *BUILD STARTED!*\n\n📱 Aplikasi : ${appName}\n🌐 URL : ${url}\n📧 Email Dev : ${email}\n🆔 App ID : ${data.appId}\n\n⌛ Status : ${data.message}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '📲 Web To App Builder',
body: 'Konversi website menjadi APK dengan cepat',
thumbnailUrl: appIcon || 'https://files.catbox.moe/fgfl5a.png',
sourceUrl: `https://${global.VsunseeApi}/tools/toapp?appId=${data.appId}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

else if (command === 'toappcheck') {
await vanzz.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} app_id` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}
const statusRes = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/toapp/status?apikey=${global.VsunseeApikey}&appId=${encodeURIComponent(text)}`)
const statusData = statusRes.data
if (!statusData.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const info = statusData.details
if (info.status !== 'success') {
const teks = `⏳ *APP MASIH DIPROSES*\n\n🆔 App ID : ${statusData.appId}\n⚙️ Status : ${info.status}\n🌐 URL : ${info.url}\n🎨 App Icon : ${info.appIcon}\n💧 Splash Icon : ${info.splashIcon}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🚧 Build Masih Berjalan',
body: 'Aplikasi sedang dibuat, harap tunggu beberapa saat',
thumbnailUrl: info.appIcon || 'https://files.catbox.moe/fgfl5a.png',
sourceUrl: `https://${global.VsunseeApi}/tools/toapp?appId=${statusData.appId}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '🕐', key: m.key } })
return
}
const downloadRes = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/toapp/download?apikey=${global.VsunseeApikey}&appId=${encodeURIComponent(text)}`)
const dl = downloadRes.data.details
const teks = `✅ *APP SIAP DIUNDUH!*\n\n📱 *${dl.appName}*\n🌐 URL : ${dl.url}\n📦 Package : ${dl.package_name}\n🔑 SHA Key : ${dl.keySha}\n\n📥 *Link Unduhan:*\n🧩 APK : ${dl.buildFile}\n🧰 AAB : ${dl.aabFile}\n🗃️ Source : ${dl.sourceFile}\n🔐 KeyStore : ${dl.keyFile}\n\n🔓 KeyPass : ${dl.keyPass}\n🪪 StorePass : ${dl.storePass}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '📲 App Build Selesai',
body: 'Klik untuk unduh hasil APK kamu',
thumbnailUrl: dl.appIcon || 'https://files.catbox.moe/fgfl5a.png',
sourceUrl: dl.buildFile,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
} catch (e) {
console.error('TOAPP ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Web To App Builder & Checker']
handler.tags = ['tools']
handler.command = ['webtoapp','toappcheck']

export default handler