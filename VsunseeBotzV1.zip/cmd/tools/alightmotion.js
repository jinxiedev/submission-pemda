import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '🎞️', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} url_alightmotion\n\n📍 Contoh:\n${prefix + command} https://alightcreative.com/am/share/u/3HYWO0zhhqTT2MmjKLDQXF1MiUq2/p/sTydstuTTk-79a8d875c8588a65` }, { quoted: qtext })
return
}
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/alightmotion?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const d = res.data
if (!d.status || !d.result) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const teks = `🎬 *Alight Motion Project*\n\n🎨 Judul: ${d.result.title}\n💾 Ukuran: ${d.result.size}\n📦 Versi: ${d.result.amVersionPackage}\n🔢 Code: ${d.result.amVersionCode}\n\n🌐 Link Asli:\n${d.result.amLink}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🎞️ Alight Motion Downloader',
body: 'Project berhasil diambil dari server',
thumbnailUrl: d.result.image,
sourceUrl: d.result.amLink,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('ALIGHTMOTION ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Alight Motion Metadata']
handler.tags = ['tools']
handler.command = ['alightmotion']

export default handler