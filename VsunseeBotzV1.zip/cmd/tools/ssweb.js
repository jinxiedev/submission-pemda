import pkg from 'getscreenshot.js'
import { qtext } from '../../source/quoted.js'
import fs from 'fs'

const { screenshotV2 } = pkg

function isUrl(str) {
try {
new URL(str)
return true
} catch {
return false
}
}

let handler = async (m, { vanzz, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

if (!text) return vanzz.sendMessage(m.chat, { text: `⚙️ *Masukkan link website!*\n\nContoh:\n.ssweb https://example.com` }, { quoted: qtext })
if (!isUrl(text)) return vanzz.sendMessage(m.chat, { text: `❌ *Link tidak valid!*\nGunakan format:\nhttps://example.com` }, { quoted: qtext })

await vanzz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

try {
const data = await screenshotV2(text)
if (!data) return await vanzz.sendMessage(m.chat, { text: '❌ Gagal mengambil tangkapan layar.' }, { quoted: qtext })

const caption = `📸 *Screenshot Website*\n🌐 URL: ${text}`

if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
image: data,
mimetype: 'image/png',
caption,
contextInfo: {
externalAdReply: {
title: '🌍 Website Screenshot',
body: 'Tangkapan layar berhasil dibuat!',
thumbnailUrl: 'https://files.catbox.moe/4kv6up.jpg',
sourceUrl: text,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { image: data, mimetype: 'image/png', caption }, { quoted: qtext })
}

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('SSWEB ERROR:', e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Screenshot Website']
handler.tags = ['tools']
handler.command = ['ssweb']

export default handler