let handler=async(m,{command,text})=>{
if(!text)return m.reply(command==='encjawa'?"❗ Silakan masukkan teks yang ingin dienkripsi ke dalam aksara Jawa!":"❗ Silakan masukkan teks Aksara Jawa yang ingin didekripsi ke huruf Latin.")
if(command==='encjawa'){
const aksaraLatinMap={"a":"ꦲ","b":"ꦧ","c":"ꦕ","d":"ꦢ","e":"ꦲꦺ","f":"ꦥ꦳","g":"ꦒ","h":"ꦲꦃ","i":"ꦲꦶ","j":"ꦗ","k":"ꦏ","l":"ꦭ","m":"ꦩ","n":"ꦤ","o":"ꦲꦺꦴ","p":"ꦥ","q":"꧀ꦏꦸ","r":"ꦫ","s":"ꦱ","t":"ꦠ","u":"ꦲꦸ","v":"ꦮ꦳","w":"ꦮ","x":"ꦼꦏꦱ꧀","y":"ꦪ","z":"ꦗ꦳","1":"꧐꧑","2":"꧐꧒","3":"꧐꧓","4":"꧐꧔","5":"꧐꧕","6":"꧐꧖","7":"꧐꧗","8":"꧐꧘","9":"꧐꧙","0":"꧐꧀",".":"꧉",",":"꧈","!":"꧌","?":"꧍","\n":"\n"," ":" "}
let hasil=""
for(let char of text.toLowerCase()){hasil+=aksaraLatinMap[char]||char}
m.reply(`📜 *Teks terenkripsi dalam Aksara Jawa:*\n\n${hasil}`)
}else if(command==='decjawa'){
const jawaToLatinMap={"ꦲꦺꦴ":"o","ꦲꦸ":"u","ꦲꦶ":"i","ꦲꦺ":"e","ꦲ":"a","ꦲꦃ":"h","ꦧ":"b","ꦕ":"c","ꦢ":"d","ꦥ꦳":"f","ꦒ":"g","ꦗ":"j","ꦏ":"k","ꦭ":"l","ꦩ":"m","ꦤ":"n","꧀ꦏꦸ":"q","ꦫ":"r","ꦱ":"s","ꦠ":"t","ꦮ꦳":"v","ꦮ":"w","ꦼꦏꦱ꧀":"x","ꦪ":"y","ꦗ꦳":"z","꧐꧑":"1","꧐꧒":"2","꧐꧓":"3","꧐꧔":"4","꧐꧕":"5","꧐꧖":"6","꧐꧗":"7","꧐꧘":"8","꧐꧙":"9","꧐꧀":"0","꧈":",","꧉":".","꧌":"!","꧍":"?"," ":" ","\n":"\n"}
const sortedKeys=Object.keys(jawaToLatinMap).sort((a,b)=>b.length-a.length)
let hasil=text
for(const key of sortedKeys){const regex=new RegExp(key,'g');hasil=hasil.replace(regex,jawaToLatinMap[key])}
m.reply(`📄 *Hasil dekripsi ke Latin:*\n\n${hasil}`)}}

handler.help=['Encrypt & Decrypt Aksara Jawa']
handler.tags=['tools']
handler.command=['encjawa','decjawa']

export default handler