import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

try {
await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

if (!text) {
await vanzz.sendMessage(m.chat, {
text: `🧠 *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix + command} 737364627276362@newsletter`
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/hexcodes?apikey=${global.VsunseeApikey}&input=${encodeURIComponent(text)}`)
const data = res.data
if (!data.status) {
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}

const teks = `💻 *HEX Code Converter*\n🔡 Input : ${data.input}\n🔣 Output : ${data.result}\n⚙️ Mode : ${data.mode}`

if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: {
externalAdReply: {
title: '🧩 HEX Encoder',
body: 'Kode berhasil dikonversi!',
thumbnailUrl: 'https://e.top4top.io/p_3568smepx1.jpg',
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('HEXCODE ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['HEXADECIMAL Encoder/Decoder']
handler.tags = ['tools']
handler.command = ['enchex']

export default handler