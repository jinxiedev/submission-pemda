import fs from 'fs'
import { ImageUploadService } from 'node-upload-images'

let handler=async(m,{vanzz,reaction})=>{
let q=m.quoted?m.quoted:m
let mime=(q.msg||q).mimetype||''
if(!/image|video/g.test(mime))return m.reply('⚠️ Kirim atau balas gambar/video yang ingin diupload!')
await reaction(m.chat,'💤')
try{
let mediaPath=await vanzz.downloadAndSaveMediaMessage(q)
const service=new ImageUploadService('pixhost.to')
let{directLink}=await service.uploadFromBinary(fs.readFileSync(mediaPath),'vanzryuichi.png')
let link=directLink.toString()
await fs.unlinkSync(mediaPath)
let caption=`✅ *Upload Berhasil!*\n\n🔗 *Link:* ${link}`
if(/image/g.test(mime)){await vanzz.sendMessage(m.chat,{image:{url:link},caption},{quoted:m})}
else if(/video/g.test(mime)){await vanzz.sendMessage(m.chat,{video:{url:link},caption},{quoted:m})}
else{await vanzz.sendMessage(m.chat,{text:caption},{quoted:m})}
await reaction(m.chat,'✅')
}catch(e){console.error(e);await reaction(m.chat,'❌');m.reply('*[❌]* Gagal upload file ke PixHost.*')}}

handler.help=['Uploader File Pixhost']
handler.tags=['tools']
handler.command=['tourl2']

export default handler