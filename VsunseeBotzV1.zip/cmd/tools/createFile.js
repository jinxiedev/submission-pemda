import fs from 'fs-extra'

let handler = async (m,{vanzz,args,qtext})=>{
const input = args.join(" ").split("|")
if(input.length < 3) return vanzz.sendMessage(m.chat,{text:"*CONTOH :* .createfile js|namafile|console.log('Hello vanzz!')"}, { quoted: qtext })
const fileType = input[0]?.trim()
const fileName = input[1]?.trim()
const content = input.slice(2).join("|").trim()
if(!fileName) return vanzz.sendMessage(m.chat,{text:"*Nama file tidak boleh kosong!*"},{ quoted: qtext })
if(!content) return vanzz.sendMessage(m.chat,{text:"*Isi file tidak boleh kosong!*"},{ quoted: qtext })
let type,mime,result
switch(fileType){
case "js": type=".js"; mime="application/javascript"; result=".js"; break
case "html": type=".html"; mime="text/html"; result=".html"; break
case "ruby": type=".rb"; mime="application/x-ruby"; result=".rb"; break
case "py": type=".py"; mime="text/x-python"; result=".py"; break
case "jv": type=".java"; mime="text/x-java-source"; result=".java"; break
case "json": type=".json"; mime="application/json"; result=".json"; break
case "c": type=".c"; mime="text/x-c"; result=".c"; break
case "cpp": type=".cpp"; mime="text/x-c++src"; result=".cpp"; break
case "ct": type=".cs"; mime="text/x-csharp"; result=".cs"; break
case "php": type=".php"; mime="application/x-httpd-php"; result=".php"; break
case "ts": type=".ts"; mime="application/x-typescript"; result=".ts"; break
case "go": type=".go"; mime="text/x-go"; result=".go"; break
case "lua": type=".lua"; mime="text/x-lua"; result=".lua"; break
case "css": type=".css"; mime="text/css"; result=".css"; break
case "txt": type=".txt"; mime="text/plain"; result=".txt"; break
default:
return vanzz.sendMessage(m.chat,{text:`Perintah Tidak Dikenali. File Type Yang Tersedia

- js      ( *JavaScript* ) 
- html ( *Html* ) 
- ruby ( *Ruby* ) 
- py     ( *Python* ) 
- jv      ( *Java* ) 
- json ( *Json* ) 
- c       ( *C* ) 
- cpp  ( *C++* ) 
- ct      ( *C#* ) 
- php  ( *PHP* ) 
- ts      ( *TypeScript* ) 
- go     ( *GoLang* ) 
- lua    ( *Lua* ) 
- css   ( *CSS* ) 
- txt    ( *Text/Txt* )`},{ quoted: qtext })}
let file = `${fileName}${result}`
try{
await fs.promises.writeFile(file,content)
await vanzz.sendMessage(m.chat,{document:fs.readFileSync(file),fileName:file,mimetype:mime},{ quoted: qtext })
await fs.promises.unlink(file)
}catch(err){
console.log(err)
await vanzz.sendMessage(m.chat,{text:`Gagal membuat file: ${err.message}`},{ quoted: qtext })}
}

handler.help=['Create File From Code']
handler.tags=['tools']
handler.command=['createfile']

export default handler