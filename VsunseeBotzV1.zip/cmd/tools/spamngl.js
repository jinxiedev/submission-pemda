import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '📨', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} https://ngl.link/username|jumlah|pesan|delay(ms)\n\n📍 Contoh:\n${prefix + command} https://ngl.link/tata0180439|5|hallo|3000` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}
const [link, jumlah, pesan, delay] = text.split('|').map(a => a.trim())
if (!link || !jumlah || !pesan) return await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/spamngl?apikey=${global.VsunseeApikey}&link=${encodeURIComponent(link)}&jumlah=${jumlah}&pesan=${encodeURIComponent(pesan)}&delay=${delay || 3000}`)
const data = res.data
if (!data.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const teks = `✅ *SPAM NGL BERHASIL!*\n\n🔗 Link: ${data.query.link}\n📦 Jumlah: ${data.query.jumlah}\n💬 Pesan: ${data.query.pesan}\n⏱️ Delay: ${data.query.delay} ms\n\n📢 Status: ${data.result}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '💣 NGL Spammer',
body: 'Pesan dikirim otomatis via API Vsunsee',
thumbnailUrl: 'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl: data.query.link,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('SPAMNGL ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['NGL Spam Sender']
handler.tags = ['tools']
handler.command = ['spamngl']

export default handler