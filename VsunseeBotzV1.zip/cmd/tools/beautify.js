import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

try {
await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

if (!text) {
await vanzz.sendMessage(m.chat, {
text: `🧠 *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix + command} <!DOCTYPE html><html>...</html>`
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/beautify?apikey=${global.VsunseeApikey}&code=${encodeURIComponent(text)}`)
const data = res.data
if (!data.status) {
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}

const teks = `💻 *Beautify Code Result*\n✨ Kode berhasil dirapikan!\n\n\`\`\`${data.result || 'Tidak ada hasil'}\`\`\``

if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: {
externalAdReply: {
title: '🧩 Code Beautifier',
body: 'Kode tampil lebih rapi dan clean!',
thumbnailUrl: 'https://j.top4top.io/p_3568ksf251.jpg',
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('BEAUTIFY ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Beautify/Formatter Code']
handler.tags = ['tools']
handler.command = ['susunkode']

export default handler