import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler=async(m,{vanzz,prefix,command,text})=>{
const modesend=global.modesend
const mode=(modesend==='xreply'||modesend==='button')?'xreply':'false'
try{
await vanzz.sendMessage(m.chat,{react:{text:'⏳',key:m.key}})
if(!text){
await vanzz.sendMessage(m.chat,{text:`🧠 *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix+command} 8.8.8.8`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}})
return}
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/iplookup?apikey=${global.VsunseeApikey}&ip=${encodeURIComponent(text)}`)
const data=res.data
if(!data.status)return await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
const geo=data.geoInfo||{}
const dns=data.reverseDNS||{}
const teks=`🌐 *IP LOOKUP RESULT*\n\n📍 IP Address : ${data.query}\n🔁 Hostname : ${dns.hostname||'-'}\n🏢 ISP : ${geo.isp||'-'}\n💼 Organization : ${geo.org||'-'}\n🌎 Country : ${geo.country||'-'}\n🏙️ Region : ${geo.region||'-'}\n🌆 City : ${geo.city||'-'}\n🕒 Timezone : ${geo.timezone||'-'}\n📡 Coordinates : ${geo.lat}, ${geo.lon}`
if(mode==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks,
contextInfo:{externalAdReply:{
title:'🛰️ IP Lookup Service',
body:'Menampilkan informasi lokasi dan ISP IP address',
thumbnailUrl:'https://files.catbox.moe/j5x2mu.png',
sourceUrl:`https://www.google.com/maps?q=${geo.lat},${geo.lon}`,
mediaType:1,
renderLargerThumbnail:true}}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks},{quoted:qtext})}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('IPLOOKUP ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})}}

handler.help=['IP Lookup Service']
handler.tags=['tools']
handler.command=['iplookup']

export default handler