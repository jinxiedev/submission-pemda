import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m,{vanzz,prefix,command,text})=>{
const modesend=global.modesend
const mode=(modesend==='xreply'||modesend==='button')?'xreply':'false'
try{
await vanzz.sendMessage(m.chat,{react:{text:'⏳',key:m.key}})
if(!text){
await vanzz.sendMessage(m.chat,{text:`🧠 *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix+command} https://${global.VsunseeApi}`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}})
return}
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/hostinfo?apikey=${global.VsunseeApikey}&host=${encodeURIComponent(text)}`)
const data=res.data
if(!data.status)return await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
const teks=`🌐 *HOST INFO SCAN*\n\n🧩 Host : ${data.query}\n💻 IP Address : ${data.ip}\n📡 Status : ${data.result?.toUpperCase()}\n📶 HTTP Status : ${data.httpStatus}\n⚡ Response : ${data.responseTime}\n🔒 SSL Valid : ${data.ssl?.valid_from} ➜ ${data.ssl?.valid_to}\n🏢 Issuer : ${data.ssl?.issuer?.O} (${data.ssl?.issuer?.CN})\n📍 Domain : ${data.ssl?.subject?.CN}`
if(mode==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks,
contextInfo:{externalAdReply:{
title:'🌍 Host Info Checker',
body:'Cek status domain dan SSL certificate',
thumbnailUrl:'https://files.catbox.moe/fgfl5a.png',
sourceUrl:data.query,
mediaType:1,
renderLargerThumbnail:true}}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks},{quoted:qtext})}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('HOSTINFO ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})}}

handler.help=['Host Info Checker']
handler.tags=['tools']
handler.command=['hostinfo']

export default handler