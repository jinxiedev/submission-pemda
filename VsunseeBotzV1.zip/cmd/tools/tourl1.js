import { fileTypeFromBuffer } from 'file-type'
import * as cheerio from 'cheerio'
import request from 'request'

let handler=async(m,{vanzz,reaction})=>{
let q=m.quoted?m.quoted:m
let mime=(q.msg||q).mimetype||''
if(!/image|video/g.test(mime))return m.reply('⚠️ Balas atau kirim gambar/video yang ingin diupload!')
await reaction(m.chat,'☁️')

async function top4top(buffer){
return new Promise(async(resolve)=>{
const{ext}=(await fileTypeFromBuffer(buffer))||{ext:'bin'}
var req=request({
url:'https://top4top.io/index.php',
method:'POST',
headers:{
'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
'content-type':'multipart/form-data; boundary=----WebKitFormBoundaryAmIhdMyLOrbDawcA',
'User-Agent':'Mozilla/5.0 (BlackBerry; U; BlackBerry 9900; en) AppleWebKit/534.11+ (KHTML, like Gecko) Version/7.0.0.585 Mobile Safari/534.11+'}
},function(error,response,body){
if(error)return resolve({status:'error'})
const $ = cheerio.load(body)
let result=$('div.alert.alert-warning > ul > li > span').find('a').attr('href')||'gagal'
if(result==='gagal'){resolve({status:'error',msg:'Maybe File Not Allowed Or Try Another File'})}else{resolve({status:'sukses',result})}})
let form=req.form()
form.append('file_1_',buffer,{filename:`${Math.floor(Math.random()*10000)}.${ext}`})
form.append('file_1_','')
form.append('submitr','[ رفع الملفات ]')})}
try{
let media=await q.download()
let upload=await top4top(media)
if(upload.status!=='sukses')return m.reply('❌ Upload gagal, coba file lain!')
let caption=`✅ *Upload Berhasil!*\n\n🔗 *Link:* ${upload.result}\n📦 *Size:* ${(media.length/1024).toFixed(2)} KB`
if(/image/g.test(mime)){await vanzz.sendMessage(m.chat,{image:{url:upload.result},caption},{quoted:m})}
else if(/video/g.test(mime)){await vanzz.sendMessage(m.chat,{video:{url:upload.result},caption},{quoted:m})}
else{await vanzz.sendMessage(m.chat,{text:caption},{quoted:m})}
await reaction(m.chat,'✅')
}catch(e){console.error(e);await reaction(m.chat,'❌');m.reply('*[❌]* Gagal upload file ke Top4Top.*')}}

handler.help=['Uploader File top4top']
handler.tags=['tools']
handler.command=['tourl']

export default handler