import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const modeSend = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

try {
await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

if (!text) {
await vanzz.sendMessage(m.chat, {
text: `🧠 *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix + command} hello|encode\n${prefix + command} 104 101 108 108 111|decode`
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}

const [query, mode] = text.split('|').map(a => a.trim().toLowerCase())
let data = {}

if (mode === 'decode') {
try {
const chars = query.split(' ').map(n => String.fromCharCode(parseInt(n))).join('')
data = { status: true, input: query, result: chars, mode: 'decode' }
} catch {
data = { status: false }
}
} else {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/asciicode?apikey=${global.VsunseeApikey}&input=${encodeURIComponent(query)}&mode=encode`)
data = res.data
}

if (!data.status) {
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}

const teks = `🧩 *ASCII ${data.mode.toUpperCase()} RESULT*\n🔡 Input : ${data.input}\n🔢 Output : ${data.result}\n⚙️ Mode : ${data.mode}`

if (modeSend === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: {
externalAdReply: {
title: '🧮 ASCII Encoder/Decoder',
body: 'Kode berhasil dikonversi!',
thumbnailUrl: 'https://b.top4top.io/p_3568nsefl1.jpg',
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

} catch (e) {
console.error('ASCII ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['ASCII Encoder/Decoder']
handler.tags = ['tools']
handler.command = ['encascii']

export default handler 