import fs from 'fs-extra'
import JsConfuser from 'js-confuser'

let handler = async (m,{vanzz})=>{
if(!m.quoted)return m.reply("❌ Reply file .js terlebih dahulu.")
const mime=m.quoted.mimetype||''
if(!/javascript|text/.test(mime))return m.reply("❌ File yang di-reply harus .js")
const media=await m.quoted.download()
if(!media)return m.reply("❌ Gagal download file.")
const filename=m.quoted.message?.documentMessage?.fileName||'file.js'
const safeFilename=filename.replace(/[^a-zA-Z0-9_.-]/g,'')
const tmpPath=`./@hardenc-${safeFilename}`
try{
fs.writeFileSync(tmpPath,media)
m.reply("🔒 Memproses encrypt hard code...")
const randomString=(length=2)=>{
const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
return[...Array(length)].map(()=>chars.charAt(Math.floor(Math.random()*chars.length))).join('')}
const identifierGenerator=()=>{
const base="/*素晴座素晴難vanzzDev素晴座素晴難/*^/*($break)*/"
return base.replace(/[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g,'')+randomString()}
const sourceCode=fs.readFileSync(tmpPath,'utf8')
const obfuscated=await JsConfuser.obfuscate(sourceCode,{
target:"node",
preset:"high",
compact:true,
minify:true,
flatten:true,
renameVariables:true,
renameGlobals:true,
identifierGenerator,
stringEncoding:0.01,
stringSplitting:0.1,
stringConcealing:true,
stringCompression:true,
duplicateLiteralsRemoval:true,
shuffle:{hash:false,true:false},
movedDeclarations:true,
objectExtraction:true,
globalConcealing:true})
if(!obfuscated||typeof obfuscated!=='string'||obfuscated.trim().length<10)throw new Error("Hasil encrypt kosong atau tidak valid.")
fs.writeFileSync(tmpPath,obfuscated)
await vanzz.sendMessage(m.chat,{document:fs.readFileSync(tmpPath),mimetype:"application/javascript",fileName:filename,caption:"✅ Encrypt file JS sukses!"},{quoted:m})}
catch(e){
console.error("Encrypt error:",e)
m.reply("❌ Terjadi error saat encrypt:\n"+e.message)}
finally{
if(fs.existsSync(tmpPath))fs.unlinkSync(tmpPath)}}

handler.help=['Encrypt Hard File JS']
handler.tags=['owner']
handler.command=['enchard']
handler.owner=true

export default handler