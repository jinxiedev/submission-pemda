import fs from 'fs'
import { exec } from 'child_process'
import { getRandom } from '../../source/myfunc.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m,{vanzz})=>{
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if(!/webp/.test(mime)) return m.reply('⚠️ Reply stiker WebP aja!')
let media = await vanzz.downloadAndSaveMediaMessage(q)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return m.reply('❌ Gagal convert ke gambar.')
let buffer = fs.readFileSync(ran)
vanzz.sendMessage(m.chat,{image:buffer},{quoted:qtext})
fs.unlinkSync(ran)
})}

handler.help=['ToImage Convert WebP to PNG']
handler.tags=['tools']
handler.command=['toimage']

export default handler