import axios from 'axios'
import fs from 'fs'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m,{vanzz,prefix,command,text})=>{
const modesend=global.modesend
const mode=(modesend==='xreply'||modesend==='button')?'xreply':'false'
try{
await vanzz.sendMessage(m.chat,{react:{text:'🌐',key:m.key}})
if(!text){
await vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah!*\n\nGunakan format:\n${prefix+command} url_website\n\n📍 Contoh:\n${prefix+command} https://${global.VsunseeApi}/`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}})
return
}
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/saveweb2zip?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.data||!d.data.downloadUrl){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const zipRes=await axios.get(d.data.downloadUrl,{responseType:'arraybuffer'})
const fileName=`websave_${Date.now()}.zip`
const filePath=`./${fileName}`
fs.writeFileSync(filePath,zipRes.data)
const teks=`🗂️ *SaveWeb2Zip Downloader*\n\n🌍 URL: ${d.data.url}\n📁 File: ${d.data.copiedFilesAmount} file tersalin\n✅ ZIP berhasil diunduh & dikirim`
if(mode==='xreply'){
await vanzz.sendMessage(m.chat,{
document:fs.readFileSync(filePath),
fileName:fileName,
mimetype:'application/zip',
caption:teks,
contextInfo:{
externalAdReply:{
title:'🌐 SaveWeb2Zip Downloader',
body:'Website berhasil disimpan ke ZIP',
thumbnailUrl:'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl:d.data.url,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{document:fs.readFileSync(filePath),fileName:fileName,mimetype:'application/zip',caption:teks},{quoted:qtext})
}
fs.unlinkSync(filePath)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('SAVEWEB2ZIP ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}
}

handler.help=['Web2Zip Tools']
handler.tags=['tools']
handler.command=['web2zip']

export default handler