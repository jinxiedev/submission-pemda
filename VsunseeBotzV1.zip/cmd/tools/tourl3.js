import fs from 'fs'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

let handler=async(m,{vanzz,reaction})=>{
let q=m.quoted?m.quoted:m
let mime=(q.msg||q).mimetype||''
if(!/image|video/g.test(mime))return m.reply('⚠️ Kirim atau balas gambar/video yang ingin diupload!')
await reaction(m.chat,'💤')
try{
let mediaPath=await vanzz.downloadAndSaveMediaMessage(q)
let buffer=fs.readFileSync(mediaPath)
let { ext }=await fileTypeFromBuffer(buffer)
const fetchModule=await import('node-fetch')
const fetch=fetchModule.default
let bodyForm=new FormData()
bodyForm.append('fileToUpload',buffer,'file.'+ext)
bodyForm.append('reqtype','fileupload')
let res=await fetch('https://catbox.moe/user/api.php',{method:'POST',body:bodyForm})
let link=await res.text()
await fs.unlinkSync(mediaPath)
let caption=`✅ *Upload Berhasil ke Catbox!*\n\n🔗 *Link:* ${link}`
if(/image/g.test(mime)){await vanzz.sendMessage(m.chat,{image:{url:link},caption},{quoted:m})}
else if(/video/g.test(mime)){await vanzz.sendMessage(m.chat,{video:{url:link},caption},{quoted:m})}
else{await vanzz.sendMessage(m.chat,{text:caption},{quoted:m})}
await reaction(m.chat,'✅')
}catch(e){console.error(e);await reaction(m.chat,'❌');m.reply('*[❌]* Upload gagal ke Catbox.*')}}

handler.help=['Uploader File Clouds Catbox']
handler.tags=['tools']
handler.command=['tourl3']

export default handler