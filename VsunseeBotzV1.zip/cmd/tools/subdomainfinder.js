import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} domain_atau_url\n\n📍 Contoh:\n${prefix + command} https://vcloudsz.my.id` }, { quoted: qtext })
return
}
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/subdomainfinder?apikey=${global.VsunseeApikey}&domain=${encodeURIComponent(text)}`)
const d = res.data
if (!d?.status || !Array.isArray(d?.result?.output?.data?.subdomains)) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const subs = d.result.output.data.subdomains.slice(0, 25)
let teks = `🧩 *Subdomain Finder Result*\n🌐 Domain: ${text}\n📊 Status: ${d.result.result_summary?.text || 'Tidak tersedia'}\n🕒 Durasi: ${d.result.duration}s\n\n`
for (let i = 0; i < subs.length; i++) {
const s = subs[i]
teks += `🔹 ${i + 1}. ${s.hostname}\n     🧭 IP: ${s.ip_address || '-'}\n     🔗 URL: ${s.hostname_data?.url || 'https://' + s.hostname}\n\n`
}
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: { externalAdReply: {
title: '🌐 Subdomain Finder',
body: `Ditemukan ${subs.length} subdomain aktif`,
thumbnailUrl: 'https://files.catbox.moe/j5lea7.jpg',
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/subdomainfinder?domain=${encodeURIComponent(text)}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks.trim() }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('SUBDOMAIN ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Subdomain Finder']
handler.tags = ['tools']
handler.command = ['subdomainfinder']
handler.owner = true;

export default handler