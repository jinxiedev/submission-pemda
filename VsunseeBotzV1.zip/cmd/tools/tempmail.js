import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

try {
await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

if (command === 'tempmail') {
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tempmail?apikey=${global.VsunseeApikey}`)
const data = res.data
if (!data.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const teks = `📩 *TEMPORARY EMAIL CREATED!*\n\n📧 Alamat : ${data.address}\n🔑 Token : ${data.token}\n⏳ Berlaku : ${data.expired_in}\n📬 Cek Inbox : .checkmail ${data.address}|${data.token}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🕶️ TempMail Generator',
body: 'Buat email sementara untuk verifikasi cepat',
thumbnailUrl: 'https://files.catbox.moe/fgfl5a.png',
sourceUrl: data.inboxUrl,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

else if (command === 'checkmail') {
if (!text || !text.includes('|')) {
await vanzz.sendMessage(m.chat, { text: `📩 *Format Salah!*\n\nGunakan format:\n${prefix + command} email|token` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}
const [email, token] = text.split('|').map(a => a.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tempmail?apikey=${global.VsunseeApikey}&check=true&email=${encodeURIComponent(email)}&token=${encodeURIComponent(token)}`)
const data = res.data
if (!data.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const inbox = data.messages || []
if (!inbox.length) {
const teks = `📭 *INBOX KOSONG*\n\n📧 Email : ${data.email}\n⏳ Berlaku : ${data.expired_in}\nBelum ada pesan yang masuk.`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🕶️ TempMail Inbox',
body: 'Belum ada pesan yang masuk ke email ini',
thumbnailUrl: 'https://files.catbox.moe/fgfl5a.png',
sourceUrl: `https://${global.VsunseeApi}/tools/tempmail?email=${encodeURIComponent(data.email)}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
return
}
let teks = `📨 *INBOX UNTUK ${data.email}*\n\n`
inbox.forEach((msg, i) => {
teks += `📧 *${i + 1}. Dari:* ${msg.from}\n🧾 *Subjek:* ${msg.subject}\n🕒 *Tanggal:* ${msg.date}\n💬 *Isi:* ${msg.body_text || '(Tanpa teks)'}\n\n`
})
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks.trim(),
contextInfo: { externalAdReply: {
title: '📬 TempMail Inbox',
body: 'Pesan masuk berhasil ditampilkan',
thumbnailUrl: 'https://files.catbox.moe/fgfl5a.png',
sourceUrl: `https://${global.VsunseeApi}/tools/tempmail?email=${encodeURIComponent(data.email)}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks.trim() }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}
} catch (e) {
console.error('TEMPMAIL ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['TempMail Generator & Checker']
handler.tags = ['tools']
handler.command = ['tempmail','checkmail']

export default handler