let handler = async (m,{vanzz,args,prefix,qtext})=>{
const text = args.join(' ')
if(!text) return vanzz.sendMessage(m.chat,{text:`*Format salah!*\nPenggunaan:\n${prefix + 'spampesan'} teks_pesan,nomor,jumlah`},{ quoted: qtext })
let t = text.split(',')
if(t.length < 3) return vanzz.sendMessage(m.chat,{text:`*Format salah!*\nPenggunaan:\n${prefix + 'spampesan'} teks_pesan,nomor,jumlah`},{ quoted: qtext })
let chat = t[0].trim()
let nomor = t[1].replace(/[^0-9]/g,'')
let jumlah = parseInt(t[2].trim())
if(!nomor) return vanzz.sendMessage(m.chat,{text:'Nomor tidak valid!'},{ quoted: qtext })
if(isNaN(jumlah) || jumlah <= 0) return vanzz.sendMessage(m.chat,{text:'Jumlah pesan harus berupa angka positif!'},{ quoted: qtext })
let targetNumber = nomor + '@s.whatsapp.net'
const sleep = (ms)=>new Promise(resolve=>setTimeout(resolve,ms))
try{
for(let i=0;i<jumlah;i++){
await vanzz.sendMessage(targetNumber,{text:chat},{ quoted: null })
await sleep(500)
}
await vanzz.sendMessage(m.chat,{text:`✅ *Berhasil mengirim pesan!*\n\n📨 *Jumlah terkirim:* ${jumlah}\n👤 *Nomor tujuan:* ${nomor}`},{ quoted: qtext })
}catch(err){
console.error(err)
await vanzz.sendMessage(m.chat,{text:`❌ Gagal mengirim pesan ke nomor ${nomor}`},{ quoted: qtext })}
}

handler.help=['Kirim Pesan Lebih']
handler.tags=['owner']
handler.command=['spampesan']
handler.owner=true

export default handler