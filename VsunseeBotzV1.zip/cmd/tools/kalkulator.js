import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '🧮', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah*\n\nGunakan format:\n${prefix + command} ekspresi_matematika\n\n📍 Contoh:\n${prefix + command} 1+1` }, { quoted: qtext })
return
}
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/kalkulator?apikey=${global.VsunseeApikey}&q=${encodeURIComponent(text)}`)
const d = res.data
if (!d.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const teks = `🧮 *Kalkulator*\n\n📥 Input: ${d.query}\n📤 Hasil: *${d.result}*`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🧮 Kalkulator Online',
body: 'Powered by Vsunsee API',
thumbnailUrl: 'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/kalkulator?q=${encodeURIComponent(text)}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('KALKULATOR ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Kalkulator Online']
handler.tags = ['tools']
handler.command = ['kalkulator']

export default handler