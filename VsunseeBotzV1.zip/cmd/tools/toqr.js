import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command }) => {
try {
await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

if (!m.text) {
await vanzz.sendMessage(m.chat, { 
text: `⚙️ *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix + command} https://example.com` 
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}

const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/toqr?apikey=${global.VsunseeApikey}&query=${encodeURIComponent(m.text)}`, { responseType: 'arraybuffer' })

await vanzz.sendMessage(m.chat, { 
image: Buffer.from(res.data), 
caption: `🧩 *QR Code Generated*\n🔗 ${m.text}\n📸 Scan Untuk Membuka!` 
}, { quoted: qtext })

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('QR ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Generate QR Code from Text/URL']
handler.tags = ['tools']
handler.command = ['toqr']

export default handler