import fs from 'fs'
import { toAudio } from '../../source/events/converter.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m,{vanzz,command,mime,qmsg})=>{
try{
if(!/video|mp4/.test(mime))return m.reply('⚠️ Reply atau kirim video terlebih dahulu!')
await vanzz.sendMessage(m.chat,{react:{text:'🎧',key:m.key}})
const vid=await vanzz.downloadAndSaveMediaMessage(qmsg)
const result=await toAudio(fs.readFileSync(vid),'mp4')
await vanzz.sendMessage(m.chat,{audio:result,mimetype:'audio/mpeg',ptt:/tovn/.test(command)?true:false},{quoted:qtext})
fs.unlinkSync(vid)
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('TOAUDIO ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}
}

handler.help=['Convert Video To Audio/Voice']
handler.tags=['tools']
handler.command=['toaudio']

export default handler