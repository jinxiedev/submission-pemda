import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '🆔', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} 3601120705880002` }, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/niklookup?apikey=${global.VsunseeApikey}&nik=${encodeURIComponent(text)}`)
const data = res.data
if (!data.status) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const r = data.result
const teks = `✅ *HASIL PENCARIAN NIK*\n\n🆔 NIK : ${r.nik}\n👤 Jenis Kelamin : ${r.kelamin}\n🎂 Tanggal Lahir : ${r.lahir_lengkap}\n📍 Provinsi : ${r.provinsi.nama}\n🏙️ Kota/Kabupaten : ${r.kotakab.nama} (${r.kotakab.jenis})\n🌆 Kecamatan : ${r.kecamatan.nama}\n🗺️ Kode Wilayah : ${r.kode_wilayah}\n🔢 Nomor Urut : ${r.nomor_urut}\n\n🪄 *Informasi Tambahan*\n📅 Pasaran : ${r.tambahan.pasaran}\n⏳ Usia : ${r.tambahan.usia}\n🎚️ Kategori : ${r.tambahan.kategori_usia}\n🎉 Ultah Berikutnya : ${r.tambahan.ultah}\n♉ Zodiak : ${r.tambahan.zodiak}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🧾 NIK Lookup Indonesia',
body: `${r.provinsi.nama} • ${r.kotakab.nama}`,
thumbnailUrl: 'https://files.catbox.moe/4kv6up.jpg',
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/niklookup?nik=${r.nik}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('NIKLOOKUP ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['NIK Lookup Indonesia']
handler.tags = ['tools']
handler.command = ['niklookup']

export default handler