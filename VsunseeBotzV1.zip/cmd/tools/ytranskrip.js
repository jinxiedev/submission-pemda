import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '🎙️', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} url_youtube\n\n📍 Contoh:\n${prefix + command} https://youtu.be/bCIgpEFpyiY` }, { quoted: qtext })
return
}
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/ytranskrip?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const d = res.data
if (!d.status || !d.result) return await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
const t = d.result.transcript.length > 3000 ? d.result.transcript.slice(0, 3000) + '... (terlalu panjang)' : d.result.transcript
const teks = `🎧 *YouTube Transcript*\n\n🎵 Judul: ${d.result.title}\n👤 Channel: ${d.result.author}\n🔗 URL: ${d.url}\n\n🗒️ *Transkrip:*\n${t}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🎙️ YouTube Transkrip Generator',
body: 'Transkrip berhasil diambil dari video',
thumbnailUrl: d.result.thumbnail,
sourceUrl: d.url,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('YTRANSKRIP ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['YouTube Transkrip']
handler.tags = ['tools']
handler.command = ['ytranskrip']

export default handler