import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'
try {
await vanzz.sendMessage(m.chat, { react: { text: '🈯', key: m.key } })
if (!text) {
await vanzz.sendMessage(m.chat, { text: `🧩 *Format Salah!*\n\nGunakan format:\n${prefix + command} teks|kode_bahasa\n\n📍 Contoh:\n${prefix + command} Hello World|id` }, { quoted: qtext })
return
}
let [query, to] = text.split('|').map(a => a.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/translate?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(query)}&to=${to || ''}`)
const d = res.data
if (!d.status) {
let list = Object.entries(d.available || {}).map(([k, v]) => `🌐 ${k} → ${v}`).join('\n')
const teks = `❌ *Kode bahasa tidak valid!*\n\n🗣️ Gunakan format:\n${prefix + command} teks | kode_bahasa\n\n🌍 *Daftar Bahasa Tersedia:*\n${list}`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: '🌐 Translator Language List',
body: 'Daftar kode bahasa yang bisa digunakan',
thumbnailUrl: 'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/translate`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}
const teks = `🌍 *Translator Result*\n\n🗣️ Dari: ${d.from.toUpperCase()}\n🏳️ Ke: ${d.to_name}\n\n💬 Input: ${d.query}\n📝 Hasil: *${d.result}*`
if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: { externalAdReply: {
title: `🌐 Translator (${d.to_name})`,
body: 'Powered by Vsunsee API',
thumbnailUrl: 'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl: `https://${global.VsunseeApi}/vsunseeV8/translate?text=${encodeURIComponent(d.query)}&to=${d.to}`,
mediaType: 1,
renderLargerThumbnail: true
}}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}
await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('TRANSLATE ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Translator Bahasa']
handler.tags = ['tools']
handler.command = ['translate']

export default handler