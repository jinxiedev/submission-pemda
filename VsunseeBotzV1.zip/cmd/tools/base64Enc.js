import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m, { vanzz, prefix, command, text }) => {
const modesend = global.modesend
const mode = (modesend === 'xreply' || modesend === 'button') ? 'xreply' : 'false'

try {
await vanzz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

if (!text) {
await vanzz.sendMessage(m.chat, {
text: `🧠 *Gunakan dengan benar!*\n\n✍️ Contoh:\n${prefix + command} Hello|encode\n${prefix + command} SGVsbG8=|decode`
}, { quoted: qtext })
await vanzz.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
return
}

const [query, modeInput] = text.split('|').map(a => a.trim())
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/base64?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(query)}&mode=${modeInput || 'encode'}`)
const data = res.data
if (!data.status) {
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
return
}

const teks = `🔐 *BASE64 ${data.mode.toUpperCase()}*\n📥 Input : ${data.query}\n📤 Output : ${data.result}\n⚙️ Mode : ${data.mode}`

if (mode === 'xreply') {
await vanzz.sendMessage(m.chat, {
text: teks,
contextInfo: {
externalAdReply: {
title: '🧬 Base64 Encoder/Decoder',
body: 'Kode berhasil diproses!',
thumbnailUrl: 'https://j.top4top.io/p_3568ig97h1.jpg',
sourceUrl: `https://${global.VsunseeApi}`,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qtext })
} else {
await vanzz.sendMessage(m.chat, { text: teks }, { quoted: qtext })
}

await vanzz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
} catch (e) {
console.error('BASE64 ERROR:', e?.response?.data || e)
await vanzz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
}
}

handler.help = ['Base64 Encoder/Decoder']
handler.tags = ['tools']
handler.command = ['encbase64']

export default handler