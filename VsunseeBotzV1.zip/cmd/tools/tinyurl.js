import axios from 'axios'
import '../../settings/config.js'
import { qtext } from '../../source/quoted.js'

let handler = async (m,{vanzz,prefix,command,text})=>{
const modesend=global.modesend
const mode=(modesend==='xreply'||modesend==='button')?'xreply':'false'
try{
await vanzz.sendMessage(m.chat,{react:{text:'🔗',key:m.key}})
if(!text){
await vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah!*\n\nGunakan format:\n${prefix+command} url_yang_ingin_dipendekkan\n\n📍 Contoh:\n${prefix+command} https://${global.VsunseeApi}`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'⚠️',key:m.key}})
return
}
const res=await axios.get(`https://${global.VsunseeApi}/vsunseeV8/tinyurl?apikey=${global.VsunseeApikey}&url=${encodeURIComponent(text)}`)
const d=res.data
if(!d.status||!d.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
return
}
const teks=`🔗 *TinyURL Shortener*\n\n🌍 Asli: ${text}\n✨ Pendek: ${d.result}`
if(mode==='xreply'){
await vanzz.sendMessage(m.chat,{
text:teks,
contextInfo:{
externalAdReply:{
title:'🔗 TinyURL Shortener',
body:'Link berhasil diperpendek dengan Vsunsee API',
thumbnailUrl:'https://b.top4top.io/p_3568r3ege1.jpg',
sourceUrl:d.result,
mediaType:1,
renderLargerThumbnail:true
}
}
},{quoted:qtext})
}else{
await vanzz.sendMessage(m.chat,{text:teks},{quoted:qtext})
}
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('TINYURL ERROR:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}
}

handler.help=['TinyURL Shortener']
handler.tags=['tools']
handler.command=['tinyurl']

export default handler