import { qtext } from "../../source/quoted.js"

let handler = async (m,{vanzz,prefix,command})=>{
if(!m.quoted)return m.reply(`*❌ Syntax Error!!*\n*Example:* Reply ViewOnce dengan caption ${prefix+command}`)
try{
let buffer=await m.quoted.download()
let type=m.quoted.mtype
let sendOptions={quoted:m}
if(type==="videoMessage"){
await vanzz.sendMessage(m.chat,{video:buffer,caption:m.quoted.text||""},sendOptions)
}else if(type==="imageMessage"){
await vanzz.sendMessage(m.chat,{image:buffer,caption:m.quoted.text||""},sendOptions)
}else if(type==="audioMessage"){
await vanzz.sendMessage(m.chat,{
audio:buffer,
mimetype:"audio/mpeg",
ptt:m.quoted.ptt||false
},sendOptions)
}else{
return m.reply("❌ Media View Once tidak didukung.")
}
}catch(err){
console.error(err)
m.reply("❌ Gagal mengambil media ViewOnce.")
}
}

handler.help=['Remove ViewOnce Media (Image/Video/Audio)']
handler.tags=['tools']
handler.command=['rvo']
handler.owner = true;

export default handler