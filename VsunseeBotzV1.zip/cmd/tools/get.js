import fs from 'fs'
import util from 'util'

let handler = async (m, { vanzz, text }) => {
if (!/^https?:\/\//.test(text)) return m.reply(`⚠️ Awali URL dengan *http://* atau *https://*`)
try {
const ajg = await fetch(text)
const size = parseInt(ajg.headers.get('content-length')) || 0
if (size > 100 * 1024 * 1024) throw `⚠️ File terlalu besar (${(size / (1024 * 1024)).toFixed(1)} MB)`
const contentType = ajg.headers.get('content-type') || ''
const buffer = await ajg.arrayBuffer()
const alak = Buffer.from(buffer)

if (contentType.startsWith('image/')) {
return await vanzz.sendMessage(m.chat, { image: { url: text }, caption: `📸 Gambar dari URL:\n${text}` }, { quoted: m })
}
if (contentType.startsWith('video/')) {
return await vanzz.sendMessage(m.chat, { video: { url: text }, caption: `🎥 Video dari URL:\n${text}` }, { quoted: m })
}
if (contentType.startsWith('audio/')) {
return await vanzz.sendMessage(m.chat, { audio: { url: text }, mimetype: contentType, caption: `🎧 Audio dari URL:\n${text}` }, { quoted: m })
}

let ext = ''
if (contentType.includes('html')) ext = 'html'
else if (contentType.includes('css')) ext = 'css'
else if (contentType.includes('javascript') || contentType.includes('ecmascript')) ext = 'js'

if (ext) {
const filename = `/tmp/output_${Date.now()}.${ext}`
fs.writeFileSync(filename, alak)
await vanzz.sendMessage(m.chat, {
document: { url: filename },
fileName: `result.${ext}`,
mimetype: contentType,
caption: `📁 File *${ext.toUpperCase()}* Terdeteksi \n🌐 URL: ${text}`
}, { quoted: m })
return
}

let teks
try {
teks = alak.toString()
} catch {
teks = util.format(alak)
}
await m.reply(teks.slice(0, 65536) || '✅ Berhasil diambil, tapi kosong.')
} catch (err) {
console.error(err)
m.reply(`❌ Gagal mengambil URL.\n${err.message || err}`)
}
}

handler.help = ['Get Any URL']
handler.tags = ['tools']
handler.command = ['get']

export default handler