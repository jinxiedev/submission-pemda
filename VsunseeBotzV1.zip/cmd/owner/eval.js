import util from 'util'

let handler = async (m, { text, vanzreply }) => {
try {
if (!text) return vanzreply(m, '⚙️ Contoh:\n.eval return 2 + 2')

let evaled = await eval(`(async () => { ${text} })()`)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)

await vanzreply(m, evaled.length > 4000 ? evaled.slice(0, 4000) + '…' : evaled)

} catch (err) {
await vanzreply(m, '❌ *Error:* ' + String(err))
}
}

handler.help = ['eval']
handler.tags = ['owner']
handler.command = ['eval']
handler.owner = true

export default handler