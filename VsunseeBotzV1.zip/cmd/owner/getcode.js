import fs from 'fs'
import path from 'path'

let handler = async (m, { text, prefix, command }) => {
try {
if (!text) return m.reply(`📦 *Format Salah*\n\nGunakan:\n${prefix + command} <nama_command>\n\nContoh:\n${prefix + command} yts\n\n📁 Folder yg dicek: cmd/ + semua subfolder`)

const baseDir = './cmd'
let foundPath = null


const folders = fs.readdirSync(baseDir).filter(x => fs.statSync(path.join(baseDir, x)).isDirectory())

for (const folder of folders) {
const folderPath = path.join(baseDir, folder)
const files = fs.readdirSync(folderPath).filter(f => f.endsWith('.js'))

for (const file of files) {
if (file.toLowerCase() === `${text.toLowerCase()}.js`) {
foundPath = path.join(folderPath, file)
break
}
}
if (foundPath) break
}

if (!foundPath) return m.reply(`❌ Tidak ditemukan file \`${text}.js\` di dalam folder cmd/`)

const code = fs.readFileSync(foundPath, 'utf8')


if (code.length > 4096) {
const tempPath = `./tmp/${text}.js`
fs.writeFileSync(tempPath, code)
await m.reply({ document: { url: tempPath }, mimetype: 'application/javascript', fileName: `${text}.js` })
fs.unlinkSync(tempPath)
} else {
await m.reply(`🧩 *Kode Dari :* \`${text}.js\`\n\n\`\`\`js\n${code}\n\`\`\``)
}

} catch (e) {
console.error('GETCODE ERROR:', e)
m.reply('❌ Terjadi kesalahan saat membaca file command.')
}
}

handler.help = ['Get Handle Code']
handler.tags = ['owner']
handler.command = ['gp']
handler.owner = true

export default handler