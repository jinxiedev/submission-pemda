import fs from 'fs-extra'
import path from 'path'
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { reaction, reply }) => {
try {
const directoryPath = './'
const fileTerkecuali = [
'cmd','settings','source','message.js','myfunc.js','quoted.js',
'handler.js','index.js','package.json','package-lock.json'
]

const files = await fs.readdir(directoryPath, { withFileTypes: true })
const filteredArray = files
.filter(f => f.isFile())
.map(f => f.name)
.filter(name => {
return [
'.gif','.png','.jpg','.jpeg','.webp','.mp3','.m4a','.mp4',
'.webm','.opus','.js','.zip','.css','.py','.html','.7z','.gz','.log'
].includes(path.extname(name)) && !fileTerkecuali.includes(name)
})

if (filteredArray.length === 0)
return vanzreply(m, "Gaada file kenangan di root 🥲")

let teks = `🗑️ *Terdeteksi ${filteredArray.length} File Sampah😒:*\n\n`
filteredArray.forEach((e, i) => { teks += `${i + 1}. ${e}\n` })
await vanzreply(m, teks)

for (const file of filteredArray) {
await fs.unlink(path.join(directoryPath, file))
console.log(`File ${file} dihapus.`)
}

await reaction(m.chat, '✅')
await vanzreply(m, '🧹 Pembersihan selesai!')

} catch (err) {
console.error('DELSAMPAH ERROR:', err)
await vanzreply(m, "❌ Gagal menghapus file: " + err)
await reaction(m.chat, '❌')
}
}

handler.help = ['Hapus File Sampah']
handler.tags = ['owner']
handler.command = ['delsampah']
handler.owner = true

export default handler