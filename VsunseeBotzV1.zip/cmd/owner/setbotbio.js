import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzz, text, prefix, command, reaction }) => {
try {
if (!text)
return m.reply(`Where is the text?\nExample: ${prefix + command} Vanz Bot`)
await vanzz.updateProfileStatus(text)
await vanzreply(m, `✅ Success In Changing The Bio Of Bot's Number`)
await reaction(m.chat, '☑️')
} catch (e) {
console.error('SETBOTBIO ERROR:', e)
await reaction(m.chat, '🙅‍♂️')
await vanzreply(m, '❌ Failed To Change Bot Bio')
}
}

handler.help = ['Settings Bot Bio']
handler.tags = ['owner']
handler.command = ['setbotbio']
handler.owner = true

export default handler