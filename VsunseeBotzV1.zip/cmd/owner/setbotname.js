import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzz, text, prefix, command, reaction }) => {
try {
if (!text)
return m.reply(`Where is the name?\nExample: ${prefix + command} Vanz Bot`)
await vanzz.updateProfileName(text)
await vanzreply(m, `✅ Success In Changing The Name Of Bot's Number`)
await reaction(m.chat, '☑️')
} catch (e) {
console.error('SETBOTNAME ERROR:', e)
await reaction(m.chat, '🙅‍♂️')
await vanzreply(m, '❌ Failed To Change Bot Name')
}
}

handler.help = ['Settings Bot Name']
handler.tags = ['owner']
handler.command = ['setbotname']
handler.owner = true

export default handler