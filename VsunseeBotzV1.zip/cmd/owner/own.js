import fs from "fs";
import path from "path";

let handler = async (m, { args, command, prefix }) => {
const configPath = path.join(process.cwd(), "settings", "config.js");
if (!fs.existsSync(configPath)) return m.reply("❌ File config.js tidak ditemukan!");

let configText = fs.readFileSync(configPath, "utf8");
const ownerMatch = configText.match(/global\.owner\s*=\s*\[(.*?)\];/s);
if (!ownerMatch) return m.reply("Tidak bisa menemukan global.owner di config.js!");

let ownerRaw = ownerMatch[1].trim();
let currentOwners = ownerRaw
  .replace(/["'`]/g, "")
  .split(",")
  .map(v => v.trim())
  .filter(v => v.length > 0);

switch (command) {
case "addowner": {
const idArg = args[0]?.replace(/[^0-9]/g, "");
if (!idArg) return m.reply(`Contoh: ${prefix}addowner 173426987819031`);
if (currentOwners.includes(idArg)) return m.reply("ID itu sudah ada di daftar owner.");

currentOwners.push(idArg);
const newOwnerLine = `global.owner = ["${currentOwners.join(",")}"];`;
configText = configText.replace(/global\.owner\s*=\s*\[.*?\];/s, newOwnerLine);
fs.writeFileSync(configPath, configText);
await m.reply(`✅ ${idArg} berhasil ditambahkan ke daftar owner.`);
break;
}

case "delowner": {
const idArg = args[0]?.replace(/[^0-9]/g, "");
if (!idArg) return m.reply(`Contoh: ${prefix}delowner 173426987819031`);
if (!currentOwners.includes(idArg)) return m.reply("ID itu tidak ada di daftar owner.");

currentOwners = currentOwners.filter(v => v !== idArg);
const updatedOwnerLine = `global.owner = ["${currentOwners.join(",")}"];`;
configText = configText.replace(/global\.owner\s*=\s*\[.*?\];/s, updatedOwnerLine);
fs.writeFileSync(configPath, configText);
await m.reply(`✅ ${idArg} berhasil dihapus dari daftar owner.`);
break;
}

case "listowner": {
if (currentOwners.length === 0) return m.reply("Belum ada owner yang terdaftar.");
let text = "📋 *DAFTAR OWNER:*\n\n";
currentOwners.forEach((o, i) => (text += `${i + 1}. ${o}\n`));
text += `\nTotal: ${currentOwners.length}`;
m.reply(text);
break;
}

default:
m.reply(
`*OWNER COMMANDS:*\n` +
`${prefix}addowner <id>\n` +
`${prefix}delowner <id>\n` +
`${prefix}listowner`
);
}
};

handler.help = ["Owner Control"]
handler.command = ["addowner", "delowner", "listowner"];
handler.tags = ["owner"];
handler.owner = true;

export default handler;