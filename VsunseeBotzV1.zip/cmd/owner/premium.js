import fs from "fs";
import path from "path";

const premiumPath = path.join(process.cwd(), "source", "database", "premium.json");

let handler = async (m, { args, command, prefix }) => {
if (!fs.existsSync(premiumPath)) {
fs.mkdirSync(path.dirname(premiumPath), { recursive: true });
fs.writeFileSync(premiumPath, JSON.stringify([]));
}

let data = JSON.parse(fs.readFileSync(premiumPath));
const idArg = args[0]?.replace(/[^0-9]/g, "");

switch (command) {
case "addpremium":
if (!idArg) return m.reply(`Contoh: ${prefix}addpremium 173426987819031`);
if (data.includes(idArg)) return m.reply("ID itu sudah ada di daftar premium.");
data.push(idArg);
fs.writeFileSync(premiumPath, JSON.stringify(data, null, 2));
await m.reply(`✅ ${idArg} berhasil ditambahkan ke daftar *Premium User*.`);
break;

case "delpremium":
if (!idArg) return m.reply(`Contoh: ${prefix}delpremium 173426987819031`);
if (!data.includes(idArg)) return m.reply("ID itu tidak ada di daftar premium.");
data = data.filter(v => v !== idArg);
fs.writeFileSync(premiumPath, JSON.stringify(data, null, 2));
await m.reply(`✅ ${idArg} berhasil dihapus dari daftar *Premium User*.`);
break;

case "listpremium":
if (data.length === 0) return m.reply("Belum ada user premium.");
let text = "🌟 *DAFTAR USER PREMIUM:*\n\n";
data.forEach((o, i) => (text += `${i + 1}. ${o}\n`));
text += `\nTotal: ${data.length}`;
m.reply(text);
break;

default:
m.reply(
`*PREMIUM COMMANDS:*\n` +
`${prefix}addpremium <id>\n` +
`${prefix}delpremium <id>\n` +
`${prefix}listpremium`
);
}
};

handler.help = ["Premium Control"]
handler.tags = ["owner"];
handler.command = ["addpremium", "delpremium", "listpremium"];
handler.owner = true;

export default handler;