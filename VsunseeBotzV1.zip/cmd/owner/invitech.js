import fs from 'fs'
import axios from 'axios'
import "../../settings/config.js"
import "../../settings/thumb.js"
import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

let handler = async (m,{vanzz})=>{
try{
await vanzz.sendMessage(m.chat,{react:{text:'📡',key:m.key}})
let thumbBuffer
if(global.ThumbnailUrl?.startsWith('http')){
const res=await axios.get(global.ThumbnailUrl,{responseType:'arraybuffer'})
thumbBuffer=Buffer.from(res.data)
}else{
thumbBuffer=fs.existsSync(global.ThumbnailUrl)?fs.readFileSync(global.ThumbnailUrl):Buffer.alloc(0)
}
const invit=generateWAMessageFromContent(
m.chat,
proto.Message.fromObject({
newsletterAdminInviteMessage:{
newsletterJid:global.ChannelID,
newsletterName:'ᴠᴀɴᴢᴢ ʀʏᴜɪᴄʜɪ ✘',
jpegThumbnail:thumbBuffer,
caption:'📡 Undangan Menjadi Putyh',
inviteExpiration:Date.now()+86400000
}
}),
{userJid:m.sender,quoted:m}
)
await vanzz.relayMessage(m.chat,invit.message,{messageId:invit.key.id})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('NEWSLETTER INVITE ERROR:',e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['Invite Channel Whatsapp']
handler.tags=['owner']
handler.command=['invitech']

export default handler