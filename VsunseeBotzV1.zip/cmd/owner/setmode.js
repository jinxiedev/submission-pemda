import fs from 'fs'
import path from 'path'
import '../../settings/config.js'

let handler = async (m, { text, reaction }) => {
await reaction(m.chat, '⚙️')
try {
if (!text) return m.reply('❌ Contoh: *.setmode button*\n\nOpsi:\n- button\n- xreply\n- false')

let mode = text.toLowerCase().trim()
if (!['button', 'xreply', 'false'].includes(mode))
return m.reply('❌ Mode tidak dikenal!\nGunakan salah satu:\n- button\n- xreply\n- false')

global.modesend = mode === 'false' ? false : mode

const configPath = path.resolve('./settings/config.js')
let configContent = fs.readFileSync(configPath, 'utf8')
configContent = configContent.replace(/global\.modesend\s*=\s*['"`]?.*?['"`]?;/, `global.modesend = '${global.modesend}';`)
fs.writeFileSync(configPath, configContent, 'utf8')

await reaction(m.chat, '✅')
m.reply(`🗯 Mode pengiriman berhasil diubah ke: *${global.modesend}*`)
console.log(`Mode pengiriman diubah ke: ${global.modesend}`)
} catch (e) {
console.error('SETMODE ERROR:', e)
await reaction(m.chat, '❌')
m.reply('❌ Terjadi kesalahan saat mengubah mode.')
}
}

handler.help = ['Setmode [button/xreply/false]']
handler.tags = ['owner']
handler.command = ['setmode']
handler.owner = true

export default handler