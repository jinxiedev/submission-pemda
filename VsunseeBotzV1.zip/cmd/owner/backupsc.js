import fs from 'fs-extra'
import path from 'path'
import { execSync } from 'child_process'
import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { vanzz, reaction }) => {
try {
const ls = execSync('ls').toString().split('\n').filter(pe => pe && !['node_modules','session','.npm'].includes(pe))
const msg = await vanzz.sendMessage(m.chat, { text: ' 0% ░░░░░░░░░░' }, { quoted: null })

for (let i of [30, 60, 90, 100]) {
const filled = '█'.repeat(i / 10)
const empty = '░'.repeat(10 - i / 10)
await new Promise(r => setTimeout(r, 700))
await vanzz.sendMessage(m.chat, { text: `♻️ ${i}% ${filled}${empty}${i == 100 ? ' 🔖' : ''}`, edit: msg.key })
}

execSync(`zip -r New.zip ${ls.join(' ')}`)
await vanzz.sendMessage('6288276746473@s.whatsapp.net', {
document: fs.readFileSync('./New.zip'),
mimetype: 'application/zip',
fileName: 'VanzRyuichi.zip'
}, { quoted: m })

await execSync('rm -rf New.zip')
await vanzreply(m, '_Backup Script Selesai ✨_')
await reaction(m.chat, '✅')

} catch (e) {
console.error('BACKUP ERROR:', e)
await vanzreply(m, '❌ Terjadi kesalahan saat backup!')
await reaction(m.chat, '❌')
}
}

handler.help = ['Backup Script']
handler.tags = ['owner']
handler.command = ['backupsc']
handler.owner = true

export default handler