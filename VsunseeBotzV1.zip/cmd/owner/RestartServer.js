import { vanzreply } from '../../source/vanzreply.js'

let handler = async (m, { sleep, vanzreply }) => {
try {
await vanzreply(m, 'Server Berhasil Di Restart ♻️')
await sleep(1000)
process.exit(0) // otomatis restart di PM2/nodemon
} catch (e) {
console.error('RESTART ERROR:', e)
await vanzreply(m, '❌ Gagal me-restart server!')
}
}

handler.help = ['Restart Server']
handler.tags = ['owner']
handler.command = ['off', 'restart']
handler.owner = true

export default handler