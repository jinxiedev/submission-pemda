import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
try {
let ask = text ? encodeURIComponent(text) : "Hello"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/groq?apikey=${global.VsunseeApikey}&prompt=${ask}`)
const data = res.data
if (!data?.status) {
await reaction(m.chat, '❌')
console.log("Groq API Error:", data)
return
}
await reaction(m.chat, '✨')
await vanzz.sendMessage(m.chat, { text: `❓ ${data.prompt}\n\n💬 ${data.response}` }, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("Groq Error:", e)
}
}

handler.help = ['Ai Chat Groq AI']
handler.tags = ['ai']
handler.command = ['groq']

export default handler