import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
try {
let ask = text ? encodeURIComponent(text) : "Hello"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/deepai?apikey=${global.VsunseeApikey}&ask=${ask}`)
const data = res.data
if (!data?.status) {
await reaction(m.chat, '❌')
console.log("DeepAI API Error:", data)
return
}
await reaction(m.chat, '✨')
await vanzz.sendMessage(m.chat, { text: `❓ ${data.query}\n\n💬 ${data.result}` }, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("DeepAI Error:", e)
}
}

handler.help = ['Ai Chat Deepai']
handler.tags = ['ai']
handler.command = ['deepai']

export default handler