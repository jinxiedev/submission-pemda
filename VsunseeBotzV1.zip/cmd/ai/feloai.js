import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
try {
let ask = text ? encodeURIComponent(text) : "Hello"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/feloai?apikey=${global.VsunseeApikey}&query=${ask}`)
const data = res.data
if (!data?.status || !data?.result) {
await reaction(m.chat, '❌')
console.log("FeloAI API Error:", data)
return
}
await reaction(m.chat, '✨')
let sources = data.result.source?.slice(0, 2).map((s, i) => `${i + 1}. ${s.title} (${s.link})`).join("\n") || "-"
await vanzz.sendMessage(m.chat, { text: `❓ ${ask}\n\n💬 ${data.result.answer}\n\n🔗 Sumber:\n${sources}` }, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("FeloAI Error:", e)
}
}

handler.help = ['Ai Chat Feloai']
handler.tags = ['ai']
handler.command = ['feloai']

export default handler