import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
try {
let ask = text ? encodeURIComponent(text) : "Hallo Perkenalkan Diri Anda"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/openai?apikey=${global.VsunseeApikey}&ask=${ask}`)
const data = res.data
if (!data || !data.status) {
await reaction(m.chat, '❌')
console.log("OpenAI API Error:", data)
return
}
await reaction(m.chat, '✨')
await vanzz.sendMessage(m.chat, { text: `❓ ${data.question}\n\n💬 ${data.result}` }, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("OpenAI Error:", e)
}
}

handler.help = ['Ai Chat Openai']
handler.tags = ['ai']
handler.command = ['openai']

export default handler