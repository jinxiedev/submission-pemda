import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
try {
let ask = text ? encodeURIComponent(text) : "Hello"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/chatupai?apikey=${global.VsunseeApikey}&type=chat&prompt=${ask}`)
const data = res.data
if (!data?.status || !data?.result) {
await reaction(m.chat, '❌')
console.log("ChatUpAI API Error:", data)
return
}
await reaction(m.chat, '✨')
await vanzz.sendMessage(m.chat, { text: `❓ ${data.query}\n\n💬 ${data.result.result}` }, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("ChatUpAI Error:", e)
}
}

handler.help = ['Ai Chat Chatupai']
handler.tags = ['ai']
handler.command = ['chatupai']

export default handler