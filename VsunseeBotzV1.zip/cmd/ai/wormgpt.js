import axios from 'axios'
import "../../settings/config.js"
import { qtext } from "../../source/quoted.js";

let handler = async (m,{vanzz,text,prefix,command})=>{
await vanzz.sendMessage(m.chat,{react:{text:'🗯',key:m.key}})
try{
if(!text)return vanzz.sendMessage(m.chat,{text:`🧩 *Format Salah*\n\nGunakan format:\n${prefix+command} pertanyaan`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'✨',key:m.key}})
const apiUrl=`https://${global.VsunseeApi}/vsunseeV8/wormgpt?apikey=${global.VsunseeApikey}&text=${encodeURIComponent(text)}`
const res=await axios.get(apiUrl)
const r=res.data
if(!r?.status||!r?.result){
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
console.error('WormGPT API Error:', r)
return m.reply('❌ Tidak ada hasil dari API WormGPT.')
}
await vanzz.sendMessage(m.chat,{text:`😈 *WormGPT Response:*\n\n${r.result}`},{quoted:qtext})
await vanzz.sendMessage(m.chat,{react:{text:'✅',key:m.key}})
}catch(e){
console.error('WormGPT Error:',e?.response?.data||e)
await vanzz.sendMessage(m.chat,{react:{text:'❌',key:m.key}})
}}

handler.help=['WormGPT Ai Chat']
handler.tags=['ai']
handler.command=['wormgpt']

export default handler