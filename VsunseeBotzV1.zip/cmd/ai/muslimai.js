import axios from 'axios'
import '../../settings/config.js'
import { qtext } from "../../source/quoted.js";

let handler = async (m, { vanzz, reaction, text }) => {
await reaction(m.chat, '🗯')
try {
let ask = text ? encodeURIComponent(text) : "Hadist"
const res = await axios.get(`https://${global.VsunseeApi}/vsunseeV8/muslimai?apikey=${global.VsunseeApikey}&query=${ask}`)
const data = res.data
if (!data?.status) {
await reaction(m.chat, '❌')
console.log("MuslimAI API Error:", data)
return
}
await reaction(m.chat, '✨')
await vanzz.sendMessage(m.chat, { text: `❓ ${data.query}\n\n💬 ${data.result}` }, { quoted: qtext })
await reaction(m.chat, '✅')
} catch (e) {
await reaction(m.chat, '❌')
console.log("MuslimAI Error:", e)
}
}

handler.help = ['Ai Chat Muslimai']
handler.tags = ['ai']
handler.command = ['muslimai']

export default handler